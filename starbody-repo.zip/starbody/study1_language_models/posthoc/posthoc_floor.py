# POST HOC (not part of the pre-registration): the bfloat16 noise floor across all four Law Test 2 models.
# CPU only: run it in any Colab session (no GPU needed). It reads each model's measurements.json and model_result.json
# from Drive, writes posthoc_floor.json and posthoc_floor.png to the run folder, and changes nothing sealed.
#
# The model being checked: in bfloat16, measured KL = floor + true (float32) KL, where the floor is a fixed level of
# arithmetic noise for each model. If that holds:
#   - bfloat16 KL matches floor + float32 KL along the whole dose grid;
#   - the rounding zone's edge sits at the floor (the edge is where float32 KL falls below it);
#   - bfloat16 reaches the budget at sqrt(1 - floor/tau) of the float32 dose, which should explain C2b per direction.

import json, math
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

try:
    from google.colab import drive
    drive.mount("/content/drive")
    BASE = Path("/content/drive/MyDrive/Starbody/law_test2")
except ImportError:
    BASE = Path("starbody_law_test2")
MODELS = ["google/gemma-2-2b", "Qwen/Qwen2.5-1.5B", "Qwen/Qwen2.5-3B", "Qwen/Qwen2.5-7B"]
_runs = [r for r in sorted(BASE.glob("run_*"))
         if all((r / m.split("/")[-1] / "measurements.json").exists() for m in MODELS)]
assert _runs, f"No Law Test 2 run folder under {BASE} holds all four models' measurements."
RUN_ROOT = _runs[-1]
TAU = json.loads((RUN_ROOT / "protocol.json").read_text())["tau_nats"]
print("Reading", RUN_ROOT)

def curve_rows(meas):
    rows = []
    for n, rec in meas.items():
        for g in rec["bf16"]["kl"]:
            k16, k32 = np.array(rec["bf16"]["kl"][g]), np.array(rec["fp32"]["kl"][g])
            f0 = float(np.median(k16[np.argsort(k32)[:5]]))            # bfloat16 KL at the five smallest true effects
            low = k32 <= f0 / 10                                        # true effect negligible next to the floor
            floor = max(float(np.median((k16 - k32)[low])) if low.sum() >= 3 else f0, 1e-12)
            valid = k32 >= 1e-8
            err = np.abs(np.log(np.maximum(k16[valid], 1e-30) / (floor + k32[valid])))
            ratio = k16 / np.maximum(k32, 1e-30)
            off = ((ratio > 2) | (ratio < 0.5)) & valid
            edge = float(k32[off].max()) if off.any() else 0.0
            rows.append({"direction": n, "genre": g, "floor": floor, "edge_kl": edge,
                         "edge_over_floor": edge / floor if edge > 0 else float("nan"),
                         "additive_error_factor": float(np.exp(np.median(err))) if err.size else float("nan"),
                         "points_below_floor": int(low.sum())})
    return rows

PH = {"note": "post hoc; not part of the pre-registration", "run": str(RUN_ROOT), "models": {}}
for m in MODELS:
    folder = RUN_ROOT / m.split("/")[-1]
    meas = json.loads((folder / "measurements.json").read_text())
    res = json.loads((folder / "model_result.json").read_text())
    rows = curve_rows(meas)
    floors_a = {r["direction"]: r["floor"] for r in rows if r["genre"] == "A"}
    c2b = {}
    for n, rec in meas.items():
        obs = rec["bf16"]["s_tau"] / rec["fp32"]["s_tau"]
        pred = math.sqrt(max(0.0, 1 - floors_a[n] / TAU))
        c2b[n] = {"observed": obs, "predicted": pred, "difference": obs - pred}
    act = res["activation_stats"]["per_layer"]
    PH["models"][m] = {
        "floor_over_tau_median": float(np.median([r["floor"] for r in rows]) / TAU),
        "floor_over_tau_iqr": [float(np.percentile([r["floor"] for r in rows], q) / TAU) for q in (25, 75)],
        "edge_over_floor_median": float(np.nanmedian([r["edge_over_floor"] for r in rows])),
        "additive_error_factor_median": float(np.nanmedian([r["additive_error_factor"] for r in rows])),
        "c2b": c2b,
        "c2b_explained_within_5_points": float(np.mean([abs(v["difference"]) <= 0.05 for v in c2b.values()])),
        "max_activation": float(max(a["max_abs"] for a in act)),
        "p999_activation_median": float(np.median([a["p999_abs"] for a in act])),
        "baseline_readout": res.get("baseline_readout"),
        "curves": rows}
(RUN_ROOT / "posthoc_floor.json").write_text(json.dumps(PH, indent=1))

print("\nPOST HOC: the bfloat16 noise floor (not pre-registered; the sealed verdict is unchanged)\n")
print(f"{'model':<14}{'floor / tau':>14}{'edge / floor':>14}{'fit (x)':>9}{'C2b explained':>15}{'max |act|':>11}"
      f"{'baseline fix/break':>20}")
for m, v in PH["models"].items():
    b = v["baseline_readout"] or {}
    print(f"{m.split('/')[-1]:<14}{v['floor_over_tau_median']:>14.4f}{v['edge_over_floor_median']:>14.2f}"
          f"{v['additive_error_factor_median']:>9.2f}{v['c2b_explained_within_5_points']:>14.0%}"
          f"{v['max_activation']:>11.0f}{(str(round(100 * b.get('fix', 0))) + '% / ' + str(round(100 * b.get('break', 0))) + '%'):>20}")
print("\nReading the columns:")
print("  floor / tau   bfloat16's noise floor as a share of the budget (median over all curves)")
print("  edge / floor  near 1 (between about 0.5 and 1) if the rounding zone ends where the floor is")
print("  fit (x)       median factor by which floor + float32 KL misses the measured bfloat16 KL (1.0 = exact)")
print("  C2b explained share of directions whose bfloat16/float32 budget-dose ratio matches sqrt(1 - floor/tau) within 5 points")
print("  baseline      first-token readout with no patch; both should be 0%")
for m, v in PH["models"].items():
    print(f"  {m.split('/')[-1]} C2b, observed vs predicted:",
          {n: f"{c['observed']:.2f}/{c['predicted']:.2f}" for n, c in v["c2b"].items()})

fig, ax = plt.subplots(1, 3, figsize=(19, 5.2))
names = [m.split("/")[-1] for m in MODELS]
ax[0].boxplot([[r["floor"] / TAU for r in PH["models"][m]["curves"]] for m in MODELS])
ax[0].set_xticks(range(1, len(names) + 1)); ax[0].set_xticklabels(names)
ax[0].set(yscale="log", title="bfloat16 noise floor (share of the budget)", ylabel="floor / tau")
for i, m in enumerate(MODELS):
    ax[0].annotate(f"max |act| {PH['models'][m]['max_activation']:.0f}", (i + 1, PH["models"][m]["floor_over_tau_iqr"][1]),
                   textcoords="offset points", xytext=(0, 8), ha="center", fontsize=8)
for m, col in zip(MODELS, ("#C44E52", "#4C72B0", "#55A868", "#8172B3")):
    meas = json.loads((RUN_ROOT / m.split("/")[-1] / "measurements.json").read_text())
    fl = {(r["direction"], r["genre"]): r["floor"] for r in PH["models"][m]["curves"]}
    xs, ys = [], []
    for n, rec in meas.items():
        for g in rec["bf16"]["kl"]:
            k16, k32 = np.array(rec["bf16"]["kl"][g]), np.array(rec["fp32"]["kl"][g])
            keep = k32 >= 1e-8
            xs += list(fl[(n, g)] + k32[keep])
            ys += list(np.maximum(k16[keep], 1e-12))
    ax[1].scatter(xs, ys, s=3, alpha=0.4, color=col, label=m.split("/")[-1])
lim = [1e-8, 1]
ax[1].plot(lim, lim, "k:", lw=1)
ax[1].set(xscale="log", yscale="log", xlim=lim, ylim=lim, title="Additive model: floor + float32 KL vs measured bfloat16",
          xlabel="floor + float32 KL", ylabel="bfloat16 KL")
ax[1].legend(fontsize=8, markerscale=4)
for i, m in enumerate(MODELS):
    c = PH["models"][m]["c2b"]
    ax[2].scatter([v["predicted"] for v in c.values()], [v["observed"] for v in c.values()], label=names[i], s=25)
ax[2].plot([0.3, 1.05], [0.3, 1.05], "k:", lw=1)
ax[2].set(title="C2b: budget-dose ratio, observed vs predicted from the floor", xlabel="predicted sqrt(1 - floor/tau)",
          ylabel="observed bfloat16 / float32 dose")
ax[2].legend(fontsize=8)
plt.tight_layout()
fig.savefig(RUN_ROOT / "posthoc_floor.png", dpi=130)
plt.show()
