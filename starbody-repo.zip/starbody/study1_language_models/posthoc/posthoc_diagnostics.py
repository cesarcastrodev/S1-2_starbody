# POST HOC DIAGNOSTICS for Law Test 1 (lt1.3). Paste into a new cell at the end of the live session and run.
# Not part of the pre-registration: it reads what is in memory, writes posthoc_diagnostics.json, and changes
# nothing the sealed verdict depends on. GPU only, no judge calls, about 10-15 minutes.

def kl_A(d, s):
    return mean_kl(MONITOR["A"], d * s)

def scale_at(d, target, lo=1e-10, hi=64.0):
    """Scale at which KL on monitor genre A reaches the target (bisection in log scale, 2% precision)."""
    if kl_A(d, lo) >= target:
        return lo
    if kl_A(d, hi) < target:
        return float("inf")
    while hi / lo > 1.02:
        mid = math.sqrt(lo * hi)
        lo, hi = (mid, hi) if kl_A(d, mid) < target else (lo, mid)
    return math.sqrt(lo * hi)

def lowdose_exponent(d):
    """Exponent on a grid anchored on MEASURED KL: 9 doses from s/4 to 4s around the dose s where KL = tau/100."""
    s1 = scale_at(d, TAU / 100)
    if not np.isfinite(s1):
        return float("nan")
    sc = [s1 * 2 ** (k / 2) for k in range(-4, 5)]
    pts = [(s, k) for s, k in ((s, kl_A(d, s)) for s in sc) if 100 * LOQ < k <= TAU]
    return float(np.polyfit(np.log([p[0] for p in pts]), np.log([p[1] for p in pts]), 1)[0]) if len(pts) >= 3 else float("nan")

def stop_vs_breakdown_anchored(d, tau_high=0.1, max_steps=40):
    """T4 on a grid that starts inside the quadratic regime (KL = tau/1000) and climbs in sqrt(2) steps."""
    s0 = scale_at(d, TAU / 1000)
    if not np.isfinite(s0):
        return None
    sc, kl = [], []
    for k in range(max_steps):
        sc.append(s0 * 2 ** (k / 2))
        kl.append(kl_A(d, sc[-1]))
        if kl[-1] >= tau_high:
            break
    s_, k_ = np.array(sc), np.array(kl)
    eta2 = float(np.median(k_[:3] / s_[:3] ** 2))
    bd = np.nonzero((k_ > 2 * eta2 * s_ ** 2) & (k_ > 100 * LOQ))[0]
    i_stop, _ = escalate(list(s_), {"A": list(k_)}, tau=tau_high)
    breakdown = float(s_[bd[0]]) if len(bd) else float("inf")
    return {"breakdown": breakdown, "stop": float(s_[i_stop]), "stopped_before": bool(s_[i_stop] < breakdown)}

PH = {"note": "post hoc; not part of the pre-registration"}

# 1. Which directions broke certificate coverage, and does the full dose rule (certificate + monitoring) hold?
PH["certificate_failures"] = {n: [g for g in HELDOUT if HKL[f"{n}|cert"]["kl"][g] > TAU] for n in ALL_DIRS}
PH["certificate_failures"] = {n: v for n, v in PH["certificate_failures"].items() if v}
PH["full_rule"] = {}
for n in tqdm(ALL_DIRS, desc="held-out KL at the full dose rule"):
    sw = SWEEPS[n]
    s_ = dose_rules(n)["law"] if n in NONRANDOM else min(sw["cert"], sw["stop"])
    PH["full_rule"][n] = {"scale": s_, "kl": {g: mean_kl(HELDOUT[g], direction_tensor(n) * s_) for g in HELDOUT}}
_pairs = [v["kl"][g] <= TAU for v in PH["full_rule"].values() for g in HELDOUT]
PH["coverage_full_rule"] = float(np.mean(_pairs))

# 2. Escalation edge case: was the first escalation step already over budget?
PH["escalation_started_over_budget"] = [n for n in ALL_DIRS if any(k[0] >= TAU for k in SWEEPS[n]["escalation_kl"].values())]

# 3. T1, T2 and T4 again, on grids anchored on measured KL instead of the Fisher prediction
PH["exponent"], PH["horizon"], PH["blank_horizon"], PH["t4"] = {}, {}, {}, {}
for k, n in enumerate(tqdm(ALL_DIRS, desc="anchored sweeps")):
    d = direction_tensor(n)
    PH["exponent"][n] = lowdose_exponent(d)
    PH["horizon"][n] = scale_at(d, TAU)
    PH["t4"][n] = stop_vs_breakdown_anchored(d)
for k, n in enumerate(tqdm(NONRANDOM, desc="blank horizons")):
    PH["blank_horizon"][n] = [scale_at(matched_blank(direction_tensor(n), P["seed"] + 500 + 10 * k + j), TAU)
                              for j in range(L["blanks_per_direction"])]
_ex = [v for v in PH["exponent"].values() if np.isfinite(v)]
PH["T1_anchored_median_exponent"] = float(np.median(_ex)) if _ex else float("nan")
PH["T2_anchored_ratios"] = {n: PH["horizon"][n] / float(np.median(PH["blank_horizon"][n])) for n in NONRANDOM}
_r = [v for v in PH["T2_anchored_ratios"].values() if np.isfinite(v) and v > 0]
PH["T2_anchored_median_ratio"] = float(np.median(_r)) if _r else float("nan")
_t4 = [v for v in PH["t4"].values() if v and np.isfinite(v["breakdown"])]
PH["T4_anchored"] = {"curves_breaking_down": len(_t4),
                     "share_stopped_before": float(np.mean([v["stopped_before"] for v in _t4])) if _t4 else float("nan")}

save_json("posthoc_diagnostics.json", PH)
lo_, hi_ = FROZEN["exponent_band"]
blo, bhi = FROZEN["reference_band_with_iqr"]
print("POST HOC (not pre-registered; the sealed verdict is unchanged)")
print("Certificate failures by direction:", PH["certificate_failures"] or "none")
print(f"Coverage: certificate alone {COVERAGE:.0%} | full dose rule (certificate + monitoring) {PH['coverage_full_rule']:.0%} "
      f"| WikiText titration {ISO_COMPLIANCE:.0%}")
print("Escalation started over budget for:", PH["escalation_started_over_budget"] or "none")
print(f"T1 anchored: median exponent {PH['T1_anchored_median_exponent']:.2f} (band {lo_}-{hi_}; pre-registered grid gave {T1_MED:.2f})")
print(f"T2 anchored: median horizon ratio {PH['T2_anchored_median_ratio']:.2f} (band {blo}-{bhi}; grid gave {T2_MED:.2f})")
_t4a = PH["T4_anchored"]
print(f"T4 anchored: " + (f"{_t4a['share_stopped_before']:.0%} of {_t4a['curves_breaking_down']} breaking curves stopped "
                          f"before breakdown" if _t4a["curves_breaking_down"] else "no curve broke down before KL 0.1")
      + f" (grid gave {T4_RATE:.0%})")
for n in ALL_DIRS:
    r_ = PH["T2_anchored_ratios"].get(n, float("nan"))
    print(f"  {n:<34} exponent {PH['exponent'][n]:.2f} | horizon x{PH['horizon'][n]:.3g} | ratio to blanks {r_:.2f} | "
          f"worst held-out KL at the full rule {max(PH['full_rule'][n]['kl'].values()) / TAU:.2f} x budget")
