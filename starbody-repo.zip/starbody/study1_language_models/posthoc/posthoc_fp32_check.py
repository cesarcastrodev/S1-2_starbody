# POST HOC CHECK, run after posthoc_diagnostics.py in the same live session (it reuses its functions).
# Question: is the low-dose exponent near 0.2 because the model runs in bfloat16? Small patches can round away or flip
# single units of the last place, so KL tracks rounding rather than the patch. The metaphor series ran in float32 and
# found exactly 2.00.
# It converts this session's model to float32 (about 10.5 GB; nothing after it needs bfloat16), re-measures four
# directions, and writes posthoc_fp32_check.json. GPU only, no judge calls, about 5 minutes.

_dirs = ["p1c:random_0", "p1c:fisher_first_block", "full:fisher_trained_two_sided", "p1c:euclid_first"]
_bf16 = {n: {"exponent": PH["exponent"][n], "horizon": PH["horizon"][n]} for n in _dirs}
model.float()
torch.cuda.empty_cache()
print("model dtype now:", next(model.parameters()).dtype)

FP32 = {}
for n in tqdm(_dirs, desc="float32 anchored sweeps"):
    d = direction_tensor(n)
    FP32[n] = {"exponent": lowdose_exponent(d), "horizon": scale_at(d, TAU)}

save_json("posthoc_fp32_check.json", {"note": "post hoc; not part of the pre-registration", "bfloat16": _bf16, "float32": FP32})
print("POST HOC (not pre-registered): low-dose exponent and horizon, bfloat16 vs float32")
for n in _dirs:
    print(f"  {n:<32} exponent {_bf16[n]['exponent']:.2f} -> {FP32[n]['exponent']:.2f} | "
          f"horizon x{_bf16[n]['horizon']:.3g} -> x{FP32[n]['horizon']:.3g}")
_e = [v["exponent"] for v in FP32.values() if np.isfinite(v["exponent"])]
print(f"Median float32 exponent: {np.median(_e):.2f} (the quadratic law predicts 2; bfloat16 gave "
      f"{np.median([v['exponent'] for v in _bf16.values()]):.2f})")
