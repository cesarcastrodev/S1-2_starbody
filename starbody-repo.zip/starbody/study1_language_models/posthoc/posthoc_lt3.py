# POST HOC (not part of the pre-registration): Law Test 3's failures, replayed and refitted. CPU only.
# Run in any Colab session: it reads each model's saved files from Drive, writes posthoc_lt3.json and posthoc_lt3.png
# to the Law Test 3 run folder, and changes nothing sealed.
#
# 1. C2: replay every saved escalation ladder with two corrected rules and recompute the law dose:
#      R1 - acceleration checked only where the excess is at least 10x the floor (above the noisy zone)
#      R2 - no acceleration check at all (stop on the budget only)
#    True held-out KL at the replayed dose is extrapolated from the nearest dose that was measured in float32,
#    using the quadratic law (exponent 2.00 in every model), and the extrapolation ratio is reported.
# 2. F1: fit the two-term floor law, bfloat16 KL = floor + (1 + eps) x float32 KL, with one eps per model, and
#    compare (1 + eps) with the matrix's bfloat16 / float32 curvature ratio.
# 3. C3a: calibrate the matrix with the single patches' float32 grids (one factor per model), then score it on the
#    combinations, which the calibration never saw.

import json, math
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import spearmanr

try:
    from google.colab import drive
    drive.mount("/content/drive")
    BASE = Path("/content/drive/MyDrive/Starbody/law_test3")
except ImportError:
    BASE = Path("starbody/law_test3")
MODELS = ["google/gemma-2-2b", "Qwen/Qwen2.5-1.5B", "Qwen/Qwen2.5-3B", "Qwen/Qwen2.5-7B"]
NEEDED = ("design.json", "design_freeze.json", "measurements.json", "fp32.json", "model_result.json")
_runs = [r for r in sorted(BASE.glob("run_*"))
         if all((r / m.split("/")[-1] / f).exists() for m in MODELS for f in NEEDED)]
assert _runs, f"No Law Test 3 run folder under {BASE} holds all four models' saved files."
RUN_ROOT = _runs[-1]
print("Reading", RUN_ROOT)
ACCEL, GUARD = 2.2, 2.0
load = lambda m, f: json.loads((RUN_ROOT / m.split("/")[-1] / f).read_text())

def replay(ladder, excess, floors, tau, rule):
    for i in range(1, len(ladder)):
        for g, e in excess.items():
            if e[i] >= tau:
                return i - 1, f"budget on {g}"
            if rule == "R1":
                lo = 10 * floors[g]
                if e[i - 1] >= lo and lo <= e[i] <= tau / 4:
                    if math.log(e[i] / e[i - 1]) / math.log(ladder[i] / ladder[i - 1]) >= ACCEL:
                        return i - 1, f"acceleration on {g}"
    return len(ladder) - 1, None

def heldout_at(n, s, doses, f32):
    """True held-out KL at dose s, scaled quadratically from the nearest dose measured in float32."""
    cands = [(abs(math.log(s / doses[n][r])), r) for r in ("law", "matrix", "titration", "computed_guard")
             if doses[n][r] > 0 and s > 0]
    if not cands:
        return None, None
    _, r = min(cands)
    ratio = s / doses[n][r]
    return {g: v * ratio ** 2 for g, v in f32[n][r]["heldout"].items()}, ratio

PH = {"note": "post hoc; not part of the pre-registration", "run": str(RUN_ROOT), "models": {}}
SCATTER = []
for m in MODELS:
    design, freeze, meas, f32, res = (load(m, f) for f in NEEDED)
    tau, doses, fdir = freeze["budget"], freeze["doses"], freeze["direction_floors"]
    names = list(freeze["directions"])
    gram = {g: np.array(v) for g, v in design["gram"].items()}
    mon = list(gram)
    out = {"budget": tau, "replay": {}, "two_term": {}, "matrix_calibration": {}}

    # 1. Replay the escalations
    for rule in ("pre-registered", "R1", "R2"):
        rows = {}
        for n in names:
            b = meas[n]["bf16"]
            esc = b["escalation"]
            if "ladder" not in esc:
                rows[n] = {"dose": 0.0, "trigger": esc.get("trigger"), "worst_over_tau": 0.0, "in_budget": True,
                           "extrapolation": None}
                continue
            if rule == "pre-registered":
                s, trig = doses[n]["law"], esc["trigger"]
            else:
                i_stop, trig = replay(esc["ladder"], esc["excess"], fdir[n], tau, rule)
                s = min(b["certificate"], esc["ladder"][i_stop])
            ho, ratio = heldout_at(n, s, doses, f32)
            worst = max(ho.values()) / tau if ho else 0.0
            rows[n] = {"dose": s, "trigger": trig, "worst_over_tau": worst,
                       "in_budget": bool(ho and all(v <= tau for v in ho.values())), "extrapolation": ratio}
        pairs = [v <= tau for n in names for v in (heldout_at(n, rows[n]["dose"], doses, f32)[0] or {}).values()]
        out["replay"][rule] = {
            "directions": rows,
            "coverage": float(np.mean(pairs)) if pairs else float("nan"),
            "not_hollow": float(np.mean([rows[n]["worst_over_tau"] >= 1 / 8 for n in names])),
            "triggers": sum(1 for n in names if rows[n]["trigger"] and "acceleration" in str(rows[n]["trigger"])),
            "max_extrapolation": max((max(r["extrapolation"], 1 / r["extrapolation"]) for r in rows.values()
                                      if r["extrapolation"]), default=None)}

    # 2. The two-term floor law
    eps_curve, acc_curve, one_f, two_f = {}, {}, [], []
    for i, n in enumerate(names):
        s = np.array(meas[n]["bf16"]["grid"])
        for g in mon:
            k16, k32, fl = np.array(meas[n]["bf16"]["kl"][g]), np.array(f32[n]["grid_kl"][g]), fdir[n][g]
            hi = (k32 >= 4 * fl) & (k32 >= 1e-8)
            if hi.sum() >= 2:
                eps_curve[(n, g)] = float(np.median((k16[hi] - fl) / k32[hi]) - 1)
            use = (k32 >= 1e-8) & (k32 <= tau / 4)
            if use.sum() >= 2:
                acc_curve[(n, g)] = float(0.5 * gram[g][i, i] / np.median(k32[use] / s[use] ** 2))
    eps_model = float(np.median(list(eps_curve.values()))) if eps_curve else 0.0
    for i, n in enumerate(names):
        for g in mon:
            k16, k32, fl = np.array(meas[n]["bf16"]["kl"][g]), np.array(f32[n]["grid_kl"][g]), fdir[n][g]
            ok = k32 >= 1e-8
            if ok.sum():
                one_f.append(float(np.exp(np.median(np.abs(np.log(np.maximum(k16[ok], 1e-30) / (fl + k32[ok])))))))
                two_f.append(float(np.exp(np.median(np.abs(np.log(np.maximum(k16[ok], 1e-30) /
                                                                  (fl + (1 + eps_model) * k32[ok])))))))
    common = [k for k in eps_curve if k in acc_curve]
    rho = (float(spearmanr([1 + eps_curve[k] for k in common], [acc_curve[k] for k in common]).correlation)
           if len(common) >= 3 else float("nan"))
    calib = float(np.median(list(acc_curve.values()))) if acc_curve else 1.0
    out["two_term"] = {"eps": eps_model, "F1_one_term": float(np.mean([f <= 1.25 for f in one_f])),
                       "F1_two_term": float(np.mean([f <= 1.25 for f in two_f])),
                       "matrix_over_measured": calib, "spearman_inflation_vs_matrix": rho}
    SCATTER += [(m, 1 + eps_curve[k], acc_curve[k]) for k in common]

    # 3. The matrix, calibrated on single-patch grids, scored on combinations it never saw
    def scores(factor, which):
        ok = []
        for c in freeze["combinations"]:
            if which == "singles":
                continue
            w = np.array(c["weights"])
            for g in mon:
                p = max(0.5 * c["dose"] ** 2 * float(w @ gram[g] @ w), 1e-30) / factor
                ok.append(abs(f32[c["name"]]["monitor"][g] / p - 1) <= 0.25)
        if which != "combinations":
            for i, n in enumerate(names):
                for g in mon:
                    p = max(0.5 * doses[n]["matrix"] ** 2 * gram[g][i, i], 1e-30) / factor
                    ok.append(abs(f32[n]["matrix"]["monitor"][g] / p - 1) <= 0.25)
        return float(np.mean(ok)) if ok else float("nan")
    out["matrix_calibration"] = {"factor": calib, "C3a_raw_all": scores(1.0, "all"),
                                 "C3a_raw_combinations": scores(1.0, "combinations"),
                                 "C3a_calibrated_combinations": scores(calib, "combinations")}
    PH["models"][m] = out

(RUN_ROOT / "posthoc_lt3.json").write_text(json.dumps(PH, indent=1, default=str))

print("\nPOST HOC (not pre-registered; the sealed verdict is unchanged)\n")
print("1. C2 replay: law dose with corrected acceleration rules (true held-out KL extrapolated quadratically)")
print(f"{'model':<14}{'rule':<16}{'coverage':>10}{'not hollow':>12}{'triggers':>10}{'max extrapolation':>19}")
for m, v in PH["models"].items():
    for rule, r_ in v["replay"].items():
        print(f"{m.split('/')[-1]:<14}{rule:<16}{r_['coverage']:>10.0%}{r_['not_hollow']:>12.0%}{r_['triggers']:>10}"
              f"{(r_['max_extrapolation'] or float('nan')):>18.2f}x")
print("\n2. The two-term floor law: bfloat16 = floor + (1 + eps) x float32")
print(f"{'model':<14}{'eps':>8}{'F1 one-term':>13}{'F1 two-term':>13}{'matrix/measured':>17}{'Spearman':>10}")
for m, v in PH["models"].items():
    t = v["two_term"]
    print(f"{m.split('/')[-1]:<14}{t['eps']:>+8.3f}{t['F1_one_term']:>13.0%}{t['F1_two_term']:>13.0%}"
          f"{t['matrix_over_measured']:>17.3f}{t['spearman_inflation_vs_matrix']:>10.2f}")
print("\n3. The matrix, calibrated on single-patch grids, scored on the combinations (within 25%)")
for m, v in PH["models"].items():
    c = v["matrix_calibration"]
    print(f"  {m.split('/')[-1]:<14} factor {c['factor']:.3f} | combinations raw {c['C3a_raw_combinations']:.0%} -> "
          f"calibrated {c['C3a_calibrated_combinations']:.0%} | raw, all patches {c['C3a_raw_all']:.0%}")

fig, ax = plt.subplots(1, 3, figsize=(19, 5.4))
for j, m in enumerate(MODELS):
    for k, (rule, mk) in enumerate((("pre-registered", "o"), ("R1", "s"), ("R2", "^"))):
        rows = PH["models"][m]["replay"][rule]["directions"]
        ax[0].scatter([j + 0.22 * (k - 1)] * len(rows), [max(r["worst_over_tau"], 1e-3) for r in rows.values()],
                      marker=mk, s=22, label=rule if j == 0 else None, color=("#888888", "#C44E52", "#4C72B0")[k])
ax[0].axhline(1, color="k", ls=":", lw=1); ax[0].axhline(1 / 8, color="grey", ls=":", lw=1)
ax[0].set_xticks(range(4)); ax[0].set_xticklabels([m.split("/")[-1] for m in MODELS], fontsize=8)
ax[0].set(yscale="log", title="C2 replay: worst true held-out KL / budget at the law dose", ylabel="ratio")
ax[0].legend(fontsize=8)
for m, col in zip(MODELS, ("#C44E52", "#4C72B0", "#55A868", "#8172B3")):
    pts = [(a, b) for mm, a, b in SCATTER if mm == m]
    if pts:
        ax[1].scatter([p[0] for p in pts], [p[1] for p in pts], s=16, color=col, label=m.split("/")[-1])
ax[1].plot([0.8, 1.6], [0.8, 1.6], "k:", lw=1)
ax[1].set(title="Inflation in measurement vs in the matrix", xlabel="1 + eps (bfloat16 excess / float32)",
          ylabel="bfloat16 curvature / float32 curvature")
ax[1].legend(fontsize=8)
for j, m in enumerate(MODELS):
    c = PH["models"][m]["matrix_calibration"]
    ax[2].bar(j - 0.2, c["C3a_raw_combinations"], 0.4, color="#BBBBBB", label="raw" if j == 0 else None)
    ax[2].bar(j + 0.2, c["C3a_calibrated_combinations"], 0.4, color="#55A868", label="calibrated" if j == 0 else None)
ax[2].axhline(0.8, color="k", ls=":", lw=1)
ax[2].set_xticks(range(4)); ax[2].set_xticklabels([m.split("/")[-1] for m in MODELS], fontsize=8)
ax[2].set(ylim=(0, 1.05), title="Matrix on combinations, within 25%: raw vs calibrated", ylabel="share")
ax[2].legend(fontsize=8)
plt.tight_layout()
fig.savefig(RUN_ROOT / "posthoc_lt3.png", dpi=130)
plt.show()
