# Checkpoints

The trained update rules, so 0.4a and 0.4b can run without retraining. Each file holds `{"model": state_dict, "iteration": n}`.

| File | Written by | Arm |
| --- | --- | --- |
| `nca_voltage_rule0.pt` to `nca_voltage_rule2.pt` | substrate 0.3, 3 November 2026 | voltage (prepattern imposed) |
| `nca_form_only_rule0.pt` to `nca_form_only_rule2.pt` | substrate 0.3, 3 November 2026 | form-only |
| `nca_form_only_long_rule0.pt` to `nca_form_only_long_rule2.pt` | substrate 0.4a section E, 5 November 2026 | form-only, longer training |

In Colab, the notebooks read and write them under `MyDrive/Starbody/cybermorphic/`: 0.3 in `nca_worm_v3/`, 0.4a's longer training in `nca_worm_v4/`. 0.4a reads the first six from `nca_worm_v3/` (its `SRC`).
