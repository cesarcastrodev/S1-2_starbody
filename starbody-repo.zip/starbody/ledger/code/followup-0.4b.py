# ======================================================================================================================
# Cybermorphic substrate 0.4b · follow-ups in the live 0.4a session
#
# Paste this whole file into ONE new cell at the end of the 0.4a notebook, in the session that ran it, and run it.
# It reuses that session's MODELS, BASIS, W_CURVES and every helper; nothing is reloaded or retrained.
# Predictions R1-R5 are stated below, hashed and saved before anything runs; the plan is sealed in the ledger.
# Roughly 15-25 minutes on the L4. Each block saves partial_<block>.json as it finishes.
# ======================================================================================================================
import hashlib, json, math, time
import numpy as np
import torch
from scipy.stats import spearmanr

FOLLOW = {
    "version": "cybermorphic substrate 0.4b: follow-ups in the 0.4a session",
    "reuses": "the 0.4a session's rules, basis and helpers; nothing is retrained",
    "replication": "one helper applies the plan's rule everywhere: PASS in at least 2 of 3 rules, FAIL in at least 2, else NOT ASSESSABLE (R5 states its own, stricter rule)",
    "predictions": {
        "R1": ("the plasticity window closes: a pulse delivered at increasing delays after a trunk cut, and in the adult, "
               "needs a rising dose to return half of acquired two-headed worms. Judged on the negative read direction: "
               "Spearman rho >= 0.6 between delay (adult last) and exit v50 (no exit counted as infinite), in at least 2 of 3 rules"),
        "R2": ("a certificate measured against each worm's own untreated twin under the same noise reaches >= 1/4 of the "
               "first change dose, with the 95% upper bound on the change rate below 5% on 128 fresh worms, in at least 2 of 3 rules"),
        "R3": ("under clinical noise, the same certificate bounding the EXCESS over spontaneous discordance (two untreated "
               "runs with independent noise) also reaches >= 1/4 of the first change dose, in at least 2 of 3 rules"),
        "R4": ("with exposure and outcome taken from the same trajectory, whole-body exposure over the first 80 steps "
               "separates worms that change from worms that don't at a fixed dose near the edge, with a within-rung AUC "
               "averaging >= 0.9, in at least half the rule-and-direction pairs with two or more scorable rungs"),
        "R5": ("each worm's own monitor: a stop at the rung before its own exposure first accelerates past a local exponent "
               "of 2.5 lands below that worm's own first change, for at least 90% of worms, in every rule"),
    },
}
FOLLOW_HASH = hashlib.sha256(json.dumps(FOLLOW, sort_keys=True).encode()).hexdigest()
(ROOT / "plan_0.4b.json").write_text(json.dumps(FOLLOW, indent=1))
print("0.4b plan", FOLLOW_HASH[:12], "| GPU", GPU, "| TF32", torch.backends.cudnn.allow_tf32)
set_tf32(True)                                            # the 0.3 and 0.4a conditions
VB, T0 = {}, time.time()

def replicate(per_rule):
    vs = list(per_rule)
    return "PASS" if vs.count("PASS") >= 2 else "FAIL" if vs.count("FAIL") >= 2 else "NOT ASSESSABLE"

# ---------------------------------------------------------------------------------------------------------------------
# R1 · when does the plasticity window close?
# ---------------------------------------------------------------------------------------------------------------------
@torch.no_grad()
def timed_exit(m, base, direction, doses, delay, seed, crn=True):
    """Acquired two-headed worms. A pulse along `direction` for k_write steps, starting `delay` steps after a trunk cut
    (delay None: in the intact adult). Regrowth then completes, then washout, then a second trunk cut and regrowth, so
    the form is read from tissue regrown after the write ended. Row 0 is an untreated control under the same noise."""
    n = base.shape[0]
    ms = seed if crn else None
    rows, ctrl = [], []
    for g in chunks(np.asarray(doses, dtype=np.float64), n):
        dz = np.concatenate([[0.0], g]); D = len(dz); tile = D if crn else 1
        x = base.repeat(D, 1, 1, 1)
        inj = write_map(direction, np.repeat(dz, n))
        if delay is None:
            x = run(m, x, S["k_write"], inject=inj, k_write=S["k_write"], tile=tile, crn=crn, mask_seed=ms)
            t = S["k_write"]
        else:
            x = amputate(x, "trunk"); t = 0
            if delay > 0:
                x = run(m, x, delay, tile=tile, crn=crn, mask_seed=ms); t = delay
            x = run(m, x, S["k_write"], inject=inj, k_write=S["k_write"], tile=tile, crn=crn, mask_seed=ms, t0=t)
            t += S["k_write"]
            rest = max(S["regrow"] - delay - S["k_write"], 0)
            if rest:
                x = run(m, x, rest, tile=tile, crn=crn, mask_seed=ms, t0=t); t += rest
        x = run(m, x, S["washout"], tile=tile, crn=crn, mask_seed=ms, t0=t); t += S["washout"]
        lab = classes(run(m, amputate(x, "trunk"), S["regrow"], tile=tile, crn=crn, mask_seed=ms, t0=t)).reshape(D, n)
        rows.append(lab[1:] == "one_head"); ctrl.append(float(np.mean(lab[0] == "one_head")))
    return np.concatenate(rows, 0), float(np.mean(ctrl))

@torch.no_grad()
def regrowth_progress(m, base, delays, seed):
    """How much of the intact posterior has regrown at each delay after a trunk cut, from 0 to 1."""
    ref = float(((base[:, 3:4] > 0.1).float() * WRITE).sum().item()) / base.shape[0]
    torch.manual_seed(seed)
    x, t, out = amputate(base.clone(), "trunk"), 0, {}
    for d in delays:
        if d > t:
            x = run(m, x, d - t, crn=False); t = d
        out[d] = float(((x[:, 3:4] > 0.1).float() * WRITE).sum().item()) / base.shape[0] / max(ref, 1e-9)
    return out

DELAYS = [0, 10, 25, 50, 100, 200, 350, 480] if not S.get("smoke_followup") else [0, 4, 8]
R1_RES, R1_PER = {}, []
for k in range(S["rules"]):
    t_rule = time.time()
    MV, vs = MODELS[k]["voltage"], BASIS[k]["v_switch"]
    two = acquired_two_heads(MV, S["n_dev"], 24, 1.25 * vs, E_VOLT)
    doses = vs * 2.0 ** np.linspace(-4, 6, 11 if not S.get("smoke_followup") else 4)
    rd = BASIS[k]["read_direction"]
    per = {"cohort": int(two.shape[0]), "doses": doses, "regrowth": regrowth_progress(MV, two, DELAYS, seed=92)}
    for dn, dv in (("read-", -rd), ("volt-", -E_VOLT)):
        cur = {}
        for delay in DELAYS + [None]:
            got, ctrl = timed_exit(MV, two, dv, doses, delay, seed=91)
            sh = got.mean(1)
            v50 = threshold(doses, sh, 0.5)
            cur["adult" if delay is None else str(delay)] = {"share": sh, "control": ctrl, "v50": v50,
                                                              "exit_cost": (v50 / vs) if v50 else None, "peak": float(sh.max())}
        keys = [str(d) for d in DELAYS] + ["adult"]
        y = np.array([cur[kk]["v50"] if cur[kk]["v50"] else np.inf for kk in keys])
        rho = float(spearmanr(np.arange(len(keys)), y).correlation) if (np.isfinite(y).sum() >= 1 and len(set(y.tolist())) > 1) else None
        per[dn] = {"timing": cur, "spearman_delay_v50": rho}
        print(f"rule {k} {dn}: exit cost by delay " +
              ", ".join(f"{kk}:{'-' if cur[kk]['exit_cost'] is None else round(cur[kk]['exit_cost'], 2)}" for kk in keys) +
              f" | rho {rho}")
    R1_RES[k] = per
    r = per["read-"]["spearman_delay_v50"]
    R1_PER.append(verdict(r >= 0.6, True) if r is not None else verdict(False, False))
    print(f"  rule {k} done in {(time.time() - t_rule) / 60:.1f} min; regrowth by delay {per['regrowth']}")
VB["R1"] = replicate(R1_PER)
print("R1", VB["R1"], R1_PER)
snapshot("R1", R1_RES)

# ---------------------------------------------------------------------------------------------------------------------
# R2 and R3 · the certificate, against the right control
# ---------------------------------------------------------------------------------------------------------------------
def certify(ladder, ks, n, disc=None):
    """The largest dose such that every rung at or below it keeps the 95% upper bound under 5%: on the change rate
    itself, or with disc=(k0, n0), on the excess over spontaneous discordance."""
    cert = None
    for j in range(len(ladder)):
        up = wilson(int(ks[j]), n)[1] - (wilson(disc[0], disc[1])[0] if disc else 0.0)
        if up >= 0.05:
            break
        cert = float(ladder[j])
    return cert

R2_RES, R2_PER, R3_PER = {}, [], []
for k in range(S["rules"]):
    t_rule = time.time()
    MV, v_change = MODELS[k]["voltage"], BASIS[k]["v_change"]
    ladder = v_change * 2.0 ** (np.arange(-12, 3) * 0.5)
    cal = adults_of(MV, 0, S["n_cal"], seed=31)
    ver = adults_of(MV, 0, S["n_ver"], seed=70)
    res = {"v_change": v_change, "ladder": ladder}
    # R2: each worm against its own untreated twin, under the same noise: the change the dose caused
    cc = switch_curve(MV, 0, E_VOLT, ladder, len(cal), seed=31, base=cal, crn=True)
    ks = cc["changed"].sum(1); n = cc["changed"].shape[1]
    cert = certify(ladder, ks, n)
    res["paired"] = {"rates": ks / n, "certified": cert, "share": (cert / v_change) if cert else None}
    if cert:
        vc = switch_curve(MV, 0, E_VOLT, [cert], len(ver), seed=8, base=ver, crn=True)
        kv = int(vc["changed"].sum())
        res["paired"]["verification"] = {"changed": kv, "n": len(ver), "upper95": wilson(kv, len(ver))[1], "latent": int(vc["latent"].sum())}
    ok = bool(cert and cert >= v_change / 4 and res["paired"]["verification"]["upper95"] < 0.05)
    R2_PER.append(verdict(ok))
    # R3: clinical noise; a dose-0 rung against the control measures spontaneous discordance, and the bound is on the excess
    cn = switch_curve(MV, 0, E_VOLT, np.concatenate([[0.0], ladder]), len(cal), seed=32, base=cal, crn=False)
    kn = cn["changed"].sum(1); disc = (int(kn[0]), n)
    cert_n = certify(ladder, kn[1:], n, disc)
    res["clinical_noise"] = {"discordance": kn[0] / n, "rates": kn[1:] / n, "certified": cert_n,
                             "share": (cert_n / v_change) if cert_n else None}
    if cert_n:
        vn = switch_curve(MV, 0, E_VOLT, [0.0, cert_n], len(ver), seed=9, base=ver, crn=False)
        k0, k1 = int(vn["changed"][0].sum()), int(vn["changed"][1].sum())
        res["clinical_noise"]["verification"] = {"changed": k1, "discordance": k0, "n": len(ver),
                                                 "excess_upper95": wilson(k1, len(ver))[1] - wilson(k0, len(ver))[0]}
    ok_n = bool(cert_n and cert_n >= v_change / 4 and res["clinical_noise"]["verification"]["excess_upper95"] < 0.05)
    R3_PER.append(verdict(ok_n))
    R2_RES[k] = res
    print(f"rule {k} ({(time.time() - t_rule) / 60:.1f} min): paired certificate {res['paired']['share']} of the first change; "
          f"under clinical noise {res['clinical_noise']['share']} (discordance {res['clinical_noise']['discordance']:.3f})")
VB["R2"], VB["R3"] = replicate(R2_PER), replicate(R3_PER)
print("R2", VB["R2"], R2_PER, "| R3", VB["R3"], R3_PER)
snapshot("R2_R3", R2_RES)

# ---------------------------------------------------------------------------------------------------------------------
# R4 and R5 · exposure and outcome from the same trajectory
# ---------------------------------------------------------------------------------------------------------------------
@torch.no_grad()
def paired_trajectories(m, base, direction, doses, seed, crn=True):
    """Each written worm runs beside its own untreated twin under identical noise, so exposure (whole-body, first
    e1_steps) and outcome (any readout differing from the twin's) come from ONE trajectory. With crn a worm also meets
    the same noise at every dose; without, every (worm, dose) pair has noise of its own."""
    n = base.shape[0]
    expo, chg, lat = [], [], []
    for ci, g in enumerate(chunks(np.asarray(doses, dtype=np.float64), 2 * n)):
        D = len(g)
        x = torch.cat([base.repeat(D, 1, 1, 1), base.repeat(D, 1, 1, 1)])
        inj = torch.cat([write_map(direction, np.repeat(g, n)), torch.zeros(D * n, CH, H, W, device=DEV)])
        acc = torch.zeros(D * n, device=DEV, dtype=torch.float64)
        def mk(t):
            if crn:
                b = _mask(n, t, seed, x.dtype)[0].repeat(D, 1, 1, 1)
            else:
                torch.manual_seed((seed * 7919 + ci * 104729 + t) % (2 ** 31))
                b = (torch.rand(D * n, 1, H, W, device=DEV, dtype=torch.float32) <= FIRE).to(x.dtype)
            return torch.cat([b, b])
        lab, T = {}, S["k_write"] + S["washout"]
        for t in range(T):
            x = step(m, x, mk(t), inj if t < S["k_write"] else None)
            if t < S["e1_steps"]:
                d2 = (x[:D * n, :4].double() - x[D * n:, :4].double()) ** 2
                acc += (d2 * BODY.double()).sum(dim=(1, 2, 3)) / (BODY.sum().double() * 4)
            if t == S["k_write"] - 1:
                lab["on_drug"] = classes(x)
        lab["washout"] = classes(x)
        for name, cut in (("regrown_with_written", "both"), ("regenerated", "trunk")):
            y = amputate(x, cut)
            for t in range(S["regrow"]):
                y = step(m, y, mk(T + t))
            lab[name] = classes(y)
        ch, vis = np.zeros((D, n), bool), np.zeros((D, n), bool)
        for r_ in READOUTS:
            dif = lab[r_][:D * n].reshape(D, n) != lab[r_][D * n:].reshape(D, n)
            ch |= dif
            if r_ in ("on_drug", "washout"):
                vis |= dif
        expo.append((acc / S["e1_steps"]).reshape(D, n).cpu().numpy()); chg.append(ch); lat.append(ch & ~vis)
    return {"exposure": np.concatenate(expo, 0), "changed": np.concatenate(chg, 0), "latent": np.concatenate(lat, 0)}

R4_RES, R5_RES, R4_AUCS, R5_PER = {}, {}, [], []
for k in range(S["rules"]):
    t_rule = time.time()
    MV = MODELS[k]["voltage"]
    sur = adults_of(MV, 0, S["n_sur"], seed=44)
    dev = adults_of(MV, 0, 2 * S["n_dev"], seed=45)
    shares = []
    for dn, dv in (("volt+", E_VOLT), ("volt-", -E_VOLT)):
        wc = W_CURVES[k].get(dn, {})
        if wc.get("edge_index") is None:
            continue
        fine, e = np.asarray(wc["doses"]), int(wc["edge_index"])
        # R4: the surrogate, without common random numbers so worms differ, at the 7 rungs around the edge
        near = fine[max(e - 3, 0): max(e - 3, 0) + 7]
        pt = paired_trajectories(MV, sur, dv, near, seed=101, crn=False)
        per_rung, rung_d = [], []
        for j in range(len(near)):
            cg, ex = pt["changed"][j], pt["exposure"][j]
            if int(cg.sum()) >= 2 and int((~cg).sum()) >= 2:
                per_rung.append(auc(ex[cg], ex[~cg])); rung_d.append(float(near[j]))
        a = float(np.mean(per_rung)) if len(per_rung) >= 2 else None
        if a is not None:
            R4_AUCS.append(a)
        R4_RES[f"{k}|{dn}"] = {"auc": a, "per_rung": per_rung, "rung_doses": rung_d, "changed_share": pt["changed"].mean(1)}
        # R5: each worm's own monitor, with common random numbers so each worm's curve is its own
        pt5 = paired_trajectories(MV, dev, dv, fine, seed=102, crn=True)
        ok, ev, leads = 0, 0, []
        for i in range(dev.shape[0]):
            hits = np.nonzero(pt5["changed"][:, i])[0]
            if len(hits) == 0:
                continue
            first, ev = int(hits[0]), ev + 1
            wi = first_warning(fine, pt5["exposure"][:, i], 2.5, 1)
            if wi is not None and wi - 1 < first:
                ok += 1; leads.append(float(fine[first] / fine[wi - 1]))
        share = ok / ev if ev else None
        if share is not None:
            shares.append(share)
        R5_RES[f"{k}|{dn}"] = {"worms_evaluated": ev, "stopped_in_time": ok, "share": share,
                               "lead_median": float(np.median(leads)) if leads else None,
                               "lead_min": float(min(leads)) if leads else None}
        print(f"rule {k} {dn}: surrogate AUC {a} on {len(per_rung)} rungs | own monitor in time for {ok}/{ev} worms")
    R5_PER.append(verdict(bool(shares) and min(shares) >= 0.9, bool(shares)))
    print(f"  rule {k} done in {(time.time() - t_rule) / 60:.1f} min")
VB["R4"] = verdict(bool(R4_AUCS) and sum(a >= 0.9 for a in R4_AUCS) >= max(1, (len(R4_AUCS) + 1) // 2), bool(R4_AUCS))
VB["R5"] = "PASS" if R5_PER and all(v == "PASS" for v in R5_PER) else ("NOT ASSESSABLE" if all(v == "NOT ASSESSABLE" for v in R5_PER) else "FAIL")
print("R4", VB["R4"], [round(a, 2) for a in R4_AUCS], "| R5", VB["R5"], R5_PER)
snapshot("R4_R5", {"R4": R4_RES, "R5": R5_RES})

# ---------------------------------------------------------------------------------------------------------------------
# verdicts, a figure, and the results file
# ---------------------------------------------------------------------------------------------------------------------
for q in sorted(FOLLOW["predictions"]):
    print(f"{q}: {VB.get(q, 'NOT RUN'):<15} {FOLLOW['predictions'][q][:110]}...")
fig, ax = plt.subplots(1, 3, figsize=(18, 5))
for k in R1_RES:
    keys = [str(d) for d in DELAYS] + ["adult"]
    for dn, ls in (("read-", "o-"), ("volt-", "s--")):
        cost = [R1_RES[k][dn]["timing"][kk]["exit_cost"] for kk in keys]
        ax[0].plot(range(len(keys)), [c if c else np.nan for c in cost], ls, label=f"rule {k} {dn}")
        miss = [i for i, c in enumerate(cost) if c is None]
        ax[0].plot(miss, [70] * len(miss), "x", color=ax[0].lines[-1].get_color())
ax[0].set_xticks(range(len(DELAYS) + 1)); ax[0].set_xticklabels([str(d) for d in DELAYS] + ["adult"])
ax[0].set_yscale("log"); ax[0].legend(fontsize=7)
ax[0].set(title=f"R1: exit cost by timing of the write · {VB['R1']} (x: no exit)", xlabel="steps after the cut", ylabel="exit v50 / switching dose")
for i, (lab, key) in enumerate((("paired", "paired"), ("clinical noise", "clinical_noise"))):
    vals = [R2_RES[k][key]["share"] or 0 for k in R2_RES]
    ax[1].bar(np.arange(len(vals)) + (i - 0.5) * 0.4, vals, 0.4, label=lab)
ax[1].axhline(0.25, color="k", ls=":", label="useful: 1/4 of the edge")
ax[1].set(title=f"R2 {VB['R2']} · R3 {VB['R3']}: certified dose / first change", xlabel="rule"); ax[1].legend(fontsize=7)
txt = [f"0.4b plan {FOLLOW_HASH[:12]}", ""] + [f"{q}: {VB.get(q)}" for q in sorted(FOLLOW["predictions"])] + [""]
txt += [f"R4 {kk}: AUC {v['auc']}" for kk, v in R4_RES.items()]
txt += [f"R5 {kk}: {v['stopped_in_time']}/{v['worms_evaluated']} in time, median lead {v['lead_median']}" for kk, v in R5_RES.items()]
ax[2].axis("off"); ax[2].text(0, 0.98, "\n".join(txt), va="top", family="monospace", fontsize=8)
plt.tight_layout(); fig.savefig(ROOT / "followup_0.4b.png", dpi=110); plt.show()
(ROOT / "results_0.4b.json").write_text(json.dumps(_clean({
    "plan_sha256": FOLLOW_HASH, "gpu": GPU, "predictions": VB, "minutes": (time.time() - T0) / 60,
    "R1": R1_RES, "R2_R3": R2_RES, "R4": R4_RES, "R5": R5_RES}), indent=1))
print(f"saved results_0.4b.json and followup_0.4b.png to {ROOT} ({(time.time() - T0) / 60:.1f} min)")
