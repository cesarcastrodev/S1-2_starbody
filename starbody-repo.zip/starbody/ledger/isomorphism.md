# Isomorphic attention

**The principle.** Notice the same structure in two domains, then check the correspondence term by term, with predictions stated before the check. Until it's checked, a correspondence is an instrument we're borrowing, not a finding.

## Rules

1. **Every borrowed term carries a status.**
   - **Tested:** a prediction made in one domain held in the other.
   - **Operational:** used as an instrument; whether it transfers is untested.
   - **Vocabulary:** a name that organizes thinking, with no measurement behind it.
   - **Imposed:** built into the substrate that tests it. It can be shown causal there, never discovered there.
2. **Constants don't cross a mechanism boundary unrecalibrated.** The PK test showed that calibration transfers within a mechanism class, not across. Guards, thresholds and grade cutoffs are recomputed in each new mechanism.
3. **A correspondence isn't tested on a substrate built to contain it.** If a design imposes it, the design says so, and adds an arm where it has to be found.
4. **Coverage needs a usefulness floor.** A certificate that covers everything by certifying almost nothing has passed nothing. The PK test "passed" twice that way, at 3% and 5% of the true range.
5. **Rules that judge noisy data must know the noise, and must be tested under it.** The PK test's stopping rule tripped on between-subject variability. In silico, common random numbers isolate the dose effect: each individual sees the same noise at every dose. But they remove exactly the noise clinics face, so every instrument meant for pharmacology runs both ways: with common random numbers, to find the true effect, and without, to see how it performs under clinical noise.
6. **Lean into the source field's instrumental limits.** A correspondence is worth most where pharmacology's own instruments are weakest. Our substrates allow what clinical studies can't:
   - paired twins: the same individual, with and without the intervention, under the same noise;
   - every organ measured, in every individual;
   - escalation past the edge, then exact washout;
   - each individual's own dose–response curve.

   The isomorphism then runs both ways: pharmacology lends its instruments, and the substrates test and repair them (S12).

## The table

| Pharmacology | Starbody | Status | Pharmacology's limit | Where it's tested |
|---|---|---|---|---|
| Dose–response | Quadratic law: exposure grows with dose squared | **Tested in a second domain:** exponent 2.00–2.05 in float32, from the lowest dose to the edge, in three growing automata (0.4a) | None at issue | Done; next, the third domain |
| Blank and assay floor | Two floors: stochastic firing (unpaired) and rounding (paired) | **Tested:** the TF32 rounding floor falls at least 2,900–4,200× in float32; and the two floors add as variances, within 3–8% — the bfloat16 structure again (0.4a, post hoc) | None at issue | The point prediction (~6.7 × 10⁷) needs a probe below 10⁻⁴ |
| Phase I escalation under monitoring | Certify-and-monitor | **Usefulness restored where noise allows:** anchored to the outcome, the certified dose reached 71% of the edge in the rule with no spontaneous discordance, and nothing where discordance was 3–5% — the PK stopping failure, reproduced inside the certificate (0.4a) | Stopping rules trip on between-subject noise | Substrate 0.4b (R2, R3): against each worm's own twin, and against the excess over discordance |
| Safety factor | Guard of 2 | **Crosses, roughly:** as a tolerance bound the guard is 2.0 and 2.8 (0.4a), around the borrowed 2. 0.3's "does not cross" came from a maximum over 32 worms and is retracted | Calibration doesn't cross mechanisms (PK test) | Tested; the PK lesson did not transfer here |
| Exposure as a surrogate | KL; whole-body change in the substrate | Operational: 0.4a's test took exposure and outcome from separate runs, so it could not answer | A surrogate can look safe while the outcome changes, as in the CAST trial | GR-1; substrate 0.4b (R4), with both from one trajectory |
| Toxicity grades (CTCAE) | Organ panels graded 0–4 | Operational: the cutoffs are ours | Grades describe severity; they aren't calibrated risks | GR; in the substrate, limits from healthy cohorts and grades on the excess over them |
| Adverse-reaction types A–F | S11 | Vocabulary | None at issue | GR, then S11's route |
| Symptomatic against disease-modifying | A patch acts while applied; an attractor write persists | **Reversed, and confirmed against an inert sham:** at one clamp level 100% of worms switch persistently and 0% visibly, in all three rules; visible change appears only in a narrow band inside the persistent range (0.4a) | Delayed-start and randomized-withdrawal designs are slow and often ambiguous | Done in the substrate; the clinical analogue is a disease-modifying effect with no on-treatment sign |
| Tolerance, dependence, discontinuation | Hysteresis and exit cost | **Measured:** exits exist in every rule. In the intact adult they cost 1.4–64× the entry dose (median 8), and in one rule none of eight protocols works; during regeneration they cost 0.18–2.8× (median 1.2). 14 of 15 exits are windows (0.4a) | Withdrawal is scored by symptom scales, drug by drug; there's no common measure of the cost of leaving | Substrate 0.4b (R1): when the window of plasticity closes |
| Individual against population dosing | Each worm's own threshold, against a population dose set on another cohort | **First measurement:** thresholds within one dose step; the variation is between rules (1.4×), not within a rule. A population of clones has no dosing problem | Individual curves are rarely observable: no patient is both treated and untreated at once | Substrate 0.4: variation sought between rules and under clinical noise |
| Bioelectric prepattern (Levin) | Channel 4 in the voltage arm | **Imposed, and so far only robust where imposed:** the form-only arm was not bistable in any of the three rules, so P8 could not be asked | None at issue | Substrate 0.4, arm E: the form-only arm trained longer before P8 is asked again |

Rows change as results arrive. Each change is sealed, like any other file here.

A seventh rule came out of reviewing substrate 0.2:

7. **Persistence is tested where the dose never reached.** A change that survives only in tissue that received the write may be a depot, not a new attractor. Persistence is judged in what regrows from tissue that was never written, and every check counts latent changes, which appear only after a challenge.

Two rules came out of the first run of substrate 0.3:

8. **A window is measured where it is not itself noise.** The quadratic law held in the 0.3 run at exponent 2.06–2.10, yet the prediction that tested it failed, because its window ran from budget/100 upward while the budget was only 10× a noise floor. Every window stated in advance is checked against the floors it will be measured over, before it is sealed.

9. **A budget anchored to noise is not a budget.** A limit set as a multiple of an assay floor says nothing about the outcome it is meant to prevent. The 0.3 certificate covered everything and certified 1% of the usable range. Budgets are anchored to the outcome, on a calibration cohort, and the noise floor is reported beside them rather than used as their unit.

A tenth rule came out of the 0.4a run:

10. **A control exists where the intervention acts.** A clamp that records its baseline before the tissue it acts on has grown is not a sham at zero; it is a clamp to zero. In 0.4a, two regeneration clamps' "untreated" rows returned every worm. A control is defined on the same tissue, at the same time, as the treatment it controls.
