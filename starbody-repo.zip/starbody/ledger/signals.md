# Signals: what to chase, boldly

Gates judge claims, not ideas. Each signal below is worth pursuing hard in exploration. None of it is claimed until it passes the gate named under it.

## S1 · The floor is predictable
**Evidence:** the bfloat16 floor rises with the activation outlier ratio (largest value / 99.9th percentile) across all four models:

| Model | Outlier ratio | Floor (nats) |
|---|---|---|
| Gemma-2-2B | 58× | 1.7e-4 |
| Qwen2.5-1.5B | 140× | 3.8e-4 |
| Qwen2.5-3B | 137× | 4.5e-4 |
| Qwen2.5-7B | 612× | 9.5e-3 |

Gemma's float16 floor was 60.6× lower, against 64× predicted.

**Claim:** a single forward pass's activation statistics predict a model's floor within a factor of 2, before any measurement.
**Route:** predictions for V-M1, sealed before G2 runs them.
**Kill criterion:** off by more than 2× in 2 or more of the 4 models.

## S2 · Selective precision removes the floor
**Evidence:** precision is the lever (Gemma's float16 result), and the floor tracks the outliers.
**Claim:** keeping the residual-stream additions, or only the outlier channels, in float32 removes at least 90% of the bfloat16 floor, at no more than 15% extra memory and time.
**Why it matters:** this would be an engineering contribution in its own right. Small budgets would become certifiable on large models, and it bears on every low-precision deployment.
**Route:** exploration on Qwen2.5-7B, which has the largest floor, then a gate on V-M1.
**Kill criterion:** less than 50% reduction, or more than 30% overhead.

## S3 · Scale and quantization
**Claim:** the certifier holds at 9–14B (Gemma-2-9B, Qwen2.5-14B, on an 80 GB GPU) and on 8-bit and 4-bit deployments. The floors there are measured, not assumed.
**Route:** a scale vault, using G1's rules.
**Kill criterion:** coverage below 90%.

## S4 · Universality across intervention types
**Claim:** the quadratic law and certification carry over to doses in weight space:
- LoRA scale;
- model-merging coefficients, giving certified merging.

The curvature is restricted to the adapter or task-vector direction.
**Evidence:** the quadratic law is generic for any smooth divergence at its minimum.
**Route:** exploration with merges, then a gate.
**Kill criterion:** the weight-space exponent falls outside [1.8, 2.2].

## S5 · Composition at scale
**Evidence:** the computed guard over combinations ranged from 1.89 to 2.45 across the four models, and was 2.06 again in the 0.1.0 run.
**Claim:** in a formulary of at least 50 interventions:
- the computed combination guard predicts combination coverage;
- interaction coefficients predict compounding within 25%.

**Route:** G1's combinations, then a composition gate.
**Kill criterion:** combination coverage below 90% at the computed guard.

## S6 · A therapeutic window
**Evidence:** at certified doses in Law Test 3, the block-Fisher patch fixed 14.5–44% of near-miss errors with almost no breaks.
**Claim and route:** GR-2. If it passes, it unlocks the prescriber.

## S7 · KL is a valid surrogate
**Claim and route:** GR-1. If it passes, budgets can be stated in harm terms.

## S8 · The clinical bridge
**Claim:** polypharmacy burden can be managed with the same architecture:
- per-channel limits from patient-level responses;
- interaction matrices;
- monitored titration and deprescribing.

**Route:** exploration only — the literature and a protocol draft. Any clinical claim needs ethics approval and its own gates.

## S9 · Anytime-valid monitoring
**Claim:** the deployment monitor can be an e-process. Its stop rule then keeps a stated false-alarm rate however often it looks, so continuous monitoring costs no statistical validity.
**Why it matters:** it replaces "sample at a fixed cadence" with monitoring that carries a guarantee.
**Route:** exploration on recorded drift, then G6.
**Kill criterion:** detection delay more than twice that of the fixed-cadence rule at the same false-alarm rate.

## S10 · Formal guarantees
**Claim:** Learn-then-Test (or conformal risk control) turns the certifier's empirical coverage into a distribution-free statement. For example: "for traffic drawn like the calibration slices, the excess stays within budget with probability at least 1 − δ."
**Why it matters:** that's the level safety cases and regulators ask for.
**Route:** exploration once G1 passes, then a gate with its own vault.
**Kill criterion:** the guarantee needs calibration sets too large to build, or the certified doses it allows become useless (below budget/8).

## S11 · A toxicology of model interventions
**Claim:** the adverse-reaction types of pharmacology carry over as a shared vocabulary for harms from model interventions:
- **A, augmented:** dose-dependent; organ panels and overreach tests.
- **B, idiosyncratic:** tails and sentinels.
- **C, cumulative:** generation and multi-turn.
- **D, delayed:** downstream, after deployment.
- **Interactions:** co-medication.
- **F, therapeutic failure:** the indication.

Type A reactions should follow dose–response; type B should escape mean exposure.

**Why it matters:** a field that doses interventions by feel gets a classification it can measure and report against.
**Route:** GR's evidence (does mean exposure predict type A organ toxicity? do tails escape it?), then a position paper.
**Kill criterion:** organ breaks show no dose relationship at all, or type B harms can't be told apart from noise.

## S12 · Pharmacology's instrumental limits, measured where they can be
**Evidence:** the PK test sharpened two of pharmacology's own instruments: calibration transfers only within a mechanism class, and a noise-blind stopping rule stops at a few percent of the true range.
**Claim:** our substrates can measure what clinical pharmacology can't, and give it better instruments:
- **disease modification:** persistence after washout and regeneration, a fast and exact version of what delayed-start designs estimate slowly;
- **exit cost:** a common measure of the cost of leaving, for tolerance, dependence and deprescribing;
- **surrogate validity:** where an exposure measure stays quiet while the outcome changes;
- **noise-aware stopping:** escalation rules that tell a cliff from between-subject noise;
- **individual against population dosing:** how much of each individual's curve a population dose hides.

**Why it matters:** the isomorphism runs both ways (`isomorphism.md`). Pharmacology lends its instruments, and the substrates test and repair them.
**Route:** cybermorphic substrate 0.3 (P3–P7) in exploration, each instrument run both with and without common random numbers; then the PK simulator, where the truth is known. Any clinical use needs ethics approval and its own gates (S8).
**Kill criterion:** an instrument found in the substrates doesn't beat the standard one in the PK simulator.

## S13 · The edge announces itself
**Evidence (substrate 0.3, exploration):** whole-body exposure grows as dose² over two decades, then turns super-quadratic shortly before the first worm's form changes. In all three rules, the local exponent crossed 2.5 exactly one dose step (a factor of √2) below the first change, with and without common random numbers. The anterior region, far from the write, accelerated even earlier.

**Claim:** near the boundary of an attractor basin, a cheap exposure measure accelerates before any outcome changes, far enough ahead to stop on. Stated to be killed: an acceleration-triggered stop lands below the first dose that changes anything, in every rule and both directions, and within a factor of 4 of it.

**Why it matters:** this is the opposite of what the PK test found, where cliffs gave no warning, and it is a monitor clinical pharmacology does not have. If it is a property of basin boundaries rather than of this substrate, the same measure should warn before a language-model intervention breaks something — which is exactly what certify-and-monitor currently cannot do. The mechanism to look for is trajectory divergence near a separatrix: two nearby states that would have stayed together are split by the boundary, so the squared difference grows faster than the perturbation.

**Route:** substrate 0.4 (Q5) on a fine dose grid, across rules, directions and protocols; then the same measure on language-model interventions near a behavioural cliff, in exploration, before any gate.

**Update (0.4a):** replicated on a grid twice as fine, in 6 of 6 rule-and-direction pairs, with stops 1.7–4× below the first change. Requiring two accelerating rungs in a row changed no stop. Next, whether each individual's own curve warns before its own change (0.4b, R5), then language models.

**Kill criterion:** the acceleration arrives after the first change in any rule or direction, or its lead varies so much that no fixed rule stops safely without stopping below a useful dose.

## S14 · Some writes cannot be undone — killed as stated (0.4a)
Its kill criterion was met: a broad search found exits in both rules where 0.3 found none. What 0.3 saw was the failure of the inverse intervention, not a trap. The finding that survives is S15.

## S15 · Reversibility depends on timing
**Evidence (substrate 0.4a, exploration):** exits exist in every rule. In the intact adult they cost 1.4–64× the dose that wrote the form (median 8), and in one rule none of eight adult protocols works. Delivered during regeneration, exits exist in all three rules and cost 0.18–2.8× (median 1.2). Of 15 exits, 14 are windows: more intervention returns fewer worms.

**Claim:** a state written in the adult is cheapest to leave during a window of plasticity, and that window closes as the form re-establishes itself. Stated to be killed: the exit cost does not rise with the delay between injury and intervention.

**Why it matters:** it reframes reversibility from a property of the intervention to a property of timing. In deprescribing terms, the question is not only how to taper but when: whether there are windows in which a state is cheap to leave, and whether intervening outside them costs several times more or does not work at all. It also predicts that more intervention is not more exit.

**Route:** substrate 0.4b (R1): exit cost against the delay between cut and write. Then whether a non-injurious perturbation can open the same window.

**Kill criterion:** exit cost is flat across delays, or lowest in the intact adult.
