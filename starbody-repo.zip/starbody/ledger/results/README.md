# Results

Each gate's results file goes here and is recorded with `python ledger.py result <gate> <file> --verdict ...`.

Never edit a sealed result. Corrections and decisions go in as new entries with `python ledger.py note`.
