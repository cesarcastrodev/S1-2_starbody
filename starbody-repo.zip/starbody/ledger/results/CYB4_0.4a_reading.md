# Cybermorphic substrate 0.4a · what the run showed

**Exploration, not a gate.** Predictions Q1–Q8 were sealed before the run (entry 46). Both results files carry the matching plan hash, c69e08ef…, and the run used the NVIDIA L4, the card 0.3 ran on.

## Verdicts as the sealed code computed them

| | Prediction | Code's verdict | Reading |
|---|---|---|---|
| Q1 | the paired floor is rounding, dropping ≥ 1000× without TF32 | FAIL | the estimator, not the arithmetic; see below |
| Q2 | quadratic up to the first change, in float32 | PASS | exponent 2.00–2.05 in all three rules |
| Q3 | an exit exists in rules 0 and 1 | PASS | stands; positive control passed |
| Q4 | every exit is a window | FAIL | 14 of 15 clean exits are; the exception reaches 50% at the top of the range |
| Q5 | the acceleration stop lands below the edge, within 4× | PASS | 6 of 6 rule-and-direction pairs, stops 1.7–4× below |
| Q6 | an outcome-anchored certificate reaches ≥ 1/4 of the edge | PASS | **does not stand**; see below |
| Q7 | exposure separates changers from non-changers, AUC ≥ 0.9 | FAIL | **cannot answer the question**; see below |
| Q8 | persistence at ≤ half the clamp of visible change | FAIL | the factor failed; the effect is clean |
| P8 | (section E) the form-only arm's memory can be read | NOT ASSESSABLE | the arm is still not bistable |

## What held

- **Exits exist in every rule.** The 0.3 "traps" were untried doors. The search rediscovered rule 2's known exit (pulse, negative voltage, 0.94 at 0.16–0.23), so its negatives mean something.
- **Timing decides the cost of leaving.** Of 15 exits with clean controls, the 7 delivered to the intact adult cost 1.4–64× the switching dose (median 8), and rule 0 has none among its eight adult protocols. The 8 delivered during regeneration exist in all three rules and cost 0.18–2.8× (median 1.2).
- **Exits are windows.** 14 of the 15 return fewer worms at higher doses. The one exception reaches exactly 50% at 64× the switching dose, the top of the range tested.
- **The edge announces itself, again.** Exposure's local exponent crossed 2.5 between 1.7 and 4 dose-fold below the first change in all six rule-and-direction pairs. The two-rungs-in-a-row rule gave the same stops.
- **The attractor moves before the form, against an inert sham.** The per-cell clamp's sham changed nothing in any rule. At clamp level 0.57, 100% of worms switched persistently while 0% looked different during the clamp, in every rule. Visible change appears only in a narrow band of clamp levels inside the persistent range. Q8's factor of 2 was too strict for a grid with steps of √2.
- **The quadratic law holds in float32 all the way to the edge,** at exponent 2.00–2.05.

## Three verdicts compromised by design flaws

These are flaws a review should have caught. They went into the run unfixed.

1. **Q1 measured its own estimator.** The fitted float32 and float64 "floors" came out identical (within 3%), and one negative: the constant was the fit's own misfit, not rounding. Comparing the float32 and float64 curves directly instead, they agree to 1.4–1.9 × 10⁻⁴ at the lowest doses, which bounds the float32 floor at about 10⁻¹² and the TF32 → float32 drop at **2,900–4,200× in every rule** — past the 1,000× threshold. The mechanism is confirmed; the predicted 6.7 × 10⁷ is beyond this experiment's resolution. *Post hoc, so it does not change the sealed verdict.*
2. **Q6's PASS does not stand, and its cause is rule 5.** The verdict code needed one usable rule of two; the plan's replication rule needs two of three, which makes Q6 NOT ASSESSABLE. Underneath, the calibration compared each worm to a control run with independent noise, without correcting for spontaneous discordance. In rule 0, 3–5% of worms differed from their control at every dose, which blocked any certificate; in rule 2, two noisy rungs cut it to 3% of the edge. In rule 1, where discordance was zero, the outcome-anchored dose reached **71% of the edge** — 158× the noise-anchored dose — with 0 of 128 fresh worms changed.
3. **Q7 cannot answer the CAST question.** Exposure and outcome came from separate runs. Near the edge, which worm switches is decided by noise, so a worm's exposure in one run cannot predict its outcome in another. The AUCs of 0.40–0.58 say that individuals do not differ in a way exposure captures, consistent with P7 in 0.3; they say nothing about exposure as a surrogate.

A fourth flaw changed no verdict. The regeneration clamps recorded their baseline while the region was still empty, so their "sham" held regrowing tissue at zero. Along the read direction that alone returned every worm in rules 0 and 2. Those four combinations are set aside; the clean exits still settle Q3.

## Two post hoc findings

- **The floors add.** Unpaired TF32 noise equals unpaired float32 noise plus the TF32 rounding floor, within 3–8% in all three rules: two independent sources adding as variances, the same structure as bfloat16 KL = floor + float32 KL in the language models. It also means 0.3's noise budget was partly rounding: in rule 1, the TF32 unpaired floor is 2.9× the stochastic one.
- **The guard, as a tolerance bound, is about 2.** Computed properly — the factor keeping 95% of worms within budget with 95% confidence — it is 2.0 and 2.8 in the two rules where it could be computed. 0.3's conclusion that the guard does not cross mechanisms came from taking a maximum over 32 worms, and is retracted.

## Section E

Longer training fixed the check that had failed (one-headed trunk regrowth, 0.72 → 0.97) and broke another: a two-headed worm cut through its posterior third regrows one head in 0–59% of cases, though cut a little further forward it regrows two in 72–100%. The form-only arm's memory of its second head depends on where it is cut. P8 still cannot be asked.
