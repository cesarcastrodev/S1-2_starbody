# Cybermorphic substrate 0.3 · what the first run showed

**Exploration, not a gate.** No claim was at stake, so nothing here passed or failed as a claim. The predictions P1–P8 were stated and sealed before the run (entry 38, plan sha256 c7f3f7a5…), and the run's own `plan.json` hash matches, so the verdicts below are the ones the notebook was committed to.

## Verdicts as the notebook computed them

| | Prediction | Verdict | What the numbers say |
|---|---|---|---|
| P1 | quadratic law up to the budget | FAIL | the law holds; the window didn't — see below |
| P2 | additive floor | PASS | 0.82–0.97 in all three rules |
| P3 | the edge gives no warning | FAIL | exposure accelerates 1–3 dose steps **before** the first change, in every rule |
| P4 | the guard leaves 1.1–2.45 | PASS | 1.02, 1.04, 1.08 — but see the caveat |
| P5 | a symptomatic band below the persistent one | FAIL | reversed: persistence appears at a **lower** clamp level than visible change |
| P6 | exposure alone lets worms change | FAIL | the budget was ~100× too conservative for anything to change |
| P7 | individual vs population dosing | ESTIMATION | thresholds within one dose step; variation is between rules, not within |
| P8 | the memory can be found by reading | NOT ASSESSABLE | the form-only arm was not bistable in any rule |

## The write worked

A 20-step voltage pulse turned one-headed worms into two-headed ones in every rule, and the new form survived cutting away all written tissue. At the certified switching dose, 99–100% of 128 fresh worms switched persistently, with no organ grade above 1 and no dose-limiting toxicity against healthy cue-grown cohorts.

## Two findings that were not predicted

1. **The written form is a trap in two of three rules.** No pulse of either sign, up to roughly 50× the switching dose, returned more than a fifth of two-headed worms — acquired or native. In rule 2 an exit exists at 0.23–0.32 per step, twice the switching dose, and it is a **window**: higher doses return fewer worms. The exit cost was identical for written and native worms (history effect 1.0).
2. **The edge announces itself.** The local exponent of whole-body exposure rises above 2.2 one to three dose steps before the first worm changes, in every rule, with and without common random numbers. Above a threshold of 2.5 the lead is exactly one dose step (a factor of √2) in all three. This is the opposite of the PK cliffs, and it is a monitor pharmacology does not have.

## Why P1 failed while the law held

The paired curve has a floor of its own: a constant of 3.3–4.5 × 10⁻⁹, which is 0.19–0.76× the unpaired floor, even though paired twins share every random update mask. At dose exactly zero the twins are bit-identical, so this floor is created by any nonzero perturbation — the signature of rounding, not of stochastic firing. Fitting floor + η²·dose² to the low-dose data matches within 2–8%, and above 10× that paired floor the measured exponent is 2.06–2.10.

P1's window ran from budget/100 to the budget, and because the budget is only 10× the *unpaired* floor, the bottom of that window sat below the *paired* floor. The law was measured partly inside its own noise. The fix is the window, not the law.

## Flaws in the design, found by the data

- **The sham clamp was not inert.** Holding the posterior region at a single mean level flattens its gradient. In rule 0, 44% of sham-clamped worms regrew two heads at zero clamp level. The clamp must hold each cell at its own baseline, not at a common one. That the gradient itself carries the form is a finding in its own right.
- **The "false warning under noise" flag is mislabelled.** It fires whenever a warning precedes the edge, which is what happened in every rule. Those warnings arrived at the same dose step with and without common random numbers, so they were real, not noise.
- **P4 passed for the wrong reason.** Guards of 1.02–1.08 reflect worms that are nearly identical, not a calibrated safety factor. At those guards, 4–13% of fresh worms exceeded the budget, while the borrowed guard of 2 kept 98–99% within it. A guard computed as a maximum over a calibration cohort is not a tolerance bound, and should be one.
- **The certificate was useless, and the usefulness floor caught it.** The certified non-switching dose reached only 0.4–1.1% of the first dose that changes anything, in all three rules. This is the PK test's failure mode reproduced exactly: coverage bought by certifying almost nothing. Rule 4 of `isomorphism.md` did its job. A budget anchored to an arbitrary multiple of a noise floor cannot produce a useful certificate; it has to be anchored to the outcome.

## What the review's fixes caught

Each of these would have been invisible in substrate 0.2:

- **A depot.** In rule 2, regrowth that kept written tissue "switched" up to 75% at doses where regrowth from never-written tissue switched none.
- **Cryptic switches.** Near threshold doses, switches were invisible until amputation. In one condition all 16 worms were cryptic.
- **The PK stopping failure, reproduced.** Under clinical noise, escalation stopped at zero in rule 0 and at 18% of the certificate in rule 2.
