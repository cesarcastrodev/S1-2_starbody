# The gate ladder

| Gate | Question | Vaults | Status |
|---|---|---|---|
| G0 · Engineering | Does it run, reproduce and keep its invariants? | none | two Colab runs of 0.2 pending |
| G1 · Internal | Does it hold for new interventions and texts in the known models? | V-P1, V-T1 | written (revision 3), not anchored |
| GR · Relationships | Is KL a valid surrogate? Is there a therapeutic window? Is transfer predictable? | V-P3, V-H1, V-T3 | written (revision 3), not anchored |
| G2 · External | Does it hold in models never used? | V-M1 | outline below |
| G3 · Adversarial | Can someone trying to break it succeed? | V-R1 | outline below |
| G4 · Replication | Does someone else get the same numbers? | another person, hardware and seeds | outline below |
| G5 · Utility | Do certified doses repair better than LoRA and prompting at matched certified side effect, on task measures? | V-U1 | outline below |
| G6 · Deployment | Does monitoring catch drift in use? | a shadow deployment | outline below |

Each outline below becomes a full gate file, with its own operating characteristics, sealed and anchored before its vaults are built.

- **G2:**
  - G1's claims a–i, on V-M1, with the same pooled rules, including the instruction-tuned models.
  - Chat-formatted slices, co-medication with a system prompt, and a critical refusal organ.
  - Signal S1's floor predictions, sealed before the models are run, must fall within a factor of 2 for at least 3 of the 4 models.
  - If a claim fails, the scope is narrowed in writing to the families where it passed.
- **G3:**
  - Intervention-level coverage of at least 90% under attack, including attacks that seek single texts or organs where a certified dose does the most harm (tail-seeking).
  - Each successful attack is documented as a failure mode and becomes a new product gate. The certifier is retested on a fresh red-team set.
- **G4:**
  - An independent rerun of G1 by another person, on another GPU type and with other seeds.
  - Doses, coverage and floors must agree within tolerances set beforehand.
  - Until G4 passes, results are published only as an "unreplicated" preprint.
- **G5:**
  - Net repairs per 1,000 queries, measured by task metrics and an LLM judge validated as in Law Test 1.
  - Compared at matched certified side effect against LoRA and prompting.
  - Non-inferiority margin fixed in advance.
- **G6:**
  - A shadow deployment on recorded traffic with injected drift.
  - The stop rule must fire before a budget breach in at least 90% of drift episodes. An anytime-valid monitor (signal S9) is preferred.
