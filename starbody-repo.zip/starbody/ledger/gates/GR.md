# GR · Relationships: what the certified quantities mean

**Questions:**
1. Is KL a valid surrogate for harm?
2. Is there a therapeutic window, where repairs come before harm?
3. Can side effects on unseen genres be predicted from the monitor genres?

GR is estimation first. Every relationship is reported as an effect with an interval. Decisions then use the interval bounds, so a noisy estimate can't pass by luck. GR runs before G5 (utility), because utility claims depend on its answers. It opens V-P3, V-H1 and V-T3.

## Design
- **Models:** the four known models, in bfloat16. Float32 is used where a claim needs truth.
- **Interventions:** V-P3, per model 4 repair, 2 steering and 2 random, so 32 in all. Each is certified with starbody-certify 0.1.2, then measured at 0.25, 0.5, 1, 2 and 3 times its certified dose. The higher doses are deliberately past the certificate, so that harm becomes visible.
- **At each dose:**
  - KL on the monitor slices and on V-T3, in float32;
  - capability accuracy on ARC-Easy, HellaSwag and MMLU (200 items each);
  - break rate on the 300 correct facts and repair rate on the 300 near-miss errors. Both are paired, batch-invariant first-token readouts with a 0.5-nat margin;
  - degeneration rate on 48 greedy continuations;
  - worst-text KL and generation KL;
  - organ-panel breaks on V-O1's items.

  Accuracy differences are paired item by item against the unpatched model. Nothing is judged by an LLM.
- **Analysis:** a sealed script with hierarchical models (random intercepts for model and intervention) and partial pooling. Intervals come from a bootstrap that resamples interventions within models.

## Claims

| ID | Claim | Pass rule |
|---|---|---|
| GR-1a | **Exposure is a strong surrogate:** each exposure measure (mean KL, worst-text KL, generation KL) is tested as a predictor of capability loss, break rate and organ breaks, across interventions and doses | for the best measure, conditional R² at least 0.5 for each harm, and the slope's 95% lower bound above 0. Which measure is best is itself reported, with intervals |
| GR-1c | **Averages hide tails, or don't:** organ breaks against mean KL, compared with organ breaks against worst-text KL | reported with intervals. If worst-text KL predicts organ breaks better (difference in R² with a lower bound above 0), monographs lead with it |
| GR-1d | **Compounding is predictable:** the generation-to-teacher-forced ratio as a function of dose | a fitted dose–ratio relation whose 90% prediction intervals contain 85–95% of observations |
| GR-1b | **The budget means low harm:** at certified doses (1× only), mean capability loss and mean break rate pooled over interventions | upper 95% bounds at most 1 accuracy point and 1% |
| GR-2 | **A therapeutic window exists:** a hierarchical Emax model fits repair against dose for repair patches; the therapeutic index is the certified dose divided by ED50 (the dose giving half the maximum repair) | pooled median index at least 1, with a lower 90% bound of at least 0.7. Random patches must show no repair: fitted Emax interval includes 0 |
| GR-3 | **Transfer is predictable:** a hierarchical model fitted on monitor KL predicts V-T3 KL | 90% prediction intervals contain between 85% and 95% of observations (calibrated, not just wide), and the computed guard factor bounds the V-T3/monitor ratio for at least 90% of interventions |

## Decision rules
- **GR-1a and GR-1b pass:** monographs may state the budget in harm terms, using the fitted relation. **They fail:** monographs keep "KL is not harm", and one fix is allowed. For example, a budget defined on the harm measures themselves, tested on a new vault.
- **GR-2 passes:** the prescriber (0.3) may proceed. **It fails:** efficacy research comes before any prescriber.
- **GR-3 passes:** the computed guard may replace the fixed guard of 2 in 0.2. **It fails:** the guard stays at 2.
- **All estimates are published** with their intervals, whatever the decisions.

## Cost

About 30 minutes per small model and 2 hours for the 7B: roughly 4 A100 hours, about 22 compute units.
