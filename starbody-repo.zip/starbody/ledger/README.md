# Starbody gate ledger

This ledger exists so that goalposts cannot move unseen. Every claim the program makes in a monograph, a paper or a product passes through a gate. Every gate is written and sealed here before the data that judges it exists.

## The rules

1. **Two tracks.**
   - **Exploration** is free: post hoc analysis, hunches, signals. It is never claimed.
   - **Confirmation** is pre-registered, runs only on vault data, and is the only source of claims.
2. **Vaults.** Sealed data sets the development loop never touches: models, interventions, texts, tasks.
   - Each vault is built by a rule written in `vaults.md`.
   - Its content hash is sealed here before any analysis reads it.
   - It is opened by exactly one gate, then retired into development data.
3. **Blinding.**
   - Vault builders are scripts. They write files and hashes, and print only counts.
   - Nobody reads vault contents or partial results before the gate's analysis code is sealed.
   - The analysis runs end to end, without stopping to look.
4. **Gates.** Each file in `gates/` states:
   - the claims, metrics and thresholds;
   - the vaults it opens;
   - the analysis code, sealed before opening;
   - what happens on failure, decided in advance.

   A gate is sealed before its vaults are built.
5. **Operating characteristics.** Each gate states how likely it is to pass when the truth is good, and when it is not. A gate that a good method would often fail, or a poor one often pass, gets redesigned before sealing, not after.
6. **The fix budget.**
   - A failed claim may be fixed once. The fix must have a mechanism behind it, and must be sealed here before the next vault opens. It is tested only on that vault.
   - A claim that fails in two independent vaults is dropped or narrowed, in writing.
   - Verdicts (PASS, FAIL, NOT ASSESSABLE) are never edited.
7. **Error control.**
   - Claims within a gate are conjunctive: all must pass.
   - A vault is never re-run.
   - The verdict uses exactly the pre-registered analysis.
8. **Anchoring.** A hash chain proves consistency, not time.
   - After sealing a gate, run `python ledger.py anchor --where "<place>"` and publish the printed head hash there: a Zenodo or OSF deposit, or a public commit.
   - `verify --published <hash>` detects any rewritten history.
   - Re-sealing a file after an anchor is allowed but always shown, with its stated reason. Amendments stay possible, never invisible.
9. **Ambition.** `signals.md` lists bold hypotheses to chase hard in exploration. A signal becomes a claim only by passing a gate. Gates judge claims, not ideas.
10. **Isomorphic attention.** Every concept borrowed from another field carries a status in `isomorphism.md` (tested, operational, vocabulary or imposed), with the test that would promote it. Constants are recalibrated across mechanisms. A correspondence is never tested on a substrate built to contain it. We lean into the limits of the instruments we borrow.
11. **A flaw found in review is closed or deferred in writing before the seal.** Three design flaws that a review should have caught went into the 0.4a run unfixed and compromised three of its eight verdicts. Each finding of a review is listed with its fix, or with the reason it is deferred, and the list is checked before sealing.

## Running a gate

1. Write `gates/Gx.md`. Then run `python ledger.py seal gates/Gx.md --kind gate --id Gx`, and `python ledger.py anchor --where ...`, and publish the head.
2. Build each vault by its rule into `vaults/<ID>/`, then run `python ledger.py seal vaults/<ID> --kind vault --id <ID>`.
3. Write the analysis code, then run `python ledger.py seal <file> --kind code --id Gx`. Anchor again.
4. Run the gate. Write `results/Gx_results.json`, then run `python ledger.py result Gx results/Gx_results.json --verdict PASS|FAIL|"NOT ASSESSABLE"`.
5. Apply the gate's decision rule. Record each decision with `python ledger.py note Gx "<decision>"`.

`python ledger.py verify` checks, at any time, that the chain is intact and that no sealed file has changed. It also lists every amendment made after an anchor.

## Status

- **Who wrote it:** Claude drafted every file here for César's review, on 2026-10-31. The entries in `ledger.jsonl` seal these drafts.
- **Six revisions are already in the chain,** each sealed after a review:
  - **revision 2 (2026-10-31):** the gates' operating characteristics, anchoring, blinding;
  - **revision 3 (2026-10-31):** the toxicity model in certifier 0.2, and the claims and vaults that test it;
  - **revision 4 (2026-11-03):** isomorphic attention, as rule 10 and `isomorphism.md`; signal S12; the cybermorphic substrate 0.2, sealed with its predictions before its first run.
  - **revision 5 (2026-11-03):** a review of substrate 0.2 found thirteen flaws before any run. Substrate 0.3 fixes them, and `isomorphism.md` gains rule 7 and an amended rule 5.
  - **revision 6 (2026-11-03):** the first run of substrate 0.3 is recorded, with a written reading (entries 39–40). `isomorphism.md` gains rules 8 and 9, both forced by flaws the run exposed; signals S13 and S14 file its two unpredicted findings. Substrate 0.4 is sealed with predictions Q1–Q8 before its first run.
  - **revision 7 (2026-11-05):** the 0.4a run is recorded with a reading that separates what held from three verdicts compromised by design flaws. `isomorphism.md` gains rule 10 and corrected rows (the guard does cross, roughly); S14 is killed as stated and replaced by S15; this file gains rule 11. The follow-up 0.4b is sealed before it runs.

  The history shows what changed and why.
- **No anchor exists yet.** Nothing is binding until the first one.
