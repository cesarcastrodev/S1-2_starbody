#!/usr/bin/env python3
"""Starbody gate ledger: an append-only, hash-chained record of gates, vaults, code and results.
Standard library only. Each entry stores the SHA-256 of the sealed file or directory and the hash of the previous
entry, so any later edit to a sealed file, or to the history itself, is detected by `verify`.

    python ledger.py seal gates/G1.md --kind gate --id G1
    python ledger.py seal vaults/V-T1 --kind vault --id V-T1
    python ledger.py result G1 results/G1_results.json --verdict PASS
    python ledger.py note G1 "fix sealed for claim G1-c before opening V-P2"
    python ledger.py anchor --where "Zenodo 10.5281/zenodo.NNNN"   # then publish the printed head hash there
    python ledger.py verify [--published <hash>]
    python ledger.py show

A hash chain proves internal consistency, not time: anyone could rewrite the whole chain consistently. Publishing the
head hash somewhere outside your control (a Zenodo or OSF deposit, a public commit) fixes the history up to that point.
`verify --published` checks that a published head is still in the chain, and `verify` warns whenever a gate, vault or
code file sealed before an anchor was re-sealed after it: amendments stay possible, but never invisible.
"""
import argparse
import hashlib
import json
import os
import sys
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
LEDGER = os.path.join(ROOT, "ledger.jsonl")
KINDS = ("genesis", "gate", "vault", "code", "result", "note", "anchor")

def sha256_path(path):
    h = hashlib.sha256()
    if os.path.isdir(path):
        for dirpath, dirnames, filenames in os.walk(path):
            dirnames.sort()
            for fn in sorted(filenames):
                fp = os.path.join(dirpath, fn)
                h.update(os.path.relpath(fp, path).replace(os.sep, "/").encode() + b"\0")
                with open(fp, "rb") as f:
                    h.update(hashlib.sha256(f.read()).digest())
    else:
        with open(path, "rb") as f:
            h.update(f.read())
    return h.hexdigest()

def entries():
    if not os.path.exists(LEDGER):
        return []
    with open(LEDGER, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]

def _entry_hash(e):
    body = {k: v for k, v in e.items() if k != "entry_hash"}
    return hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

def append(kind, id_, path=None, note="", verdict=None, sha=None):
    assert kind in KINDS, kind
    es = entries()
    rel = os.path.relpath(os.path.abspath(path), ROOT).replace(os.sep, "/") if path else None
    e = {"seq": len(es), "time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "kind": kind, "id": id_,
         "path": rel, "sha256": sha or (sha256_path(path) if path else None), "verdict": verdict, "note": note,
         "prev": es[-1]["entry_hash"] if es else "0" * 64}
    e["entry_hash"] = _entry_hash(e)
    with open(LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps(e, ensure_ascii=False) + "\n")
    return e

def verify(published=None):
    es, problems, warnings = entries(), [], []
    prev = "0" * 64
    for i, e in enumerate(es):
        if e.get("seq") != i:
            problems.append(f"entry {i}: sequence number {e.get('seq')}")
        if e.get("prev") != prev:
            problems.append(f"entry {i}: broken chain (prev does not match)")
        if _entry_hash(e) != e.get("entry_hash"):
            problems.append(f"entry {i}: entry altered after writing")
        prev = e.get("entry_hash")
    latest = {}
    for e in es:
        if e.get("path"):
            latest[e["path"]] = e
    for rel, e in latest.items():
        p = os.path.join(ROOT, rel)
        if not os.path.exists(p):
            problems.append(f"{rel}: sealed (entry {e['seq']}) but missing")
        elif sha256_path(p) != e["sha256"]:
            problems.append(f"{rel}: changed since it was sealed (entry {e['seq']})")
    anchors = [e["seq"] for e in es if e["kind"] == "anchor"]
    seals = {}
    for e in es:
        if e["kind"] in ("gate", "vault", "code") and e.get("path"):
            seals.setdefault(e["path"], []).append(e)
    for rel, ss in seals.items():
        for a in anchors:
            before = [x for x in ss if x["seq"] < a]
            after = [x for x in ss if x["seq"] > a and before and x["sha256"] != before[-1]["sha256"]]
            for x in after:
                warnings.append(f"{rel}: AMENDED after the anchor at entry {a} (entry {x['seq']}: {x.get('note') or 'no reason given'})")
    if published and not any(e.get("entry_hash") == published for e in es):
        problems.append(f"the published head {published[:16]}... is not in this chain: history was rewritten")
    return problems, warnings

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("seal"); s.add_argument("path"); s.add_argument("--kind", required=True, choices=KINDS[1:4])
    s.add_argument("--id", required=True); s.add_argument("--note", default="")
    r = sub.add_parser("result"); r.add_argument("id"); r.add_argument("path")
    r.add_argument("--verdict", required=True, choices=("PASS", "FAIL", "NOT ASSESSABLE")); r.add_argument("--note", default="")
    n = sub.add_parser("note"); n.add_argument("id"); n.add_argument("text")
    h = sub.add_parser("hash"); h.add_argument("path")
    an = sub.add_parser("anchor"); an.add_argument("--where", required=True)
    v = sub.add_parser("verify"); v.add_argument("--published", default=None)
    sub.add_parser("show")
    a = ap.parse_args(argv)
    if a.cmd == "seal":
        e = append(a.kind, a.id, a.path, a.note)
        print(f"sealed {e['path']} as {a.kind} {a.id}: {e['sha256'][:16]} (entry {e['seq']})")
    elif a.cmd == "result":
        e = append("result", a.id, a.path, a.note, a.verdict)
        print(f"result for {a.id}: {a.verdict} (entry {e['seq']})")
    elif a.cmd == "note":
        e = append("note", a.id, note=a.text)
        print(f"note for {a.id} (entry {e['seq']})")
    elif a.cmd == "hash":
        print(sha256_path(a.path))
    elif a.cmd == "anchor":
        es = entries()
        head = es[-1]["entry_hash"] if es else "0" * 64
        e = append("anchor", "ANCHOR", note=f"head {head} published at: {a.where}")
        print(f"Publish this head hash at {a.where}:\n  {head}\n(anchor recorded as entry {e['seq']})")
    elif a.cmd == "verify":
        probs, warns = verify(a.published)
        print("ledger OK: chain intact, every sealed file unchanged" if not probs else "PROBLEMS:\n  " + "\n  ".join(probs))
        if warns:
            print("WARNINGS (visible amendments):\n  " + "\n  ".join(warns))
        return 1 if probs else 0
    elif a.cmd == "show":
        for e in entries():
            print(f"{e['seq']:>3} {e['time']} {e['kind']:<7} {e['id']:<8} {e.get('verdict') or '':<8} "
                  f"{(e.get('path') or ''):<28} {(e.get('sha256') or '')[:12]} {e.get('note', '')[:60]}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
