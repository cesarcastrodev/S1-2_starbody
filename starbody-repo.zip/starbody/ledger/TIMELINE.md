# Timeline from Google Drive

Every run saved its predictions to the author's Google Drive before it saved any result. The runs wrote these files themselves, from Colab, as they started and as they finished.

**What this shows.** On Google's clock, each prediction existed before its result did. Drive records when each file was created, and keeps a version history. Each predictions file below has a single version, saved seconds after the file was created and never changed.

**That the predictions are the ones in this repository** can be checked without Drive: `python verify_plans.py` rebuilds every protocol and plan from the notebooks and compares it with the fingerprint each run recorded.

**What it does not show.** These records are not a cryptographic timestamp. They sit in the author's account, so they corroborate the ordering rather than prove it, and others can inspect them only if the files are shared.

Checked on 13 November 2026 through the Google Drive connector, in the author's account. Times are UTC.

## Predictions, then results

| Run | Predictions file on Drive | Bytes | Created | Its one version | First results file on Drive | Bytes | Created |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Law Test 1.3 | `Starbody/law_test1/run_18e523ff02bc/protocol.json` | 25,108 | 30 Oct 18:03:16 | 18:03:24 | `verdict_law_test.json` | 19,016 | 30 Oct 20:16:13 |
| Law Test 2 | `Starbody/law_test2/run_d3acaa2613eb/protocol.json` | 6,734 | 30 Oct 21:42:43 | 21:42:58 | `model_result.json`, Gemma-2-2B | 15,506 | 30 Oct 22:19:39 |
| Law Test 3 | `Starbody/law_test3/run_93913f7ddd0c/protocol.json` | 7,685 | 31 Oct 01:39:25 | 01:39:32 | `model_result.json`, Gemma-2-2B | 15,005 | 31 Oct 02:04:12 |
| Substrate 0.3 | `Starbody/cybermorphic/nca_worm_v3/plan.json` | 4,114 | 3 Nov 18:06:05 | 18:06:13 | `results.json` | 118,513 | 3 Nov 19:09:34 |
| Substrate 0.4a | `Starbody/cybermorphic/nca_worm_v4/plan.json` | 4,444 | 5 Nov 18:22:34 | 18:22:41 | `results.json` | 82,699 | 5 Nov 18:59:44 |
| Follow-up 0.4b | `Starbody/cybermorphic/nca_worm_v4/plan_0.4b.json` | 1,660 | 5 Nov 20:19:26 | 20:19:32 | `results_0.4b.json` | 22,860 | 5 Nov 20:55:40 |

The law tests name each run folder after the first 12 characters of the protocol's SHA-256 fingerprint. The automaton runs record their plan's fingerprint inside their results.

## Later results files

| Run | Results file on Drive | Bytes | Created |
| --- | --- | --- | --- |
| Law Test 2 | `model_result.json`, Qwen2.5-1.5B | 15,637 | 30 Oct 22:49:01 |
| Law Test 2 | `model_result.json`, Qwen2.5-3B | 16,366 | 30 Oct 23:31:24 |
| Law Test 2 | `model_result.json`, Qwen2.5-7B | 15,624 | 31 Oct 00:33:39 |
| Law Test 3 | `model_result.json`, Qwen2.5-1.5B | 14,991 | 31 Oct 02:26:07 |
| Law Test 3 | `model_result.json`, Qwen2.5-3B | 14,834 | 31 Oct 02:54:15 |
| Law Test 3 | `model_result.json`, Qwen2.5-7B | 15,484 | 31 Oct 03:35:32 |
| Substrate 0.4a | `results_formonly.json` | 1,740 | 5 Nov 19:52:46 |

Every results file listed here has the same size as its copy in this repository.

## Against the ledger's own times

The ledger's times are recorded by the ledger tool itself, so they are not independent. They agree with Drive's:

| Run | Sealed in the ledger | Predictions reached Drive |
| --- | --- | --- |
| Substrate 0.3 | 3 Nov 13:12:13 (entry 38) | 3 Nov 18:06:05 |
| Substrate 0.4a | 3 Nov 21:27:27 (entry 46) | 5 Nov 18:22:34 |
| Follow-up 0.4b | 5 Nov 20:18:20 (entry 55) | 5 Nov 20:19:26 |

The law tests predate the ledger. Their fingerprint is the name of their run folder.
