# Starbody: dose, warning, way back

Code, results and the sealed record for the preprint
*Paracelsus for Machines: dose, warning and the way back in learned systems* (César Castro, November 2026).

**Status: exploratory.** Nothing here is a clinical or biological claim. Nothing has been replicated by anyone else.

## What was tested

Four instruments borrowed from clinical pharmacology, each tested on two kinds of learned system:

| Instrument | Language models (Study 1) | Regenerating automaton (Study 2) |
| --- | --- | --- |
| Dose–response law (exposure ∝ dose²) | Held, 4 models | Held, 3 trained rules |
| Assay floor from arithmetic precision | Held, post hoc | Held, post hoc |
| Certify, then escalate under monitoring | 100% of held-out pairs within budget | 0.71 of the first-change dose, against a twin |
| Warning before a qualitative change | Not tested | Held, population and individual |
| Cost of reversal (exit cost) | Not applicable | Measured; depends on timing |

## What failed

- **All three language-model tests returned FAIL as registered.** See `study1_language_models/results/*_verdict.json`.
- **7 of 20 automaton predictions were spoiled by the instrument**, not answered by the data. See the readings in `ledger/results/`.
- **Exposure as a surrogate for harm is untested.** A certificate here bounds a number, not safety.

## Layout

| Folder | Contents |
| --- | --- |
| `ledger/` | The hash-chained record: 57 entries, the verifier, the isomorphism table, the signals list, the gates, each run's reading, and the Drive timeline |
| `verify_plans.py` | Rebuilds each run's predictions from the notebooks and checks them against the runs' own records |
| `study1_language_models/` | Law Tests 1.3, 2.1 and 3.1 (sources and executed copies), post hoc scripts, verdicts, per-model results and figures |
| `study2_automaton/` | Substrate notebooks 0.3 and 0.4a (sources and executed copies), the 0.4b follow-up cell, results, figures, checkpoints |
| `certifier/` | The `starbody-certify` package (0.2.0), its tests, an example notebook, and monographs it produced |
| `paper/` | The preprint |

## Check the record

```bash
cd ledger
python ledger.py verify
```

This recomputes every hash and confirms the chain. The head entry at assembly was
`ef4afbf93ca5b1cf630ea89d80b625eba75d942fa920c07b9e29e72cdf9f4d09` (entry 56, 57 entries).

The notebooks in `study2_automaton/notebooks/` are byte-identical to the sealed copies in `ledger/code/`.
`MANIFEST.sha256` lists the hash of every file in this repository.

To check that the predictions here are the ones the runs used:

```bash
python verify_plans.py
```

It rebuilds every protocol and plan from the notebooks and compares each with the fingerprint its run recorded and with
the file the run saved to Google Drive as it started. Standard library only; no model is loaded.
`ledger/TIMELINE.md` lists when each run saved its predictions and its results on Drive.

## Known gaps

- **The ledger was not timestamped by a third party before the runs.** This release is its first external anchor. Google Drive's records corroborate the ordering, since every run saved its predictions before its first result (`ledger/TIMELINE.md`), but they sit in the author's account and are not a cryptographic timestamp.
- **The 0.4b results were entered after the run** (entry 56, on 13 November 2026), as for every run here. The results file has no timestamp of its own.
- **Law Tests 1 to 3 predate the ledger.** Their protocols were fingerprinted to storage on first run, inside each notebook.
- **Two superseded versions survive only as hashes in the ledger:** substrate 0.3 as first sealed (entry 36, corrected in its text only before the run, entry 38) and substrate 0.4 before its revision to 0.4a (entry 43). Certifier 0.1.1 (entry 8) was hashed as an external file. Substrate 0.2, which never ran, is in `ledger/code/`.
- **Executed copies show only the last session's outputs.** Law Tests 2 and 3 ran once per model in the same notebook, so their executed copies show the Qwen2.5-7B session; the other models' outputs survive in their result files. The executed 0.4a copy also holds the 0.4b cell, which ran in that session.

## Tests

```bash
cd certifier
python -m unittest discover -s tests
```

All 27 tests passed at assembly, with Python 3 and NumPy.

## Reproduce

- **Study 2** runs on one GPU in Google Colab (an NVIDIA L4 was used). Run 0.3 first; it trains the rules that 0.4a and 0.4b load.
- **Study 1** needs an A100 for the 7B model in float32. Each notebook runs once per model and needs a Hugging Face token for gated weights. Model weights are not redistributed.

## How this was made

Claude, an AI system made by Anthropic, designed and wrote the notebooks, the analysis scripts and the ledger tool, and wrote each reading, under the author's direction. The author posed the questions, ran every experiment and made the decisions.

## Licence

Code: MIT (`LICENSE`). Results, figures and text: CC BY 4.0 (`LICENSE-DATA.md`).
