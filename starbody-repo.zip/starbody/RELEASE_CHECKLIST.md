# Before the first push

1. **Merge the Drive additions.** Download the Drive folder `starbody-repo-additions` (nine checkpoints, three Law Test 2
   result files with their figures, five executed notebooks), unzip it next to this folder, and merge it in:
   `cp -R starbody-repo-additions/. starbody/`
   Don't drag it over in Finder: Finder replaces folders instead of merging them.
2. **Check the executed notebooks for secrets:** `grep -rl "hf_" study1_language_models/notebooks study2_automaton/notebooks`
   should print nothing.
3. **Check the predictions:** `python verify_plans.py` should end with "All checks passed." Before the merge in step 1,
   three Law Test 2 result files are missing and fail.
4. **Reserve a DOI on Zenodo** before publishing anything, so the preprint can cite it.
5. **Finish the preprint:** put the repository URL and the reserved DOI in Section 11, export it as PDF, and save it as
   `paper/paracelsus_for_machines.pdf`.
6. **Licences.** Confirm MIT for code and CC BY 4.0 for the rest, or change them.
7. **Manifest:** `find . -type f ! -path './.git/*' ! -name MANIFEST.sha256 | sort | xargs sha256sum > MANIFEST.sha256`
8. **Commit and push:** `git init && git add . && git commit -m "Starbody 0.1.0"`, then push to a public repository.
9. **Anchor the ledger:** `cd ledger && python ledger.py anchor --where "Zenodo <DOI>, commit <hash>"`. Copy the head hash
   it prints. Regenerate the manifest, commit, tag `v0.1.0`, and push.
10. **Publish the Zenodo record** from the tag, with the head hash from step 9 in its description. That record is the
    ledger's first external anchor.
