"""Check that the predictions the runs used are the ones in this repository.

For every run, this script rebuilds the protocol or plan (the file holding the predictions) from the notebook in this
repository and compares it with three records:

1. the fingerprint the run stamped into its own results (automaton runs), or into its Drive folder's name (law tests);
2. the size, in bytes, of the protocol or plan file the run saved to Google Drive as it started (ledger/TIMELINE.md);
3. the size of each results file the run saved to Drive, against its copy here.

It executes only the cells that define each protocol or plan: no model is loaded and nothing is downloaded.
Standard library only. Run from the repository root:  python verify_plans.py
"""
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# What Google Drive recorded for the predictions files (ledger/TIMELINE.md)
DRIVE_PREDICTIONS = {
    "Law Test 1.3": {"folder": "run_18e523ff02bc", "bytes": 25108},
    "Law Test 2": {"folder": "run_d3acaa2613eb", "bytes": 6734},
    "Law Test 3": {"folder": "run_93913f7ddd0c", "bytes": 7685},
    "Substrate 0.3": {"bytes": 4114},
    "Substrate 0.4a": {"bytes": 4444},
    "Follow-up 0.4b": {"bytes": 1660},
}

# What Google Drive recorded for the results files, against their copies in this repository
DRIVE_RESULTS = {
    "study1_language_models/results/law_test1_verdict.json": 19016,
    "study1_language_models/results/law_test2_gemma-2-2b.json": 15506,
    "study1_language_models/results/law_test2_Qwen2.5-1.5B.json": 15637,
    "study1_language_models/results/law_test2_Qwen2.5-3B.json": 16366,
    "study1_language_models/results/law_test2_Qwen2.5-7B.json": 15624,
    "study1_language_models/results/law_test3_gemma-2-2b.json": 15005,
    "study1_language_models/results/law_test3_Qwen2.5-1.5B.json": 14991,
    "study1_language_models/results/law_test3_Qwen2.5-3B.json": 14834,
    "study1_language_models/results/law_test3_Qwen2.5-7B.json": 15484,
    "study2_automaton/results/results_0.3.json": 118513,
    "study2_automaton/results/results_0.4a.json": 82699,
    "study2_automaton/results/results_0.4a_formonly.json": 1740,
    "study2_automaton/results/results_0.4b.json": 22860,
}

NB1 = "study1_language_models/notebooks/"
NB2 = "study2_automaton/notebooks/"
RES2 = "study2_automaton/results/"


def code_cells(path):
    return ["".join(c["source"]) for c in json.loads(path.read_text(encoding="utf-8"))["cells"]
            if c["cell_type"] == "code"]


def run_definitions(code):
    namespace = {}
    exec("import json, hashlib, math\n" + code, namespace)
    return namespace


def law_test_protocol(notebook):
    """The protocol as the law-test notebooks write it: json.dumps(PROTOCOL, sort_keys=True, indent=2)."""
    for src in code_cells(ROOT / notebook):
        if "PROTOCOL = {" in src and "PROTOCOL_HASH" in src:
            protocol = run_definitions(src[: src.find("PROTOCOL_HASH")])["PROTOCOL"]
            text = json.dumps(protocol, sort_keys=True, indent=2).encode()
            return hashlib.sha256(text).hexdigest(), len(text)
    raise SystemExit(f"no protocol cell found in {notebook}")


def automaton_plan(notebook):
    """The plan as the substrate notebooks build it: hashed with sort_keys, saved as plan.json with indent=1."""
    src = code_cells(ROOT / notebook)[0]
    head = src[: src.find("PLAN = {")]
    flags = "\n".join(line for line in head.splitlines() if re.match(r"^(SMOKE|RUN_FORM_ONLY|SEED)\s*=", line))
    sizes = head[head.find("S = dict("):]
    body = src[src.find("PLAN = {"): src.find("PLAN_HASH")]
    plan = run_definitions(flags + "\n" + sizes + "\n" + body)["PLAN"]
    return hashlib.sha256(json.dumps(plan, sort_keys=True).encode()).hexdigest(), len(json.dumps(plan, indent=1).encode())


def followup_plan(script):
    src = (ROOT / script).read_text(encoding="utf-8")
    plan = run_definitions(src[src.find("FOLLOW = {"): src.find("FOLLOW_HASH")])["FOLLOW"]
    return hashlib.sha256(json.dumps(plan, sort_keys=True).encode()).hexdigest(), len(json.dumps(plan, indent=1).encode())


def recorded_plan_hash(results_file):
    return json.loads((ROOT / results_file).read_text(encoding="utf-8"))["plan_sha256"]


def main():
    failures = 0

    def report(ok, label, detail):
        nonlocal failures
        failures += not ok
        print(f"  {'ok  ' if ok else 'FAIL'}  {label}: {detail}")

    print("Predictions: rebuilt from this repository, against the runs' own records")
    for run, notebook in (("Law Test 1.3", NB1 + "law_test1_lt1.3.ipynb"),
                          ("Law Test 2", NB1 + "law_test2_lt2.1.ipynb"),
                          ("Law Test 3", NB1 + "law_test3_lt3.1.ipynb")):
        digest, size = law_test_protocol(notebook)
        drive = DRIVE_PREDICTIONS[run]
        report("run_" + digest[:12] == drive["folder"], run, f"fingerprint folder run_{digest[:12]}, Drive {drive['folder']}")
        report(size == drive["bytes"], run, f"protocol.json {size} bytes, Drive {drive['bytes']}")

    for run, build, source, results in (
            ("Substrate 0.3", automaton_plan, NB2 + "cybermorphic_substrate_0.3.ipynb", [RES2 + "results_0.3.json"]),
            ("Substrate 0.4a", automaton_plan, NB2 + "cybermorphic_substrate_0.4a.ipynb",
             [RES2 + "results_0.4a.json", RES2 + "results_0.4a_formonly.json"]),
            ("Follow-up 0.4b", followup_plan, NB2 + "followup_0.4b.py", [RES2 + "results_0.4b.json"])):
        digest, size = build(source)
        for results_file in results:
            recorded = recorded_plan_hash(results_file)
            report(digest == recorded, run, f"plan fingerprint {digest[:16]}, recorded in {Path(results_file).name} {recorded[:16]}")
        report(size == DRIVE_PREDICTIONS[run]["bytes"], run, f"plan file {size} bytes, Drive {DRIVE_PREDICTIONS[run]['bytes']}")

    print("\nResults: copies in this repository, against the sizes Drive recorded")
    for path, size in DRIVE_RESULTS.items():
        p = ROOT / path
        if not p.exists():
            report(False, path, "missing here (merge the Drive additions first)")
        else:
            report(p.stat().st_size == size, path, f"{p.stat().st_size} bytes, Drive {size}")

    print("\nAll checks passed." if not failures else f"\n{failures} check(s) failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
