"""The certifier: certified doses for residual-stream interventions, with a toxicity profile and a stated benefit.

Backend-agnostic. A backend provides, for named text slices:
    kl_per_text(slice, delta)  per-text mean KL(base || patched) and token counts, in the current precision
    mean_kl(slice, delta)      token-weighted mean of the above
    hvp(slice, vectors)        Hessian-vector products of mean KL at zero patch (on-demand curvature)
    score_items(items, delta)  per-item margin: log-likelihood of the answer minus the best other choice
    generation_exposure(slice, delta, ...)   KL along the patched model's own generations (optional)
    mean_kl_rebatched(slice, delta)          the same measurement with different batching (optional)
    null_like(delta, seed), precision(name), describe(), slice_info(slice), fingerprint(delta)
TorchBackend (backend.py) is the real one; the tests use a numerical stand-in.

KL is treated as exposure, not harm. Harm is tested directly by organ panels (function tests graded like adverse
events), and benefit by the intervention's declared indication.
"""
import math
import random
from dataclasses import dataclass

import numpy as np

from . import _math as M
from .monograph import Monograph, now

__version__ = "0.2.0"

@dataclass
class Intervention:
    name: str
    delta: object                   # [layers, width]: added to every layer's output at every token
    description: str = ""
    indication: list = None         # items the intervention is meant to improve ({"prompt", "choices", "answer"})
    indication_kind: str = "repair" # "repair": share of baseline-wrong items fixed; "shift": mean margin gain
    control: bool = False           # a control (for example a random patch), certified without an indication

def _dot(a, b):
    return float((a * b).sum())

def _finite(x):
    return x is not None and x == x and math.isfinite(x)

def _halves(items, seed):
    idx = list(range(len(items)))
    random.Random(seed).shuffle(idx)
    h = len(idx) // 2
    return [items[i] for i in idx[:h]], [items[i] for i in idx[h:]]

class Certifier:
    # calibration measures bfloat16 inflation of curvature; the certificate is already conservative about it
    GATES = {"agreement_flag": 0.10, "agreement_refuse": 0.25, "calibration_flag": (0.8, 1.25),
             "calibration_refuse": (0.5, 2.0), "repeatability": 0.05, "repeatability_spread": 3.0, "caution": 0.75,
             "compounding_caution": 2.0}

    def __init__(self, backend, monitor, verify=(), panels=None, critical=(), budgets=(0.02, 0.05, 0.1), guard=2.0,
                 feasibility_multiple=4.0, tail_multiple=4.0, generation=True, gen_prompts=16, null_patches=5,
                 null_true_kl=(1e-8, 1e-7), grid_k=tuple(range(-2, 11)), accel=2.2, noise_multiple=10.0, seed=0,
                 verbose=True, allow_infeasible=False):
        self.b = backend
        self.monitor, self.verify = list(monitor), list(verify)
        assert self.monitor, "at least one monitor slice is needed"
        self.budgets, self.guard, self.multiple, self.tail_multiple = tuple(budgets), guard, feasibility_multiple, tail_multiple
        self.generation, self.gen_prompts = generation, gen_prompts
        self.null_patches, self.null_true_kl, self.grid_k = null_patches, tuple(null_true_kl), tuple(grid_k)
        self.accel, self.noise_multiple, self.seed, self.verbose = accel, noise_multiple, seed, verbose
        self.allow_infeasible = allow_infeasible
        self.panels = {n: _halves(items, seed + 31 + j) for j, (n, items) in enumerate(sorted((panels or {}).items()))}
        self.critical = set(critical)
        self.calibration = None
        self._null_floors, self._null_spread, self._null_text = None, {}, {}
        self._panel_base = {}

    def _log(self, *a):
        if self.verbose:
            print("[certify]", *a)

    @staticmethod
    def _mean(run):
        per, tok = run
        return float((np.asarray(per) * np.asarray(tok)).sum() / np.asarray(tok).sum())

    # ---- floors -------------------------------------------------------------------------------------------------
    def null_floors(self, reference):
        """Noise floor of every slice and every text: KL of random null patches at doses with a negligible true effect."""
        if self._null_floors is None:
            nulls = [self.b.null_like(reference, self.seed + 900 + j) for j in range(self.null_patches)]
            anchor = self.monitor[0]
            curv = [_dot(n, fv) for n, fv in zip(nulls, self.b.hvp(anchor, nulls))]
            doses = [[M.dose_for_kl(t, c) for t in self.null_true_kl] for c in curv]
            means, texts = {}, {}
            for s in self.monitor + self.verify:
                runs = [self.b.kl_per_text(s, n * x) for n, ds in zip(nulls, doses) for x in ds]
                means[s] = np.array([self._mean(r) for r in runs])
                texts[s] = np.median(np.array([np.asarray(r[0]) for r in runs]), axis=0)
            self._null_floors = {s: float(np.median(v)) for s, v in means.items()}
            self._null_spread = {s: float(1.4826 * np.median(np.abs(v - np.median(v)))) for s, v in means.items()}
            self._null_text = texts
            self._log("null floors:", {k: f"{v:.2e}" for k, v in self._null_floors.items()})
        return self._null_floors

    def _own_floors(self, delta, curv):
        ds = [M.dose_for_kl(t, curv[self.monitor[0]]) for t in self.null_true_kl]
        return {s: float(np.median([self.b.mean_kl(s, delta * x) for x in ds])) for s in self.monitor}

    # ---- curvature ----------------------------------------------------------------------------------------------
    def _curvature(self, delta):
        return {s: _dot(delta, self.b.hvp(s, [delta])[0]) for s in self.monitor}

    def interactions(self, interventions):
        """Side-effect matrices over the interventions, per monitor slice, plus what they read."""
        deltas = [iv.delta for iv in interventions]
        grams = {}
        for s in self.monitor:
            fv = self.b.hvp(s, deltas)
            G = np.array([[_dot(deltas[i], fv[j]) for j in range(len(deltas))] for i in range(len(deltas))])
            grams[s] = ((G + G.T) / 2).tolist()
        return {"members": [iv.name for iv in interventions], "grams": grams,
                "coefficients": {s: M.interaction_coefficients(g) for s, g in grams.items()},
                "guards": M.computed_guards(grams), "adversarial": M.adversarial_combinations(grams)}

    def calibrate(self, interventions, kl_points=(1e-4, 1e-3)):
        """One factor per model: deployment-precision curvature / float32 measured curvature."""
        anchor = self.monitor[0]
        ratios = []
        for iv in interventions:
            c_dep = _dot(iv.delta, self.b.hvp(anchor, [iv.delta])[0])
            with self.b.precision("float32"):
                ds = [M.dose_for_kl(t, c_dep) for t in kl_points]
                c32 = float(np.median([2 * self.b.mean_kl(anchor, iv.delta * x) / x ** 2 for x in ds]))
            ratios.append(c_dep / max(c32, 1e-30))
        self.calibration = float(np.median(ratios))
        self._log(f"calibration factor {self.calibration:.3f} (from {len(ratios)} interventions)")
        return {"factor": self.calibration, "ratios": ratios}

    # ---- organ panels and the indication ------------------------------------------------------------------------
    def _base_margins(self, name, half):
        key = (name, half)
        if key not in self._panel_base:
            self._panel_base[key] = np.asarray(self.b.score_items(self.panels[name][half], None))
        return self._panel_base[key]

    def _organs(self, delta, half):
        out = {}
        for name, halves in self.panels.items():
            base = self._base_margins(name, half)
            pat = np.asarray(self.b.score_items(halves[half], delta)) if delta is not None else base
            correct = base > 0.5
            breaks, n = int(((pat < -0.5) & correct).sum()), int(correct.sum())
            crit = name in self.critical
            g = M.grade_breaks(breaks, n, crit)
            out[name] = {"grade": g, "breaks": breaks, "n_correct": n, "break_rate": breaks / n if n else None,
                         "critical": crit, "dlt": M.is_dlt(g, crit)}
        return out

    def _indication(self, iv, d, grid, dose):
        if iv.control:
            return {"control": True}
        if not iv.indication:
            return {"declared": False}
        design, held = _halves(iv.indication, self.seed + 77)
        bd, bh = np.asarray(self.b.score_items(design, None)), np.asarray(self.b.score_items(held, None))

        def eff(items, base, x):
            pat = np.asarray(self.b.score_items(items, d * x))
            if iv.indication_kind == "repair":
                wrong = base <= 0
                return float(((pat > 0.5) & wrong).sum() / max(1, int(wrong.sum())))
            return float(np.mean(pat - base))
        doses = sorted(grid)
        curve = [eff(design, bd, x) for x in doses]
        e50 = M.ed50(doses, curve)
        return {"declared": True, "kind": iv.indication_kind, "n_items": len(held),
                "efficacy_at_dose": eff(held, bh, dose) if dose > 0 else 0.0,
                "curve": {"doses": doses, "efficacy": curve}, "ed50": e50,
                "therapeutic_index": (dose / e50) if (e50 and dose > 0) else None}

    # ---- certification ------------------------------------------------------------------------------------------
    def _escalate(self, delta, top, tau, tau_tail, floors):
        halvings = 0
        while True:
            ladder = M.escalation_ladder(top)
            first = {s: self.b.mean_kl(s, delta * ladder[0]) - floors[s] for s in self.monitor}
            if max(first.values()) < tau or halvings >= 10:
                break
            top, halvings = top / 2, halvings + 1
        ex, fl = {}, {}
        for s in self.monitor:
            runs = [self.b.kl_per_text(s, delta * x) for x in ladder]
            ex[s] = [self._mean(r) - floors[s] for r in runs]
            fl[s] = floors[s]
            tails = [float(np.max(np.asarray(r[0]) - self._null_text[s])) / self.tail_multiple for r in runs]
            ex[f"{s} (worst text)"], fl[f"{s} (worst text)"] = tails, float(np.max(self._null_text[s])) / self.tail_multiple
        i, trig = M.escalate_r1(ladder, ex, fl, tau, self.accel, self.noise_multiple)
        dlt = None
        if self.panels:
            for j in range(i + 1):
                organs = self._organs(delta * ladder[j], half=0)
                hit = [k for k, o in organs.items() if o["dlt"]]
                if hit:
                    dlt = (j, hit)
                    break
        stop = ladder[i]
        if dlt is not None:
            j, hit = dlt
            stop = ladder[j - 1] if j > 0 else float("nan")
            trig = f"dose-limiting toxicity in {', '.join(hit)} at ladder step {j}"
        return {"stop": stop, "trigger": trig, "halvings": halvings, "ladder": ladder, "excess": ex,
                "still_over_budget": bool(max(first.values()) >= tau), "dlt": dlt is not None,
                "rule": (f"R1: stop at the previous dose when mean excess reaches the budget (worst text: "
                         f"{self.tail_multiple:g}x the budget), on acceleration (local exponent >= {self.accel} with "
                         f"excess >= {self.noise_multiple:g}x floor), or at a dose-limiting toxicity")}

    def _verify(self, delta, dose, tau, tau_tail, nf):
        rows = {}
        for s in self.verify:
            if dose > 0:
                per, tok = self.b.kl_per_text(s, delta * dose)
                total = self._mean((per, tok))
                worst = float(np.max(np.asarray(per) - self._null_text[s]))
            else:
                total, worst = nf[s], 0.0
            ex = total - nf[s]
            rows[s] = {"total": total, "floor": nf[s], "excess": ex, "within_budget": bool(ex <= tau),
                       "worst_text_excess": worst, "worst_text_within_budget": bool(worst <= tau_tail)}
        if not rows:
            return {"slices": {}, "coverage": None, "worst_excess_over_budget": None, "pass": None, "tail_pass": None}
        cov = float(np.mean([r["within_budget"] for r in rows.values()]))
        return {"slices": rows, "coverage": cov, "worst_excess_over_budget": max(r["excess"] for r in rows.values()) / tau,
                "pass": bool(cov == 1.0), "tail_pass": all(r["worst_text_within_budget"] for r in rows.values())}

    def _generation(self, delta, dose, ver, nf):
        if not (self.generation and dose > 0 and hasattr(self.b, "generation_exposure")):
            return {}
        out = {}
        for s in (self.verify or self.monitor):
            g = dict(self.b.generation_exposure(s, delta * dose, n_prompts=self.gen_prompts, seed=self.seed))
            g["excess"] = g["kl_along_patched"] - nf[s]
            tf = ver["slices"].get(s, {}).get("excess") if ver["slices"] else None
            g["ratio_to_teacher_forced"] = g["excess"] / tf if tf and tf > 0 else float("nan")
            out[s] = g
        return out

    def _gates(self, d, dose, tau, tau_tail, feasible, cert, mparts, esc, ver, own, gen, tox, ind, iv):
        """Product gates: a dose is issued only if every gate passes (fail-closed)."""
        G, flags = self.GATES, []
        gates = {"feasibility": {"pass": bool(feasible or self.allow_infeasible), "value": feasible,
                                 "rule": f"budget >= {self.multiple} x the largest monitor floor"}}
        if _finite(cert) and cert > 0 and mparts.get("raw"):
            ratio = mparts["raw"] / cert
            dev = abs(ratio - 1)
            gates["agreement"] = {"pass": bool(dev <= G["agreement_refuse"]), "value": ratio,
                                  "rule": (f"matrix / measured certificate within {G['agreement_flag']:.0%} (flag up to "
                                           f"{G['agreement_refuse']:.0%}; refuse beyond)")}
            if G["agreement_flag"] < dev <= G["agreement_refuse"]:
                flags.append(f"matrix and measurement disagree by {dev:.0%}; the smaller dose was issued")
        else:
            gates["agreement"] = {"pass": False, "value": None, "rule": "a measured certificate is required"}
        (flo, fhi), (rlo, rhi) = G["calibration_flag"], G["calibration_refuse"]
        c = self.calibration
        gates["calibration"] = {"pass": bool(c is None or rlo <= c <= rhi), "value": c,
                                "rule": f"calibration factor within [{rlo}, {rhi}] when measured (flagged outside [{flo}, {fhi}])"}
        if c is not None and rlo <= c <= rhi and not flo <= c <= fhi:
            flags.append(f"precision inflation: matrix curvature is {c:.2f}x the float32 curvature; the conservative "
                         f"matrix certificate was used")
        trig = str(esc.get("trigger") or "")
        gates["shape"] = {"pass": bool(not esc.get("still_over_budget", False) and dose > 0), "value": esc.get("trigger"),
                          "rule": "a safe dose exists on the escalation ladder and it is not still over budget after halving"}
        if "acceleration" in trig:
            flags.append(f"faster-than-quadratic growth ({trig}): the escalation stopped early")
        gates["verification"] = {"pass": ver.get("pass") is not False, "value": ver.get("coverage"),
                                 "rule": "every verification slice within the mean budget"}
        gates["tail"] = {"pass": ver.get("tail_pass") is not False, "value": None,
                         "rule": f"every verification text within {self.tail_multiple:g}x the budget"}
        if gen:
            worst = max(g["excess"] for g in gen.values())
            gates["generation"] = {"pass": bool(worst <= tau), "value": worst / tau,
                                   "rule": "excess KL along the patched model's own generations within the budget"}
        else:
            gates["generation"] = {"pass": True, "value": None, "rule": "not measured for this backend or dose"}
            flags.append("exposure under generation was not measured")
        hit = [k for k, o in tox.items() if o["dlt"]]
        gates["toxicity"] = {"pass": not hit, "value": {k: o["grade"] for k, o in tox.items()},
                             "rule": "no dose-limiting toxicity on held-out organ-panel items at the certified dose"}
        if not tox:
            flags.append("no organ panels were run: toxicity was not tested directly")
        gates["indication"] = {"pass": bool(ind.get("control") or ind.get("declared")), "value": ind.get("efficacy_at_dose"),
                               "rule": "an indication is declared and measured (or the intervention is a declared control)"}
        if ind.get("declared") and (ind.get("efficacy_at_dose") or 0) <= 0:
            flags.append("no measurable benefit at the certified dose")
        a = self.monitor[0]
        if dose > 0 and hasattr(self.b, "mean_kl_rebatched"):
            e1 = self.b.mean_kl(a, d * dose) - own[a]
            e2 = self.b.mean_kl_rebatched(a, d * dose) - own[a]
            tol = max(G["repeatability"] * abs(e1), G["repeatability_spread"] * self._null_spread.get(a, 0.0))
            gates["repeatability"] = {"pass": bool(abs(e2 - e1) <= tol), "value": abs(e2 - e1) / max(abs(e1), 1e-30),
                                      "tolerance": tol,
                                      "rule": (f"excess re-measured with one text per batch within max({G['repeatability']:.0%}, "
                                               f"{G['repeatability_spread']:g} x the floor's spread)")}
        else:
            gates["repeatability"] = {"pass": True, "value": None, "rule": "not available for this backend or dose"}
        return gates, flags

    def _contraindications(self, ver, gen, tox, tau, tau_tail):
        c, G = [], self.GATES
        for s, r in ver.get("slices", {}).items():
            if r["excess"] >= G["caution"] * tau:
                c.append(f"caution on {s}: uses {r['excess'] / tau:.0%} of the mean budget")
            if r["worst_text_excess"] >= G["caution"] * tau_tail:
                c.append(f"caution on {s}: its worst text uses {r['worst_text_excess'] / tau_tail:.0%} of the worst-text budget")
        for s, g in gen.items():
            if g["excess"] >= G["caution"] * tau:
                c.append(f"caution on {s} under generation: uses {g['excess'] / tau:.0%} of the mean budget")
            if g["ratio_to_teacher_forced"] == g["ratio_to_teacher_forced"] and g["ratio_to_teacher_forced"] >= G["compounding_caution"]:
                c.append(f"caution on {s}: side effects compound under generation ({g['ratio_to_teacher_forced']:.1f}x teacher-forced)")
        for k, o in tox.items():
            if o["grade"] == 2:
                c.append(f"caution: {k} shows grade 2 toxicity at the certified dose")
            if o["dlt"]:
                c.append(f"contraindicated where {k} matters: dose-limiting toxicity")
        return c

    def certify(self, intervention, budget=None, interactions=None):
        iv, d = intervention, intervention.delta
        nf = self.null_floors(d)
        tau, feasible = M.feasible_budget({s: nf[s] for s in self.monitor}, self.budgets, self.multiple, budget)
        tau_tail = self.tail_multiple * tau
        curv = self._curvature(d)
        own = self._own_floors(d, curv)
        grid = [M.dose_for_kl(tau, curv[self.monitor[0]]) * 2 ** (-k / 2) for k in self.grid_k]
        runs = {s: [self.b.kl_per_text(s, d * x) for x in grid] for s in self.monitor}
        kl = {s: [self._mean(r) for r in runs[s]] for s in self.monitor}
        cert, per = M.excess_certificate(grid, kl, own, tau, self.guard)
        tkl, tfl = {}, {}
        for s in self.monitor:
            arr = np.array([np.asarray(r[0]) for r in runs[s]])
            for i in range(arr.shape[1]):
                tkl[f"{s}#{i}"], tfl[f"{s}#{i}"] = arr[:, i].tolist(), float(self._null_text[s][i])
        tail_cert, _ = M.excess_certificate(grid, tkl, tfl, tau_tail, self.guard)
        tops = [x for x in (cert, tail_cert) if _finite(x)]
        esc = (self._escalate(d, min(tops), tau, tau_tail, own) if tops
               else {"stop": float("nan"), "trigger": "no excess certificate", "halvings": 0, "rule": "R1", "dlt": False})
        mcert, mparts = M.matrix_certificate([1.0], {s: [[c]] for s, c in curv.items()}, tau, self.guard, self.calibration)
        cands = {"excess_certificate": cert, "worst_text_certificate": tail_cert, "escalation_stop": esc["stop"],
                 "matrix_certificate": mcert}
        ok = {k: v for k, v in cands.items() if _finite(v)}
        if not _finite(esc["stop"]):
            ok = {}
        dose = min(ok.values()) if ok else 0.0
        binding = min(ok, key=ok.get) if ok else None
        ver = self._verify(d, dose, tau, tau_tail, nf)
        tox = self._organs(d * dose, half=1) if (self.panels and dose > 0) else ({} if not self.panels else
                                                                                   self._organs(None, half=1))
        gen = self._generation(d, dose, ver, nf)
        ind = self._indication(iv, d, grid, dose)
        gates, flags = self._gates(d, dose, tau, tau_tail, feasible, cert, mparts, esc, ver, own, gen, tox, ind, iv)
        refused = [k for k, g in gates.items() if not g["pass"]]
        status = "refused" if refused else "certified"
        issued = 0.0 if refused else dose
        contra = self._contraindications(ver, gen, tox, tau, tau_tail)
        self._log(f"{iv.name}: {status.upper()} dose {issued:.4g} ({binding}), budget {tau}"
                  + (f" | failed gates: {', '.join(refused)}" if refused else "")
                  + (f" | flags: {'; '.join(flags)}" if flags else ""))
        return Monograph(
            status=status, gates=gates, flags=flags,
            intervention={"name": iv.name, "description": iv.description, "fingerprint": self.b.fingerprint(d),
                          "norm": math.sqrt(_dot(d, d)), "control": iv.control},
            model=self.b.describe(),
            slices={"monitor": {s: self.b.slice_info(s) for s in self.monitor},
                    "verify": {s: self.b.slice_info(s) for s in self.verify}},
            precision={"null_floors": nf, "null_floor_spread": dict(self._null_spread), "intervention_floors": own,
                       "calibration_factor": self.calibration, "feasibility_multiple": self.multiple, "curvature": curv},
            budget={"requested": budget, "used": tau, "worst_text": tau_tail, "feasible": feasible,
                    "unit": "KL in nats per token: exposure, excess over the floor (mean per slice, and per text)"},
            dose={"certified": issued, "candidate": dose, "binding": binding, "excess_certificate": cert,
                  "worst_text_certificate": tail_cert, "per_slice_budget_doses": per, "escalation_stop": esc["stop"],
                  "matrix_certificate": mparts, "guard": self.guard,
                  "unit": "multiplier applied to the intervention's delta (deployed patch = dose x delta)"},
            escalation={k: v for k, v in esc.items() if k != "stop"},
            verification=ver,
            exposure={"mean": {s: r["excess"] for s, r in ver.get("slices", {}).items()},
                      "worst_text": {s: r["worst_text_excess"] for s, r in ver.get("slices", {}).items()},
                      "generation": gen},
            toxicity={"organs": tox, "dlt_stop": esc.get("trigger") if esc.get("dlt") else None, "grades": M.GRADE_RULES,
                      "critical": sorted(self.critical)},
            indication=ind,
            contraindications=contra,
            monitoring_plan={
                "sample": "each monitor slice, the organ panels, and live traffic grouped by type, at a fixed cadence",
                "measure": "excess KL (mean and worst text) and organ breaks at the deployed dose, in deployment precision",
                "stop rule": "step the dose down at the budget, on R1 acceleration, or at any dose-limiting toxicity",
                "re-certify": "when the traffic mix, the model, its precision, its context (prompts, adapters) or the intervention changes"},
            interactions=interactions,
            provenance={"package": "starbody-certify", "version": __version__, "created": now(),
                        "evidence": "Starbody Law Tests 2-3 and their post hoc analyses; toxicity model added in 0.2 (untested by gates)"})

    def certify_combination(self, interventions, weights, budget=None, name=None):
        """Certify sum_i w_i delta_i: measured like any intervention, with its interaction matrices attached. Its
        indication is the union of its members' indications; it is a control only if every member is."""
        inter = self.interactions(interventions)
        inter["weights"] = [float(w) for w in weights]
        delta = sum(float(w) * iv.delta for w, iv in zip(weights, interventions))
        items = [it for iv in interventions if iv.indication for it in iv.indication]
        nm = name or " + ".join(f"{float(w):.2f}*{iv.name}" for w, iv in zip(weights, interventions))
        combo = Intervention(nm, delta, "combination", indication=items or None,
                             control=all(iv.control for iv in interventions))
        return self.certify(combo, budget=budget, interactions=inter)

    @staticmethod
    def balanced_weights(interactions):
        """Weights under which each member, alone, has the same worst-slice side effect: w_i = 1 / sqrt(max_s G_s[i,i]),
        scaled so the largest weight is 1."""
        k = len(interactions["members"])
        worst = [max(np.atleast_2d(g)[i][i] for g in interactions["grams"].values()) for i in range(k)]
        w = np.array([1 / math.sqrt(max(x, 1e-30)) for x in worst])
        return (w / w.max()).tolist()

def formulary_table(monographs):
    """Markdown table summarising monographs side by side."""
    rows = ["| Intervention | Status | Dose | Bound by | Worst organ grade | Generation ratio | Therapeutic index | Flags |",
            "|---|---|---|---|---|---|---|---|"]
    for m in monographs:
        grades = [o["grade"] for o in (m.toxicity or {}).get("organs", {}).values() if o["grade"] is not None]
        gens = [g.get("ratio_to_teacher_forced") for g in (m.exposure or {}).get("generation", {}).values()]
        gens = [g for g in gens if g == g]
        ti = (m.indication or {}).get("therapeutic_index")
        rows.append(f"| {m.intervention['name']} | {m.status} | {m.dose['certified']:.4g} | {m.dose.get('binding')} | "
                    f"{max(grades) if grades else '-'} | {f'{max(gens):.2f}x' if gens else '-'} | "
                    f"{f'{ti:.2f}' if ti else ('control' if (m.indication or {}).get('control') else '-')} | "
                    f"{'; '.join(m.flags) or '-'} |")
    return "\n".join(rows)
