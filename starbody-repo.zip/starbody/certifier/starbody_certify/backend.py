"""TorchBackend: measurement on a Hugging Face causal LM (decoder layers at model.model.layers), with logits from a
float32 copy of the unembedding and KL arithmetic in float64, exactly as in Starbody's Law Tests 2 and 3."""
import contextlib
import hashlib

class TorchBackend:
    def __init__(self, model, tokenizer, slices, max_tokens=64, batch_size=4, model_id=None):
        import torch
        import torch.nn.functional as F
        self.torch, self.F = torch, F
        self.model, self.tok = model, tokenizer
        tokenizer.padding_side = "left"
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        self.layers = model.model.layers
        self.n_layers, self.width = len(self.layers), model.config.hidden_size
        self.device = next(model.parameters()).device
        self.deploy_dtype = next(model.parameters()).dtype
        self.W_U32 = model.get_output_embeddings().weight.detach().float()
        self.softcap = getattr(model.config, "final_logit_softcapping", None)
        self.model_id = model_id or getattr(model.config, "_name_or_path", "?")
        self.max_tokens, self.batch_size = max_tokens, batch_size
        self.texts = {k: list(v) for k, v in slices.items()}
        self._batches = {}
        model.eval()
        model.requires_grad_(False)

    # ---- plumbing ----------------------------------------------------------------------------------------------
    def _encode(self, name):
        if name not in self._batches:
            out, t = [], self.texts[name]
            for i in range(0, len(t), self.batch_size):
                enc = self.tok(t[i:i + self.batch_size], return_tensors="pt", padding=True, truncation=True,
                               max_length=self.max_tokens)
                ids, mask = enc["input_ids"].to(self.device), enc["attention_mask"].to(self.device)
                out.append((ids, mask, (mask.cumsum(-1) - 1).clamp(min=0)))
            self._batches[name] = out
        return self._batches[name]

    def _logits(self, ids, mask, pos):
        h = self.model.model(input_ids=ids, attention_mask=mask, position_ids=pos, use_cache=False).last_hidden_state
        z = self.F.linear(h.float(), self.W_U32)
        return self.softcap * self.torch.tanh(z / self.softcap) if self.softcap else z

    @contextlib.contextmanager
    def _patch(self, delta):
        handles = []
        if delta is not None:
            per_seq = delta.dim() == 3
            def make(l):
                def hook(module, inputs, output):
                    hs = output[0] if isinstance(output, tuple) else output
                    d = (delta[:, l, None, :] if per_seq else delta[l]).to(hs.dtype)
                    hs = hs + d
                    return (hs, *output[1:]) if isinstance(output, tuple) else hs
                return hook
            handles = [layer.register_forward_hook(make(l)) for l, layer in enumerate(self.layers)]
        try:
            yield
        finally:
            for h in handles:
                h.remove()

    # ---- the backend interface ---------------------------------------------------------------------------------
    def mean_kl_rebatched(self, name, delta):
        """The same measurement with one text per batch (no padding interplay): the repeatability gate."""
        key = (name, "single")
        if key not in self._batches:
            saved, self.batch_size = self.batch_size, 1
            self._batches[key] = self._encode_uncached(name)
            self.batch_size = saved
        return self.mean_kl(name, delta, batches=self._batches[key])

    def _encode_uncached(self, name):
        out, t = [], self.texts[name]
        for i in range(0, len(t), self.batch_size):
            enc = self.tok(t[i:i + self.batch_size], return_tensors="pt", padding=True, truncation=True,
                           max_length=self.max_tokens)
            ids, mask = enc["input_ids"].to(self.device), enc["attention_mask"].to(self.device)
            out.append((ids, mask, (mask.cumsum(-1) - 1).clamp(min=0)))
        return out

    def kl_per_text(self, name, delta, batches=None):
        """Per-text mean KL(base || patched) and token counts, in the model's current precision (float64 sums)."""
        torch, F = self.torch, self.F
        per, ntok = [], []
        with torch.no_grad():
            for ids, mask, pos in (batches or self._encode(name)):
                base = F.log_softmax(self._logits(ids, mask, pos).double(), dim=-1)
                with self._patch(delta):
                    pat = F.log_softmax(self._logits(ids, mask, pos).double(), dim=-1)
                kl = (base.exp() * (base - pat)).sum(dim=-1) * mask.double()
                n = mask.sum(dim=1).double()
                per += (kl.sum(dim=1) / n.clamp(min=1)).cpu().tolist()
                ntok += n.cpu().tolist()
                del base, pat, kl
        import numpy as np
        return np.array(per), np.array(ntok)

    def mean_kl(self, name, delta, batches=None):
        per, ntok = self.kl_per_text(name, delta, batches)
        return float((per * ntok).sum() / ntok.sum())

    def score_items(self, items, delta=None, batch_size=16):
        """Margin per item: log-likelihood of the answer minus the best other choice, after the prompt."""
        import numpy as np
        torch, F = self.torch, self.F
        seqs, owner = [], []
        for i, it in enumerate(items):
            p_ids = self.tok(it["prompt"], add_special_tokens=True)["input_ids"]
            for c, ch in enumerate(it["choices"]):
                c_ids = self.tok(ch, add_special_tokens=False)["input_ids"]
                seqs.append((p_ids + c_ids, len(c_ids)))
                owner.append((i, c))
        lp = np.full((len(items), max(len(it["choices"]) for it in items)), -np.inf)
        pad = self.tok.pad_token_id
        with torch.no_grad():
            for k in range(0, len(seqs), batch_size):
                chunk = seqs[k:k + batch_size]
                T = max(len(s) for s, _ in chunk)
                ids = torch.tensor([[pad] * (T - len(s)) + s for s, _ in chunk], device=self.device)
                mask = torch.tensor([[0] * (T - len(s)) + [1] * len(s) for s, _ in chunk], device=self.device)
                pos = (mask.cumsum(-1) - 1).clamp(min=0)
                with self._patch(delta):
                    logp = F.log_softmax(self._logits(ids, mask, pos).double(), dim=-1)
                for j, (s, nc) in enumerate(chunk):
                    tgt = torch.tensor(s[-nc:], device=self.device)
                    rows = logp[j, T - nc - 1:T - 1]
                    i, c = owner[k + j]
                    lp[i, c] = float(rows.gather(1, tgt[:, None]).sum())
                del logp
        ans = np.array([it["answer"] for it in items])
        best_other = np.array([max(lp[i, c] for c in range(len(it["choices"])) if c != it["answer"]) for i, it in enumerate(items)])
        return lp[np.arange(len(items)), ans] - best_other

    def generation_exposure(self, name, delta, n_prompts=16, prompt_tokens=24, new_tokens=48, temperature=1.0, seed=0):
        """Side effect under free generation: the patched model samples continuations; at every generated step, the
        full KL(base || patched) is computed in the context the patched model created, so compounding counts.
        Also the share of prompts whose greedy continuation diverges from the base model's, and where."""
        torch, F = self.torch, self.F
        texts = self.texts[name][:n_prompts]
        enc = self.tok(texts, return_tensors="pt", padding=True, truncation=True, max_length=prompt_tokens)
        ids, mask = enc["input_ids"].to(self.device), enc["attention_mask"].to(self.device)
        P = ids.shape[1]
        gen_kw = dict(max_new_tokens=new_tokens, pad_token_id=self.tok.pad_token_id)
        with torch.no_grad():
            torch.manual_seed(int(seed))
            with self._patch(delta):
                out = self.model.generate(input_ids=ids, attention_mask=mask, do_sample=temperature > 0,
                                          temperature=max(temperature, 1e-5), top_k=0, top_p=1.0, **gen_kw)
                greedy_p = self.model.generate(input_ids=ids, attention_mask=mask, do_sample=False, **gen_kw)
            greedy_b = self.model.generate(input_ids=ids, attention_mask=mask, do_sample=False, **gen_kw)
            new = out[:, P:]
            eos = self.tok.eos_token_id
            alive = torch.ones_like(new)
            if eos is not None:
                hit = (new == eos).int().cumsum(dim=1)
                alive = (hit - (new == eos).int() == 0).int()
            full_mask = torch.cat([mask, alive], dim=1)
            pos = (full_mask.cumsum(-1) - 1).clamp(min=0)
            base = F.log_softmax(self._logits(out, full_mask, pos).double(), dim=-1)
            with self._patch(delta):
                pat = F.log_softmax(self._logits(out, full_mask, pos).double(), dim=-1)
            kl = (base.exp() * (base - pat)).sum(dim=-1)[:, P - 1:-1] * alive.double()
            gen_kl = float(kl.sum() / alive.sum().clamp(min=1))
            gp, gb = greedy_p[:, P:], greedy_b[:, P:]
            L = min(gp.shape[1], gb.shape[1])
            diff = (gp[:, :L] != gb[:, :L])
            diverged = diff.any(dim=1)
            first = torch.where(diverged, diff.float().argmax(dim=1).float(), torch.full_like(diverged.float(), float(L)))
            del base, pat
        return {"kl_along_patched": gen_kl, "greedy_divergence": float(diverged.float().mean()),
                "first_divergence_mean": float(first.mean()), "prompts": len(texts), "new_tokens": new_tokens,
                "temperature": temperature}

    def hvp(self, name, vectors):
        """Hessian-vector products of mean per-token KL at zero patch (exact for these texts; never stored).
        A batch that runs out of memory is split in half; results are added only once a batch succeeds."""
        torch, F = self.torch, self.F
        out = [torch.zeros(self.n_layers, self.width, device=self.device) for _ in vectors]

        def one(batch):
            ids, mask, pos = batch
            try:
                with torch.no_grad():
                    base = F.log_softmax(self._logits(ids, mask, pos).double(), dim=-1)
                leaf = torch.zeros(self.n_layers, self.width, device=self.device, requires_grad=True)
                with torch.enable_grad():
                    with self._patch(leaf):
                        pat = F.log_softmax(self._logits(ids, mask, pos).double(), dim=-1)
                    m = mask.double()
                    kl = ((base.exp() * (base - pat)).sum(dim=-1) * m).sum()
                    g, = torch.autograd.grad(kl, leaf, create_graph=True)
                    hvs = [torch.autograd.grad((g * v).sum(), leaf, retain_graph=i < len(vectors) - 1)[0].detach().float()
                           for i, v in enumerate(vectors)]
                for i, hv in enumerate(hvs):
                    out[i] += hv
                return float(m.sum())
            except torch.cuda.OutOfMemoryError:
                if ids.shape[0] == 1:
                    raise
                torch.cuda.empty_cache()
                h = ids.shape[0] // 2
                return one((ids[:h], mask[:h], pos[:h])) + one((ids[h:], mask[h:], pos[h:]))

        ntok = sum(one(b) for b in self._encode(name))
        return [o / ntok for o in out]

    def null_like(self, delta, seed):
        torch = self.torch
        r = torch.randn(self.n_layers, self.width, generator=torch.Generator().manual_seed(int(seed))).to(self.device)
        return r / r.norm(dim=1, keepdim=True).clamp(min=1e-12) * delta.norm(dim=1, keepdim=True)

    @contextlib.contextmanager
    def precision(self, name):
        """'float32' converts the model in place (exact round trip for bfloat16 weights) and back afterwards."""
        if name != "float32" or self.deploy_dtype == self.torch.float32:
            yield
            return
        self.model.float()
        self.torch.cuda.empty_cache()
        try:
            yield
        finally:
            self.model.to(self.deploy_dtype)
            self.torch.cuda.empty_cache()

    def describe(self):
        return {"model_id": self.model_id, "precision": str(self.deploy_dtype).replace("torch.", ""),
                "layers": self.n_layers, "width": self.width, "vocabulary": int(self.W_U32.shape[0])}

    def slice_info(self, name):
        t = self.texts[name]
        return {"texts": len(t), "sha256": hashlib.sha256("\u241e".join(t).encode()).hexdigest()[:16]}

    def fingerprint(self, delta):
        return hashlib.sha256(delta.detach().float().cpu().numpy().tobytes()).hexdigest()[:16]
