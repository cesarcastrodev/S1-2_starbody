"""Standard text slices, as used in Starbody's Law Tests 2 and 3.

A: encyclopedic (WikiText-2, loaded with the datasets library), B: conversational, C: code, D: European Portuguese,
E: maths and science, F: procedural. B-F are built in. standard_slices() returns monitor slices (A-D, used for
certification) and verification slices (fresh A-D texts, plus E and F, which certification never sees).
"""
import random

MATRIX_B = [
    "Hi Sam, are you free on Thursday? I was thinking we could grab lunch near the station and then walk over to the bookshop. Let me know what time works for you, and whether Anna wants to join us.",
    "To reset your password, open the settings page, choose Account, and click Forgot password. You will receive an email with a link. The link expires after thirty minutes, so use it soon.",
    "Honestly, I didn't expect the hike to be that steep. My legs were shaking by the time we reached the top, but the view over the valley made it completely worth it.",
    "Can you pick up some milk, eggs and a loaf of bread on your way home? We're also out of coffee, but only if they have the brand we usually buy.",
    "Thanks for coming in today. Before we start, could you tell me a little about your previous job and what you enjoyed most about working there?",
    "The train to the airport leaves every twenty minutes from platform four. If you miss it, there is a bus outside the main entrance, although it takes about twice as long.",
    "I've been meaning to call you all week. Work has been chaotic, the car broke down on Monday, and the kids both caught a cold. How are things on your side?",
    "Please remember to switch off the lights and lock the back door when you leave the office. The cleaning staff will arrive at seven and will need access to the meeting rooms.",
    "We're planning a small get-together on Saturday afternoon. Nothing fancy, just a few friends in the garden. Feel free to bring someone along if you like.",
    "If the printer shows an error message, turn it off, wait ten seconds and turn it on again. If the problem continues, check that the paper tray is properly closed.",
    "Did you see the email from the landlord? Apparently they're replacing the windows next month, which means someone will need to be home on the Tuesday and Wednesday.",
    "Sorry for the late reply. I only just got back from my trip and I'm still catching up on messages. Can we move our call to tomorrow morning instead?",
    "The library will be closed for renovation from the first to the fifteenth of next month. Borrowed books can still be returned using the drop box next to the main entrance.",
    "My grandmother still writes letters by hand. Every birthday, a small envelope arrives with a card, a short poem and a few words about the weather in her village.",
    "When you get to the roundabout, take the second exit and keep going until you see a petrol station on your left. Our house is the third one after it, with the blue door.",
    "Could everyone please send me their availability for next week by Friday? I'd like to schedule the planning session before the end of the month.",
    "We've been having trouble with the internet connection all morning. The technician said it might be a problem with the cable outside, so they're sending someone this afternoon.",
    "I finally finished painting the spare room. It took three coats, but the colour came out exactly as I hoped. Now I just need to find a new lamp for the corner.",
    "Just a reminder that the dentist appointment is at half past nine tomorrow. Don't forget to bring the insurance card, because they asked for it last time.",
    "The meeting has been moved to the larger room on the second floor, since more people confirmed than we expected. Coffee will be available from a quarter to ten.",
    "We walked along the beach until the sun went down, talking about nothing in particular. It was one of those quiet evenings that you only appreciate afterwards.",
    "If you have any questions about the new timetable, please ask at the information desk. Staff will be available there every day between eight and six.",
    "I'm thinking of learning to play the piano this year. A friend recommended an online course, but I'm not sure whether I'd rather have a real teacher.",
    "The neighbours are moving out at the end of the week. They've offered us their old bookshelf and a couple of plants, which is very kind of them.",
]
MATRIX_C = [
    "def mean(values):\n    total = sum(values)\n    return total / len(values) if values else 0.0\n\nprint(mean([3, 5, 8]))",
    "for i in range(10):\n    if i % 2 == 0:\n        print(f\"{i} is even\")\n    else:\n        print(f\"{i} is odd\")",
    "const items = [4, 8, 15, 16, 23, 42];\nconst doubled = items.map(x => x * 2);\nconsole.log(doubled.filter(x => x > 20));",
    "SELECT name, COUNT(*) AS orders\nFROM customers c JOIN orders o ON o.customer_id = c.id\nGROUP BY name\nORDER BY orders DESC\nLIMIT 10;",
    "import json\n\nwith open(\"config.json\") as f:\n    config = json.load(f)\nport = config.get(\"port\", 8080)\nprint(\"Listening on\", port)",
    "class Stack:\n    def __init__(self):\n        self.items = []\n    def push(self, x):\n        self.items.append(x)\n    def pop(self):\n        return self.items.pop()",
    "function debounce(fn, wait) {\n  let timer;\n  return (...args) => {\n    clearTimeout(timer);\n    timer = setTimeout(() => fn(...args), wait);\n  };\n}",
    "#!/bin/bash\nfor file in *.txt; do\n  echo \"Processing $file\"\n  wc -l \"$file\"\ndone",
    "def fibonacci(n):\n    a, b = 0, 1\n    for _ in range(n):\n        a, b = b, a + b\n    return a\n\nprint([fibonacci(k) for k in range(10)])",
    "try:\n    value = int(input(\"Enter a number: \"))\nexcept ValueError:\n    print(\"That was not a number.\")\nelse:\n    print(\"Square:\", value ** 2)",
    "let total = 0;\nfor (const price of [9.99, 4.5, 12]) {\n  total += price;\n}\nconsole.log(`Total: ${total.toFixed(2)}`);",
    "CREATE TABLE visits (\n  id INTEGER PRIMARY KEY,\n  name TEXT NOT NULL,\n  visit_date DATE,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);",
    "import numpy as np\n\nx = np.linspace(0, 1, 101)\ny = np.sin(2 * np.pi * x)\nprint(round(float(y.max()), 3))",
    "words = text.lower().split()\ncounts = {}\nfor w in words:\n    counts[w] = counts.get(w, 0) + 1\ntop = sorted(counts.items(), key=lambda kv: -kv[1])[:5]",
    "async function load(url) {\n  const response = await fetch(url);\n  if (!response.ok) throw new Error(response.status);\n  return response.json();\n}",
    "git checkout -b feature/login\ngit add .\ngit commit -m \"Add login form\"\ngit push origin feature/login",
    "def is_prime(n):\n    if n < 2:\n        return False\n    for d in range(2, int(n ** 0.5) + 1):\n        if n % d == 0:\n            return False\n    return True",
    "const user = { name: \"Ana\", age: 31 };\nconst { name, ...rest } = user;\nconsole.log(name, Object.keys(rest));",
    "with open(\"data.csv\") as f:\n    header = f.readline().strip().split(\",\")\n    rows = [line.strip().split(\",\") for line in f]\nprint(len(rows), \"rows\", header)",
    "UPDATE accounts\nSET balance = balance - 50\nWHERE id = 7 AND balance >= 50;\nCOMMIT;",
    "def retry(fn, attempts=3):\n    for i in range(attempts):\n        try:\n            return fn()\n        except Exception as e:\n            print(\"attempt\", i + 1, \"failed:\", e)\n    raise RuntimeError(\"gave up\")",
    "matrix = [[1, 2, 3], [4, 5, 6]]\ntransposed = [list(row) for row in zip(*matrix)]\nprint(transposed)",
    "document.querySelector(\"#save\").addEventListener(\"click\", () => {\n  window.lastDraft = editor.value;\n  showMessage(\"Saved\");\n});",
    "from collections import deque\n\nqueue = deque([1, 2, 3])\nqueue.append(4)\nqueue.popleft()\nprint(list(queue))",
]
MATRIX_D = [
    "Olá Rita, estás livre na quinta-feira à tarde? Pensei que podíamos almoçar perto da estação e depois passar pela livraria. Diz-me a que horas te dá jeito e se a Ana também quer vir.",
    "Para alterar a palavra-passe, abra as definições, escolha a opção Conta e carregue em Esqueci-me da palavra-passe. Vai receber um e-mail com uma ligação válida durante trinta minutos.",
    "O comboio para o aeroporto parte de vinte em vinte minutos da linha quatro. Se o perder, há um autocarro à porta da estação, embora demore quase o dobro do tempo.",
    "A biblioteca municipal vai estar fechada para obras durante a primeira quinzena do próximo mês. Os livros emprestados podem ser devolvidos na caixa junto à entrada principal.",
    "Ontem fomos até à praia ao fim da tarde e ficámos a ver o pôr do sol. Estava um pouco de vento, mas a água estava surpreendentemente quente para esta altura do ano.",
    "Podes passar pelo supermercado quando vieres para casa? Faltam leite, ovos e pão, e também já não temos café, mas só se houver da marca que costumamos comprar.",
    "Évora é uma cidade alentejana conhecida pelo seu centro histórico, pelas muralhas e por um templo romano que continua de pé no meio da praça principal.",
    "Por favor, não se esqueçam de desligar as luzes e trancar a porta das traseiras ao sair do escritório. A equipa de limpeza chega às sete e precisa de acesso às salas.",
    "A reunião passou para a sala maior do segundo andar, porque confirmaram mais pessoas do que esperávamos. Haverá café disponível a partir das dez menos um quarto.",
    "Se a impressora mostrar uma mensagem de erro, desligue-a, espere dez segundos e volte a ligá-la. Se o problema continuar, verifique se a gaveta do papel está bem fechada.",
    "A minha avó ainda escreve cartas à mão. Em cada aniversário chega um pequeno envelope com um postal, um poema curto e algumas palavras sobre o tempo na aldeia.",
    "Desculpa só responder agora. Voltei ontem de viagem e ainda estou a pôr as mensagens em dia. Podemos passar a nossa chamada para amanhã de manhã?",
    "O rio nasce na serra e atravessa várias vilas antes de chegar ao mar. Durante o inverno, as cheias são frequentes nas zonas mais baixas do vale.",
    "Quando chegar à rotunda, saia na segunda saída e continue até ver uma bomba de gasolina à esquerda. A nossa casa é a terceira depois dela, a da porta azul.",
    "Estou a pensar aprender a tocar piano este ano. Um amigo recomendou-me um curso online, mas ainda não sei se prefiro ter aulas com um professor a sério.",
    "Os vizinhos vão mudar-se no fim da semana. Ofereceram-nos uma estante antiga e duas plantas, o que foi muito simpático da parte deles.",
    "O museu reabriu depois de dois anos de obras, com novas salas dedicadas à história da navegação e uma coleção de mapas antigos que nunca tinha sido exposta.",
    "Lembro-te que a consulta no dentista é amanhã às nove e meia. Não te esqueças do cartão do seguro, porque da última vez pediram-no à entrada.",
    "Ainda bem que trouxeste o guarda-chuva. Segundo a previsão, vai chover a tarde toda e só deve abrir um pouco ao fim do dia.",
    "Durante o século dezanove, a vila cresceu à volta das fábricas de tecidos, que atraíam trabalhadores de todas as aldeias da região.",
    "Se tiver dúvidas sobre os novos horários, dirija-se ao balcão de informações. Os funcionários estão lá todos os dias entre as oito e as dezoito horas.",
    "Acabei finalmente de pintar o quarto de hóspedes. Foram precisas três demãos, mas a cor ficou exatamente como eu queria. Agora só falta um candeeiro novo.",
    "A internet esteve em baixo toda a manhã. O técnico disse que pode ser um problema no cabo da rua, por isso vem cá alguém durante a tarde.",
    "No mercado de sábado havia fruta da época, queijos da serra e pão acabado de sair do forno. Comprámos mais do que precisávamos, como sempre.",
]
MATRIX_E = [
    "A train leaves the station at 9:15 and travels 180 kilometres at an average speed of 72 kilometres per hour. At what time does it arrive?",
    "Water boils at 100 degrees Celsius at sea level, but at higher altitudes the boiling point drops because the air pressure is lower.",
    "If a rectangle has a perimeter of 36 centimetres and its length is twice its width, what are its length and width?",
    "Photosynthesis converts carbon dioxide and water into glucose and oxygen, using energy captured from sunlight by chlorophyll.",
    "A shop sells notebooks for 2.40 euros each. How much change does a customer receive from a 20 euro note after buying six notebooks?",
    "The speed of sound in air is about 343 metres per second, so thunder heard three seconds after lightning means the storm is about a kilometre away.",
    "Maria has three times as many marbles as Tom. Together they have 48 marbles. How many marbles does each of them have?",
    "An enzyme lowers the activation energy of a reaction, which is why many biological reactions proceed quickly at body temperature.",
    "A recipe needs 250 grams of flour for 4 servings. How much flour is needed to make 10 servings of the same recipe?",
    "The Moon takes about 27 days to orbit the Earth, and the same side always faces us because its rotation is locked to its orbit.",
    "A cyclist rides 12 kilometres in 40 minutes. At the same pace, how long will it take the cyclist to ride 30 kilometres?",
    "Sound waves are longitudinal, meaning the particles of the medium vibrate in the same direction in which the wave travels.",
    "The sum of three consecutive even numbers is 78. What is the largest of the three numbers, and how can you check the answer?",
    "Iron rusts when it reacts with oxygen and water, forming hydrated iron oxide that flakes away and exposes fresh metal underneath.",
    "A tank holds 1,200 litres and is being filled at 15 litres per minute. How long will it take to fill the tank from empty?",
    "Plants grown in the dark become pale and tall because they lack chlorophyll and stretch toward any light that is available.",
]
MATRIX_F = [
    "To repot a houseplant, water it the day before, ease it out of the old pot, loosen the roots gently and set it in fresh compost slightly deeper than before.",
    "For a quick tomato sauce, soften a chopped onion in olive oil, add two cloves of garlic, pour in a tin of tomatoes and simmer for twenty minutes before seasoning.",
    "To change a bicycle tyre, release the brake, remove the wheel, lever one side of the tyre off the rim, replace the inner tube and pump it to the pressure on the sidewall.",
    "Before painting a wall, fill any cracks, sand them smooth, wipe away the dust and apply a coat of primer, letting it dry completely before the first layer of paint.",
    "To make pancakes, whisk two eggs with a cup of milk, fold in a cup of flour and a pinch of salt, rest the batter for ten minutes and cook spoonfuls in a hot buttered pan.",
    "To back up your phone, connect it to a charger and a wireless network, open the settings, choose the backup option and wait until the progress bar reaches the end.",
    "When brewing tea, warm the pot first, use one teaspoon of leaves per cup, pour water just off the boil and steep for three to five minutes before straining.",
    "To clean a cast-iron pan, rinse it with hot water while it is still warm, scrub off any residue with salt, dry it on the stove and rub a thin layer of oil over it.",
    "To plant garlic, separate the bulb into cloves, push each one pointed end up into loose soil about five centimetres deep and leave a hand's width between them.",
    "For a basic bread dough, mix flour, water, yeast and salt, knead for ten minutes until smooth, let it rise until doubled, shape it and bake it in a hot oven.",
    "To fold a fitted sheet, tuck the corners into each other in pairs, lay the sheet flat, fold the edges inward and then fold it into a neat rectangle.",
    "Before a long drive, check the tyre pressure, top up the windscreen washer fluid, test the lights and make sure the spare wheel and jack are in the boot.",
    "To descale a kettle, fill it halfway with equal parts water and vinegar, bring it to the boil, leave it for an hour, then rinse it thoroughly several times.",
    "To sharpen a kitchen knife on a whetstone, soak the stone, hold the blade at a shallow angle and draw it across the stone in smooth strokes, alternating sides.",
    "For a simple vinaigrette, whisk three parts olive oil with one part vinegar, add a spoonful of mustard and a pinch of salt, and taste before dressing the salad.",
    "To hang a picture, mark the height on the wall, drill a small hole, insert a plug and a screw, then hook the wire over the screw and check that the frame is level.",
]


def load_wikitext(split, n, seed=4242):
    from datasets import load_dataset
    last = None
    for src in ("Salesforce/wikitext", "wikitext"):
        try:
            ds = load_dataset(src, "wikitext-2-raw-v1", split=split)
            paras = [t.strip() for t in ds["text"] if len(t.strip()) > 200 and not t.strip().startswith("=")]
            random.Random(seed).shuffle(paras)
            return paras[:n]
        except Exception as e:          # try the next mirror
            last = e
    raise RuntimeError(f"WikiText-2 not reachable: {last}")

def standard_slices(seed=4242):
    """(monitor, verify): dictionaries of slice name -> texts."""
    g = random.Random(seed + 7)
    def halves(texts):
        t = list(texts)
        g.shuffle(t)
        return t[:len(t) // 2], t[len(t) // 2:]
    B, C, D = halves(MATRIX_B), halves(MATRIX_C), halves(MATRIX_D)
    monitor = {"A": load_wikitext("train", 32, seed), "B": B[0], "C": C[0], "D": D[0]}
    verify = {"A_heldout": load_wikitext("test", 100, seed), "B_heldout": B[1], "C_heldout": C[1], "D_heldout": D[1],
              "E": list(MATRIX_E), "F": list(MATRIX_F)}
    return monitor, verify


# ---- organ panels: judge-free function tests ----------------------------------------------------------------------
# Each item is {"prompt", "choices", "answer"}; scoring compares the log-likelihood of each choice after the prompt.

CAPITALS = [("France", "Paris"), ("Germany", "Berlin"), ("Italy", "Rome"), ("Spain", "Madrid"), ("Portugal", "Lisbon"),
            ("Japan", "Tokyo"), ("China", "Beijing"), ("Russia", "Moscow"), ("Canada", "Ottawa"), ("Australia", "Canberra"),
            ("Brazil", "Brasília"), ("Argentina", "Buenos Aires"), ("Mexico", "Mexico City"), ("Egypt", "Cairo"),
            ("Kenya", "Nairobi"), ("Nigeria", "Abuja"), ("India", "New Delhi"), ("Pakistan", "Islamabad"),
            ("Turkey", "Ankara"), ("Greece", "Athens"), ("Poland", "Warsaw"), ("Sweden", "Stockholm"), ("Norway", "Oslo"),
            ("Finland", "Helsinki"), ("Denmark", "Copenhagen"), ("the Netherlands", "Amsterdam"), ("Belgium", "Brussels"),
            ("Austria", "Vienna"), ("Ireland", "Dublin"), ("Hungary", "Budapest"), ("the Czech Republic", "Prague"),
            ("Romania", "Bucharest"), ("Iran", "Tehran"), ("Iraq", "Baghdad"), ("Saudi Arabia", "Riyadh"),
            ("Thailand", "Bangkok"), ("Vietnam", "Hanoi"), ("Indonesia", "Jakarta"), ("the Philippines", "Manila"),
            ("South Korea", "Seoul"), ("Chile", "Santiago"), ("Peru", "Lima"), ("Colombia", "Bogotá"),
            ("Venezuela", "Caracas"), ("Cuba", "Havana"), ("Morocco", "Rabat"), ("Ethiopia", "Addis Ababa"),
            ("New Zealand", "Wellington")]

CAPITAIS_PT = [("França", "Paris"), ("Alemanha", "Berlim"), ("Itália", "Roma"), ("Espanha", "Madrid"),
               ("Portugal", "Lisboa"), ("Japão", "Tóquio"), ("China", "Pequim"), ("Grécia", "Atenas"),
               ("Polónia", "Varsóvia"), ("Suécia", "Estocolmo"), ("Noruega", "Oslo"), ("Áustria", "Viena"),
               ("Irlanda", "Dublin"), ("Hungria", "Budapeste"), ("Turquia", "Ancara"), ("Peru", "Lima"),
               ("Chile", "Santiago"), ("Cuba", "Havana"), ("Marrocos", "Rabat"), ("Brasil", "Brasília"),
               ("Argentina", "Buenos Aires"), ("Bélgica", "Bruxelas"), ("Suíça", "Berna"), ("Reino Unido", "Londres"),
               ("Colômbia", "Bogotá"), ("Venezuela", "Caracas"), ("Coreia do Sul", "Seul"), ("Indonésia", "Jacarta"),
               ("Filipinas", "Manila"), ("Nova Zelândia", "Wellington")]

def _choice_item(prompt, correct, distractors, rng):
    choices = [correct] + list(distractors)
    order = list(range(len(choices)))
    rng.shuffle(order)
    return {"prompt": prompt, "choices": [choices[i] for i in order], "answer": order.index(0)}

def panel_arithmetic(n=120, seed=0):
    rng = random.Random(seed + 11)
    items = []
    for _ in range(n):
        a, b = rng.randint(11, 89), rng.randint(11, 89)
        s = a + b
        items.append(_choice_item(f"{a} + {b} =", f" {s}", [f" {s + 1}", f" {s - 1}", f" {s + 10}"], rng))
    return items

def panel_capitals(seed=0):
    rng = random.Random(seed + 12)
    caps = [c for _, c in CAPITALS]
    return [_choice_item(f"The capital of {country} is", f" {cap}",
                         [f" {x}" for x in rng.sample([c for c in caps if c != cap], 3)], rng) for country, cap in CAPITALS]

def panel_capitals_pt(seed=0):
    rng = random.Random(seed + 13)
    caps = [c for _, c in CAPITAIS_PT]
    return [_choice_item(f"País: {country}. Capital:", f" {cap}",
                         [f" {x}" for x in rng.sample([c for c in caps if c != cap], 3)], rng) for country, cap in CAPITAIS_PT]

_SUBJECTS = [("The key", "The keys"), ("The author", "The authors"), ("The dog", "The dogs"), ("The student", "The students"),
             ("The doctor", "The doctors"), ("The house", "The houses"), ("The child", "The children"),
             ("The teacher", "The teachers"), ("The report", "The reports"), ("The nurse", "The nurses")]
_ATTRACTORS = [("near the cabinets", "near the cabinet"), ("of the managers", "of the manager"),
               ("behind the trees", "behind the tree"), ("with the books", "with the book")]
_VERBS = [(" is", " are"), (" was", " were"), (" has", " have")]

def panel_agreement(n=120, seed=0):
    """Subject-verb agreement across an attractor of the opposite number."""
    rng = random.Random(seed + 14)
    items = []
    for _ in range(n):
        sing, plur = rng.choice(_SUBJECTS)
        att_for_sing, att_for_plur = rng.choice(_ATTRACTORS)
        vs, vp = rng.choice(_VERBS)
        if rng.random() < 0.5:
            items.append({"prompt": f"{sing} {att_for_sing}", "choices": [vs, vp], "answer": 0})
        else:
            items.append({"prompt": f"{plur} {att_for_plur}", "choices": [vs, vp], "answer": 1})
    return items

_FUNCS = ["len", "max", "min", "sum", "abs", "sorted", "list", "str", "int", "round"]

def panel_brackets(n=120, seed=0):
    """Closing nested calls in code."""
    rng = random.Random(seed + 15)
    items = []
    for _ in range(n):
        depth = rng.choice([2, 3])
        fs = rng.sample(_FUNCS, depth)
        prompt = "result = " + "(".join(fs) + "(items"
        correct = ")" * depth
        wrong = sorted({")" * (depth - 1), ")" * (depth + 1), ")" * (depth - 1) + "]"} - {correct})
        items.append(_choice_item(prompt, correct, wrong[:3], rng))
    return items

def standard_panels(seed=0):
    """Organ name -> items. Facts, arithmetic, grammar, code syntax and a second language."""
    return {"facts": panel_capitals(seed), "arithmetic": panel_arithmetic(120, seed), "grammar": panel_agreement(120, seed),
            "code": panel_brackets(120, seed), "portuguese": panel_capitals_pt(seed)}
