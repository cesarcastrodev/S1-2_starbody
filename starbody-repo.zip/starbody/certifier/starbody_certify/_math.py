"""Pure-numpy mathematics of certification. No model, no torch: everything here is unit-tested directly.

The rules come from Starbody's Law Tests 2 and 3 and their post hoc analyses:
- side effects of a residual patch grow as dose^2 in float32 (exponent 2.00 in four models);
- in bfloat16, measured KL = a floor + the true effect, possibly inflated by a model-specific factor;
- certificates are fitted on the excess over the floor, near the budget, never on small doses;
- the escalation's acceleration check runs only where the excess is well above the floor (rule R1);
- matrix (curvature) certificates take the more conservative of the raw and the calibrated matrix.
"""
import math
import numpy as np

def escalation_ladder(top, steps=7):
    """Doses from top / 2^((steps-1)/2) up to top, in steps of sqrt(2)."""
    return [top * 2 ** (-k / 2) for k in range(steps - 1, -1, -1)]

def dose_for_kl(kl_target, curvature):
    """Dose s at which the quadratic law 0.5 * curvature * s^2 reaches kl_target."""
    return math.sqrt(2 * kl_target / max(float(curvature), 1e-30))

def excess_certificate(grid, kl_by_slice, floors, tau, guard):
    """Certified dose from a measured dose grid, fitted on the excess over each slice's floor.

    Per slice, eta^2 = median(excess / dose^2) over grid points with excess in [max(2 x floor, tau/16), tau/2];
    if fewer than two points qualify, the two points with excess > 2 x floor nearest tau/4 are used.
    Returns (dose, per-slice budget doses); dose is nan if no slice could be fitted."""
    s = np.asarray(grid, dtype=float)
    per = {}
    for name, k in kl_by_slice.items():
        f = floors[name]
        e = np.asarray(k, dtype=float) - f
        use = (e >= max(2 * f, tau / 16)) & (e <= tau / 2)
        if use.sum() < 2:
            cand = np.nonzero(e > 2 * f)[0]
            use = np.zeros(len(e), dtype=bool)
            if len(cand) >= 2:
                use[cand[np.argsort(np.abs(np.log(e[cand]) - math.log(tau / 4)))[:2]]] = True
        if use.sum() >= 2:
            eta2 = float(np.median(e[use] / s[use] ** 2))
            per[name] = math.sqrt(tau / eta2) if eta2 > 0 else float("inf")
        else:
            per[name] = float("nan")
    usable = [v for v in per.values() if np.isfinite(v)]
    return (min(usable) / guard if usable else float("nan")), per

def escalate_r1(ladder, excess_by_slice, floors, tau, accel=2.2, noise_multiple=10.0):
    """Monitored escalation, rule R1: stop at the previous dose when any excess reaches tau, or when the local
    exponent of the excess reaches `accel` where both excesses are at least noise_multiple x floor and the
    newer one is at most tau/4. Below that zone the excess is a difference of two noisy numbers and its slope
    is not trusted (Law Test 3's false triggers). Returns (index of the last safe dose, trigger or None)."""
    for i in range(1, len(ladder)):
        for name, e in excess_by_slice.items():
            if e[i] >= tau:
                return i - 1, f"budget reached on {name}"
            lo = noise_multiple * floors[name]
            if e[i - 1] >= lo and lo <= e[i] <= tau / 4 and e[i - 1] > 0:
                if math.log(e[i] / e[i - 1]) / math.log(ladder[i] / ladder[i - 1]) >= accel:
                    return i - 1, f"acceleration on {name}"
    return len(ladder) - 1, None

def feasible_budget(floors, budgets=(0.02, 0.05, 0.1), multiple=4.0, requested=None):
    """The requested budget if it is at least `multiple` x the largest floor; otherwise the smallest feasible
    budget in `budgets`. Returns (budget, feasible)."""
    need = multiple * max(floors.values())
    if requested is not None:
        return float(requested), bool(requested >= need)
    ok = [t for t in sorted(budgets) if t >= need]
    return (ok[0], True) if ok else (max(budgets), False)

def matrix_certificate(w, grams, tau, guard, calibration=None):
    """Dose for patch D w certified by the curvature matrices: min over slices of sqrt(2 tau / w^T G w) / guard.
    With a calibration factor c (matrix curvature / measured float32 curvature), the calibrated dose is
    raw x sqrt(c); the certificate is the more conservative of the two."""
    w = np.atleast_1d(np.asarray(w, dtype=float))
    raw = min(math.sqrt(2 * tau / max(float(w @ np.atleast_2d(G) @ w), 1e-30)) for G in grams.values()) / guard
    cal = raw * math.sqrt(calibration) if calibration else raw
    return min(raw, cal), {"raw": raw, "calibrated": cal if calibration else None}

def _ridge(M, k, eps=1e-3):
    return M + eps * np.trace(M) / k * np.eye(k)

def computed_guards(grams):
    """Leave-one-slice-out guard factors from the matrices: for single patches (diagonal ratios) and over every
    combination in the subspace (largest generalized eigenvalue between ordered pairs of slices)."""
    from scipy.linalg import eigh
    G = {n: np.atleast_2d(np.asarray(v, dtype=float)) for n, v in grams.items()}
    names = list(G)
    if len(names) < 2:
        return {"single": 1.0, "combinations": 1.0}
    k = next(iter(G.values())).shape[0]
    r = [G[gp][i, i] / max(max(G[g][i, i] for g in names if g != gp), 1e-30) for i in range(k) for gp in names]
    gen = [eigh(G[a], _ridge(G[b], k), eigvals_only=True)[-1] for a in names for b in names if a != b]
    return {"single": max(1.0, math.sqrt(max(r))), "combinations": max(1.0, math.sqrt(max(gen)))}

def adversarial_combinations(grams):
    """Per slice, the combination with the most side effect there relative to the mean of the other slices."""
    from scipy.linalg import eigh
    G = {n: np.atleast_2d(np.asarray(v, dtype=float)) for n, v in grams.items()}
    k = next(iter(G.values())).shape[0]
    out = {}
    for name in G:
        others = [G[h] for h in G if h != name]
        if not others:
            continue
        vals, vecs = eigh(G[name], _ridge(np.mean(others, axis=0), k))
        w = vecs[:, -1] / np.linalg.norm(vecs[:, -1])
        out[name] = {"weights": w.tolist(), "relative_sensitivity": float(vals[-1])}
    return out

def constructed_combination(grams, repair):
    """EXPERIMENTAL (Law Test 3's C4 did not pass): the combination with the most first-order repair per unit of
    side effect under the mean of the slices' matrices."""
    G = np.mean([np.atleast_2d(np.asarray(v, dtype=float)) for v in grams.values()], axis=0)
    w = np.linalg.solve(_ridge(G, G.shape[0]), np.asarray(repair, dtype=float))
    return w / np.linalg.norm(w)

def interaction_coefficients(gram):
    """Normalized interactions G_ij / sqrt(G_ii G_jj): 0 = independent side effects, +1 = they compound fully,
    -1 = they cancel."""
    G = np.atleast_2d(np.asarray(gram, dtype=float))
    d = np.sqrt(np.maximum(np.diag(G), 1e-30))
    return (G / d[:, None] / d[None, :]).tolist()

def clopper_pearson_lower(x, n, conf=0.95):
    from scipy.stats import beta
    return float(beta.ppf((1 - conf) / 2, x, n - x + 1)) if x > 0 else 0.0

# ---- toxicity: severity grades, dose-limiting toxicities, and efficacy ----------------------------------------------
GRADE_RULES = "grade 0: no breaks; 1: <= 2%; 2: <= 5%; 3: <= 10%; 4: > 10% of baseline-correct items; any break in a critical organ is grade 4"

def grade_breaks(breaks, n_correct, critical=False):
    """CTCAE-style grade for an organ panel from paired breaks (baseline-correct items that turn wrong)."""
    if n_correct == 0:
        return None
    if breaks == 0:
        return 0
    if critical:
        return 4
    rate = breaks / n_correct
    return 1 if rate <= 0.02 else 2 if rate <= 0.05 else 3 if rate <= 0.10 else 4

def is_dlt(grade, critical=False):
    """Dose-limiting toxicity: grade 3 or more in any organ, or any break (grade 1+) in a critical organ."""
    return grade is not None and (grade >= 3 or (critical and grade >= 1))

def ed50(doses, effects):
    """Smallest dose at which the effect reaches half its maximum over the doses (log-linear interpolation).
    None when there is no positive effect."""
    d, e = np.asarray(doses, dtype=float), np.asarray(effects, dtype=float)
    order = np.argsort(d)
    d, e = d[order], e[order]
    emax = float(e.max()) if len(e) else 0.0
    if emax <= 0:
        return None
    half = emax / 2
    i = int(np.argmax(e >= half))
    if i == 0:
        return float(d[0])
    lo, hi = math.log(d[i - 1]), math.log(d[i])
    frac = (half - e[i - 1]) / max(e[i] - e[i - 1], 1e-30)
    return float(math.exp(lo + frac * (hi - lo)))
