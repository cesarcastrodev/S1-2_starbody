"""The monograph: a certified dose with its evidence, written as a package insert for a model intervention."""
import json
import time
from dataclasses import dataclass, field, asdict

SCHEMA_VERSION = "0.3"

LIMITATIONS = [
    "KL is exposure, not harm. The budgets bound measured exposure (mean, worst text, and under generation) on the named "
    "slices; the organ panels test a few functions directly, but untested functions are not covered.",
    "Certification covers small, local interventions. The quadratic law holds near zero dose; large behaviour changes "
    "leave that regime.",
    "Coverage is empirical, on the verification slices. Traffic unlike every slice, rare outputs and adversarial "
    "inputs are not covered. Re-certify when the traffic mix or the model changes.",
    "Evidence base: Starbody Law Tests 2 and 3, four models from 1.5B to 7B parameters (Gemma-2, Qwen2.5), "
    "residual-stream patches. Other architectures and intervention types are untested.",
]

@dataclass
class Monograph:
    intervention: dict
    model: dict
    slices: dict
    precision: dict
    budget: dict
    dose: dict
    escalation: dict
    verification: dict
    monitoring_plan: dict
    status: str = "certified"
    gates: dict = field(default_factory=dict)
    flags: list = field(default_factory=list)
    exposure: dict = field(default_factory=dict)
    toxicity: dict = field(default_factory=dict)
    indication: dict = field(default_factory=dict)
    contraindications: list = field(default_factory=list)
    interactions: dict = None
    limitations: list = field(default_factory=lambda: list(LIMITATIONS))
    provenance: dict = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    def to_dict(self):
        return asdict(self)

    def to_json(self, path=None):
        text = json.dumps(self.to_dict(), indent=1, default=_jsonable)
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
        return text

    @classmethod
    def from_json(cls, text_or_path):
        text = text_or_path
        if not text_or_path.lstrip().startswith("{"):
            with open(text_or_path, encoding="utf-8") as f:
                text = f.read()
        return cls(**json.loads(text))

    def render(self):
        """Human-readable package insert (Markdown)."""
        d, b, v, p = self.dose, self.budget, self.verification, self.precision
        lines = [f"# Monograph · {self.intervention.get('name', 'intervention')}",
                 f"Model {self.model.get('model_id', '?')} in {self.model.get('precision', '?')} · fingerprint "
                 f"{self.intervention.get('fingerprint', '?')} · schema {self.schema_version}", "",
                 ("## Certified dose" if self.status == "certified" else "## NO CERTIFICATE ISSUED"),
                 *( [f"- Failed gates: {', '.join(k for k, g in self.gates.items() if not g['pass'])} "
                     f"(candidate dose {d.get('candidate', 0):.4g})"] if self.status != "certified" else []),
                 f"- **Dose: {d['certified']:.4g}** x the delta (binding: {d.get('binding')}); budget {b['used']} nats of excess "
                 f"KL per token" + ("" if b.get("feasible") else " — **NOT FEASIBLE: the floor is too close to the "
                                    "budget for a trustworthy certificate**"),
                 f"- Candidates: excess certificate {_f(d.get('excess_certificate'))}, worst-text certificate "
                 f"{_f(d.get('worst_text_certificate'))}, escalation stop "
                 f"{_f(d.get('escalation_stop'))}, matrix certificate {_f(d.get('matrix_certificate', {}).get('raw'))}"
                 + (f" (calibrated {_f(d['matrix_certificate']['calibrated'])})"
                    if d.get("matrix_certificate", {}).get("calibrated") else ""),
                 f"- Guard factor {d.get('guard')}; escalation rule R1, stop "
                 f"{self.escalation.get('trigger') or 'not triggered'}", "",
                 *( [f"- Flag: {x}" for x in self.flags] ),
                 "- Gates: " + ", ".join(f"{k} {'pass' if g['pass'] else 'FAIL'}" for k, g in self.gates.items()), "",
                 "## Precision report",
                 "- Noise floor per slice (null patches): " +
                 ", ".join(f"{k} {x:.2e}" for k, x in p.get("null_floors", {}).items()),
                 f"- Calibration factor (matrix curvature / float32 curvature): {p.get('calibration_factor') or 'not measured'}",
                 f"- Feasibility rule: budget >= {p.get('feasibility_multiple')} x the largest monitor floor", "",
                 "## Verification (slices not used for certification)"]
        for k, r in v.get("slices", {}).items():
            lines.append(f"- {k}: excess {r['excess']:.2e} ({r['excess'] / b['used']:.0%} of budget) "
                         f"{'within' if r['within_budget'] else 'OVER'} budget")
        if v.get("coverage") is not None:
            lines.append(f"- Coverage {v['coverage']:.0%}; worst slice uses {v['worst_excess_over_budget']:.0%} of the budget")
        if self.interactions:
            lines += ["", "## Interactions",
                      f"- Members: {', '.join(self.interactions.get('members', []))}; weights "
                      f"{[round(x, 3) for x in self.interactions.get('weights', [])]}",
                      f"- Computed guard: {self.interactions['guards']['single']:.2f} for single patches, "
                      f"{self.interactions['guards']['combinations']:.2f} over all combinations"]
        ind = self.indication or {}
        if ind:
            lines += ["", "## Indication and benefit"]
            if ind.get("control"):
                lines.append("- Control intervention: certified without an indication.")
            elif ind.get("declared"):
                lines.append(f"- Kind {ind['kind']}: efficacy at the certified dose {_f(ind.get('efficacy_at_dose'))} on "
                             f"{ind.get('n_items')} held-out items; ED50 {_f(ind.get('ed50'))}; therapeutic index "
                             f"(certified dose / ED50) {_f(ind.get('therapeutic_index'))}")
            else:
                lines.append("- **No indication declared.**")
        tox = self.toxicity or {}
        if tox.get("organs"):
            lines += ["", "## Toxicity at the certified dose (held-out panel items)"]
            for k, o in tox["organs"].items():
                lines.append(f"- {k}{' (critical)' if o.get('critical') else ''}: grade {o['grade']} "
                             f"({o['breaks']} breaks / {o['n_correct']} correct at baseline)")
            if tox.get("dlt_stop"):
                lines.append(f"- Escalation stopped by a dose-limiting toxicity: {tox['dlt_stop']}")
        ex = self.exposure or {}
        if ex.get("generation"):
            lines += ["", "## Exposure under generation"]
            for k, g in ex["generation"].items():
                lines.append(f"- {k}: excess {g['excess']:.2e} ({g['excess'] / b['used']:.0%} of budget), "
                             f"{g.get('ratio_to_teacher_forced', float('nan')):.2f}x the teacher-forced excess; greedy "
                             f"output diverges on {g['greedy_divergence']:.0%} of prompts")
        if self.contraindications:
            lines += ["", "## Contraindications and cautions"] + [f"- {x}" for x in self.contraindications]
        lines += ["", "## Monitoring plan"] + [f"- {k}: {x}" for k, x in self.monitoring_plan.items()]
        lines += ["", "## Limitations"] + [f"- {x}" for x in self.limitations]
        return "\n".join(lines)

def validate(m):
    """Problems with a monograph (an empty list means it is internally consistent)."""
    probs = []
    d = m.dose
    if not (d.get("certified", -1) >= 0):
        probs.append("certified dose missing or negative")
    for k in ("excess_certificate", "escalation_stop"):
        x = d.get(k)
        if x is not None and x == x and d.get("certified", 0) > x * (1 + 1e-9):
            probs.append(f"certified dose exceeds {k}")
    mc = d.get("matrix_certificate", {})
    if mc.get("raw") and d.get("certified", 0) > mc["raw"] * (1 + 1e-9):
        probs.append("certified dose exceeds the matrix certificate")
    if not m.budget.get("used", 0) > 0:
        probs.append("budget missing")
    cov = m.verification.get("coverage")
    if cov is not None and not (0 <= cov <= 1):
        probs.append("coverage outside [0, 1]")
    if m.status not in ("certified", "refused"):
        probs.append("status must be certified or refused")
    if m.status == "refused" and d.get("certified", 0) != 0:
        probs.append("a refused monograph must issue dose 0")
    if m.status == "certified" and any(not g.get("pass") for g in m.gates.values()):
        probs.append("certified despite a failed gate")
    if m.status == "certified" and any(o.get("dlt") for o in (m.toxicity or {}).get("organs", {}).values()):
        probs.append("certified despite a dose-limiting toxicity at the certified dose")
    if m.schema_version != SCHEMA_VERSION:
        probs.append(f"schema {m.schema_version} differs from {SCHEMA_VERSION}")
    return probs

def _f(x):
    return "n/a" if x is None or x != x else f"{x:.4g}"

def _jsonable(o):
    try:
        import numpy as np
        if isinstance(o, np.generic):
            return o.item()
        if isinstance(o, np.ndarray):
            return o.tolist()
    except ImportError:
        pass
    if hasattr(o, "tolist"):
        return o.tolist()
    raise TypeError(type(o))

def now():
    return time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
