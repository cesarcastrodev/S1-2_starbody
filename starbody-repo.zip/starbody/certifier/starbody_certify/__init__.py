"""starbody-certify: certified doses for residual-stream interventions on language models.

    from starbody_certify import Certifier, Intervention, TorchBackend
    from starbody_certify.data import standard_slices

    monitor, verify = standard_slices()
    backend = TorchBackend(model, tokenizer, {**monitor, **verify})
    cert = Certifier(backend, monitor=list(monitor), verify=list(verify))
    mono = cert.certify(Intervention("my_patch", delta))      # delta: [layers, width]
    print(mono.render()); mono.to_json("my_patch.monograph.json")
"""
from .certifier import Certifier, Intervention, formulary_table, __version__
from .monograph import Monograph, validate

def TorchBackend(*args, **kwargs):          # imported lazily so the package works without torch
    from .backend import TorchBackend as _TB
    return _TB(*args, **kwargs)

__all__ = ["Certifier", "Intervention", "Monograph", "validate", "TorchBackend", "formulary_table", "__version__"]
