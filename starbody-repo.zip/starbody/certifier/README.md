# starbody-certify 0.2

Certified doses for interventions that add a vector to a language model's residual stream (repair patches, steering
vectors, combinations of them). Each certification produces a **monograph**: the dose, the exposure it causes, the
toxicity it shows, the benefit it brings, its interactions, contraindications, a monitoring plan and the limits of the
claim — a package insert for a model intervention.

**The toxicity model (new in 0.2).** KL is treated as exposure, not harm:
- **Exposure** is bounded three ways: mean KL per slice, the worst single text (4x the budget), and KL along the
  patched model's own generations, where per-token shifts can compound.
- **Toxicity** is tested directly by organ panels (judge-free function tests: facts, arithmetic, grammar, code, a
  second language; add your own, such as refusals on an instruction-tuned model). Breaks of baseline-correct items are
  graded like adverse events (grades 0-4). Grade 3 or more, or any break in an organ you declare critical, is a
  dose-limiting toxicity: the escalation stops before it, and a certificate is never issued with one.
- **Benefit**: every intervention declares its indication (items it should improve) and is certified with its measured
  efficacy, ED50 and therapeutic index, or declares itself a control.
- **Contraindications** list the slices and organs where the certified dose comes close to a limit.

## Quickstart

```python
from starbody_certify import Certifier, Intervention, TorchBackend
from starbody_certify.data import standard_slices

monitor, verify = standard_slices()                    # WikiText + built-in conversational, code, Portuguese, maths, procedural
backend = TorchBackend(model, tokenizer, {**monitor, **verify})   # model in its deployment precision, on the GPU
from starbody_certify.data import standard_panels
cert = Certifier(backend, monitor=list(monitor), verify=list(verify), panels=standard_panels())

cert.calibrate([Intervention("a", d1), Intervention("b", d2)])     # optional; needs room for a float32 copy
mono = cert.certify(Intervention("my_patch", delta, indication=items))   # delta: [layers, width]; items it should fix
print(mono.render())
mono.to_json("my_patch.monograph.json")

combo = cert.certify_combination([Intervention("a", d1), Intervention("b", d2)], weights=[1.0, 0.5])
```

## What the certifier does

1. **Measures the noise floor** of every slice with random null patches. In bfloat16, measured KL = floor + true
   effect; a budget closer than 4x the floor is flagged as not feasible.
2. **Computes the curvature on demand** (Hessian-vector products of KL at zero patch; nothing stored) and anchors a
   dose grid on it.
3. **Fits the certificate on the excess over the floor**, near the budget, never on small doses.
4. **Escalates under monitoring with rule R1**: stop when any slice's excess reaches the budget, or when it
   accelerates, checked only where the excess is at least 10x the floor.
5. **Takes the most conservative** of the excess certificate, the escalation stop and the matrix certificate (the
   latter is calibrated against float32 when `calibrate` has been run, again taking the safer side).
6. **Verifies** the dose on slices certification never saw, and writes the monograph.
7. **Fails closed.** A dose is issued only if every product gate passes; otherwise the monograph says "no certificate"
   and why:
   - feasibility: the budget is at least 4x the largest monitor floor;
   - agreement: matrix and measured certificates within 10% (10-25%: the smaller dose is issued with a flag; beyond: refused);
   - calibration: the factor, when measured, lies within [0.5, 2.0] (outside [0.8, 1.25] it is flagged as precision
     inflation; the conservative matrix certificate already covers it);
   - shape: not still over budget after the escalation's halvings (an R1 acceleration stop is flagged as faster-than-quadratic);
   - verification: every verification slice within budget;
   - repeatability: the excess, re-measured with one text per batch, agrees within 5% or 3x the floor's spread,
     whichever is larger.

`Certifier.balanced_weights(cert.interactions(ivs))` gives combination weights under which each member alone has the
same worst-slice side effect, so a combination is not dominated by its most fragile member. `formulary_table(monographs)`
summarises a set of monographs side by side.

## Evidence (Starbody Law Tests 2 and 3; four models, Gemma-2-2B and Qwen2.5 1.5B/3B/7B)

- Side effects grow as dose^2 in float32 (exponent 2.00 in every model).
- bfloat16 adds a floor: about 1-2% of a 0.02-nat budget in the small models, about half of it in Qwen2.5-7B. The floor
  tracks the activation outlier ratio. float16's floor in Gemma-2-2B was 60.6x lower (64x predicted).
- Certified doses kept the true held-out side effect within budget in 100% of patch x genre pairs in all four models,
  including adversarial combinations.
- Post hoc: rule R1 removes the false acceleration stops that left some patches under-dosed, with coverage unchanged;
  one calibration factor per model fixes the matrix's prediction on Qwen2.5-7B (75% -> 90% within 25%).

## What a certificate does not mean

The toxicity model is new in 0.2 and has not yet passed a gate: its organ panels are small and synthetic, its grade
thresholds are conventions, and generation exposure uses the natural-text floor as an approximation.

See `Monograph.limitations`: it bounds measured KL on named slices, not harm; it covers small local interventions; it
is empirical coverage, not a formal guarantee; it has been tested on four models up to 7B and on residual patches only.

## Tests

`python -m unittest discover -s tests` (27 tests) — the mathematics, every product gate and the whole pipeline, run against a numpy
stand-in model with the measured laws built in (no GPU needed).

## Roadmap

0.1 certifier (this) · 0.2 formulary and interaction checker · 0.3 prescriber (needs task-level efficacy measures) ·
0.4 dispenser and pharmacovigilance (serving integration, drift re-certification).
