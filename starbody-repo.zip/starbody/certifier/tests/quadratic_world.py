"""A numerical stand-in for a model, with the measured laws built in.

'bfloat16': per-text KL = a noisy per-text floor + (1 + eps) x the true quadratic effect, and the curvature includes
the same inflation. 'float32': per-text KL is the true effect. Each text has its own sensitivity, so tails exist.
Items carry stand-in fields (m0: baseline margin, tox: harm per unit effect, eff: benefit per unit effect) that only
this stand-in reads; a real backend scores items with the model."""
import contextlib
import hashlib
import numpy as np

class QuadraticWorld:
    def __init__(self, slices, L=4, D=8, floor=2e-4, eps=0.0, floor_noise=0.15, seed=0, accelerate_above=None,
                 hvp_scale=1.0, rebatch_bias=0.0, sensitive=None, n_texts=12, hot_text=None, compounding=0.3):
        rng = np.random.default_rng(seed)
        self.L, self.D, self.slices = L, D, list(slices)
        self.H = {s: rng.lognormal(0, 0.5, size=(L, D)) for s in slices}
        for s, factor in (sensitive or {}).items():
            self.H[s] = self.H[s] * factor
        self.text_factor = {s: rng.lognormal(0, 0.3, size=n_texts) for s in slices}
        if hot_text:
            s, i, f = hot_text
            self.text_factor[s][i] *= f
        self.floor = {s: floor * rng.lognormal(0, 0.2) for s in slices}
        self.text_floor = {s: self.floor[s] * rng.lognormal(0, 0.2, size=n_texts) for s in slices}
        self.eps, self.floor_noise, self.fp32 = eps, floor_noise, False
        self.rng = np.random.default_rng(seed + 1)
        self.accelerate_above, self.hvp_scale, self.rebatch_bias, self.compounding = accelerate_above, hvp_scale, rebatch_bias, compounding

    def _q(self, s, d):
        q = 0.5 * float((self.H[s] * d * d).sum())
        if self.accelerate_above and q > self.accelerate_above:
            q = q * (q / self.accelerate_above)
        return q

    def true_kl_text(self, s, d):
        return self._q(s, d) * self.text_factor[s]

    def true_kl(self, s, d):
        return float(np.mean(self.true_kl_text(s, d)))

    def kl_per_text(self, s, d):
        q = self.true_kl_text(s, d)
        tok = np.full(len(q), 64.0)
        if self.fp32:
            return q, tok
        return self.text_floor[s] * self.rng.lognormal(0, self.floor_noise, size=len(q)) + (1 + self.eps) * q, tok

    def mean_kl(self, s, d):
        per, tok = self.kl_per_text(s, d)
        return float((per * tok).sum() / tok.sum())

    def mean_kl_rebatched(self, s, d):
        return self.mean_kl(s, d) * (1 + self.rebatch_bias) if not self.fp32 else self.true_kl(s, d)

    def hvp(self, s, vecs):
        f = (1.0 if self.fp32 else 1.0 + self.eps) * self.hvp_scale * float(np.mean(self.text_factor[s]))
        return [f * self.H[s] * v for v in vecs]

    def score_items(self, items, d=None):
        r = 0.0 if d is None else float(np.sqrt(2 * self.true_kl(self.slices[0], d)))
        return np.array([it.get("m0", 3.0) - it.get("tox", 0.0) * r + it.get("eff", 0.0) * r for it in items])

    def generation_exposure(self, s, d, n_prompts=16, seed=0, **kw):
        q = self.true_kl(s, d)
        return {"kl_along_patched": self.floor[s] + (1 + self.eps) * (1 + self.compounding) * q,
                "greedy_divergence": min(1.0, 20 * q), "first_divergence_mean": 48 * (1 - min(1.0, 20 * q)),
                "prompts": n_prompts, "new_tokens": 48, "temperature": 1.0}

    def null_like(self, d, seed):
        r = np.random.default_rng(int(seed)).normal(size=(self.L, self.D))
        return r / np.linalg.norm(r, axis=1, keepdims=True) * np.linalg.norm(d, axis=1, keepdims=True)

    @contextlib.contextmanager
    def precision(self, name):
        old, self.fp32 = self.fp32, name == "float32"
        try:
            yield
        finally:
            self.fp32 = old

    def describe(self):
        return {"model_id": "quadratic-world", "precision": "bfloat16-like", "layers": self.L, "width": self.D, "vocabulary": 0}

    def slice_info(self, s):
        return {"texts": len(self.text_factor[s]), "sha256": s}

    def fingerprint(self, d):
        return hashlib.sha256(np.asarray(d, dtype=float).tobytes()).hexdigest()[:16]
