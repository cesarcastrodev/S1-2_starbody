import math
import os
import sys
import tempfile
import unittest
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from starbody_certify import Certifier, Intervention, Monograph, validate, formulary_table
from starbody_certify import _math as M
from quadratic_world import QuadraticWorld

MON = ["A", "B", "C", "D"]
VER = ["A_h", "B_h", "C_h", "D_h", "E", "F"]

def world(**kw):
    return QuadraticWorld(MON + VER, **kw)

def patch(seed, L=4, D=8):
    return np.random.default_rng(100 + seed).normal(size=(L, D))

def organs(fragile=None, base_tox=0.3, n=60, seed=0):
    rng = np.random.default_rng(seed)
    out = {}
    for name in ("facts", "arithmetic", "grammar", "code"):
        tox = (fragile[1] if fragile and fragile[0] == name else base_tox)
        out[name] = [{"prompt": f"{name}{i}", "choices": ["x", "y"], "answer": 0, "m0": 3.0,
                      "tox": tox * rng.uniform(0.5, 1.5)} for i in range(n)]
    return out

def indication(n=60, eff=40.0, seed=1):
    rng = np.random.default_rng(seed)
    return [{"prompt": f"err{i}", "choices": ["x", "y"], "answer": 0, "m0": -1.0, "eff": eff * rng.uniform(0.5, 1.5)}
            for i in range(n)]

def ctrl(name, d):
    return Intervention(name, d, control=True)

class TestMath(unittest.TestCase):
    def test_excess_certificate_is_exact_on_a_clean_quadratic(self):
        eta = {"A": 1.0, "B": 0.6, "C": 2.5, "D": 1.2}
        tau, guard = 0.02, 2.0
        grid = [math.sqrt(tau / eta["A"]) * 2 ** (-k / 2) for k in range(-2, 11)]
        floors = {g: 1e-4 for g in eta}
        kl = {g: [floors[g] + eta[g] * s ** 2 for s in grid] for g in eta}
        dose, _ = M.excess_certificate(grid, kl, floors, tau, guard)
        self.assertAlmostEqual(dose, min(math.sqrt(tau / e) for e in eta.values()) / guard, places=10)

    def test_r1_ignores_noise_near_the_floor_but_catches_real_acceleration(self):
        tau, F = 0.02, {"A": 2e-4}
        ladder = M.escalation_ladder(0.05)
        noisy = {"A": [4.5e-4, 1.2e-3, 1.5e-3, 2.1e-3, 2.9e-3, 3.8e-3, 4.6e-3]}
        self.assertIsNone(M.escalate_r1(ladder, noisy, F, tau, noise_multiple=10)[1])
        self.assertIsNotNone(M.escalate_r1(ladder, noisy, F, tau, noise_multiple=2)[1])
        quartic = {"A": [3e-3 * (x / ladder[0]) ** 4 for x in ladder]}
        t3 = M.escalate_r1(ladder, quartic, F, tau, noise_multiple=10)[1]
        self.assertTrue(t3 and ("acceleration" in t3 or "budget" in t3))

    def test_feasible_budget(self):
        self.assertEqual(M.feasible_budget({"A": 1e-4}), (0.02, True))
        self.assertEqual(M.feasible_budget({"A": 0.012}), (0.05, True))
        self.assertEqual(M.feasible_budget({"A": 0.05}), (0.1, False))
        self.assertEqual(M.feasible_budget({"A": 0.01}, requested=0.02), (0.02, False))

    def test_matrix_certificate_takes_the_conservative_side(self):
        G = {"A": [[2.0]], "B": [[1.0]]}
        raw = math.sqrt(2 * 0.02 / 2.0) / 2
        self.assertAlmostEqual(M.matrix_certificate([1.0], G, 0.02, 2.0, calibration=1.25)[0], raw)
        self.assertAlmostEqual(M.matrix_certificate([1.0], G, 0.02, 2.0, calibration=0.8)[0], raw * math.sqrt(0.8))

    def test_guards_and_adversarial_combinations(self):
        G = {"A": np.diag([1.0, 5.0, 1.0]), "B": np.diag([1.0, 1.0, 2.0]), "C": np.eye(3), "D": np.eye(3)}
        self.assertAlmostEqual(M.computed_guards(G)["combinations"], math.sqrt(5), places=2)
        self.assertAlmostEqual(abs(M.adversarial_combinations(G)["A"]["weights"][1]), 1.0, places=6)

    def test_grades_dlt_and_ed50(self):
        self.assertEqual([M.grade_breaks(b, 100) for b in (0, 2, 5, 10, 11)], [0, 1, 2, 3, 4])
        self.assertEqual(M.grade_breaks(1, 100, critical=True), 4)
        self.assertTrue(M.is_dlt(3) and not M.is_dlt(2) and M.is_dlt(1, critical=True))
        self.assertAlmostEqual(M.ed50([1, 2, 4, 8], [0.0, 0.2, 0.6, 0.8]), math.exp(math.log(2) + 0.5 * math.log(2)), places=6)
        self.assertIsNone(M.ed50([1, 2], [0.0, -0.1]))

class TestCertifier(unittest.TestCase):
    def check(self, m, tau=None, feasible=True):
        self.assertEqual(validate(m), [])
        self.assertEqual(m.budget["feasible"], feasible)
        if tau:
            self.assertEqual(m.budget["used"], tau)
        self.assertEqual(Monograph.from_json(m.to_json()).dose["certified"], m.dose["certified"])
        self.assertIn("Certified dose" if m.status == "certified" else "NO CERTIFICATE ISSUED", m.render())

    def true_ok(self, w, d, dose, tau, tau_tail, slices):
        return all(w.true_kl(s, d * dose) <= tau and max(w.true_kl_text(s, d * dose)) <= tau_tail for s in slices)

    def test_small_floor_model(self):
        w = world(floor=2e-4, seed=1)
        c = Certifier(w, MON, VER, verbose=False)
        for k in range(5):
            m = c.certify(ctrl(f"p{k}", patch(k)))
            self.check(m, 0.02)
            self.assertEqual(m.status, "certified")
            self.assertGreaterEqual(m.verification["worst_excess_over_budget"], 1 / 8)
            self.assertTrue(self.true_ok(w, patch(k), m.dose["certified"], 0.02, 0.08, MON + VER))

    def test_large_floor_inflated_model_like_the_7b(self):
        m = Certifier(world(floor=0.012, eps=0.25, seed=2), MON, VER, verbose=False).certify(ctrl("p", patch(3)))
        self.check(m, 0.1)
        self.assertEqual(m.status, "certified")

    def test_infeasible_budget_is_refused(self):
        m = Certifier(world(floor=0.05, seed=3), MON, VER, verbose=False).certify(ctrl("p", patch(1)))
        self.check(m, 0.1, feasible=False)
        self.assertEqual((m.status, m.dose["certified"]), ("refused", 0.0))
        self.assertIn("NOT FEASIBLE", m.render())

    def test_combination_with_interactions(self):
        w = world(floor=2e-4, seed=4)
        c = Certifier(w, MON, VER, verbose=False)
        ivs = [ctrl(f"p{k}", patch(k)) for k in range(3)]
        m = c.certify_combination(ivs, [0.7, -0.4, 1.1])
        self.check(m, 0.02)
        self.assertEqual(np.array(m.interactions["coefficients"]["A"]).shape, (3, 3))
        d = sum(x * iv.delta for x, iv in zip([0.7, -0.4, 1.1], ivs))
        self.assertTrue(self.true_ok(w, d, m.dose["certified"], 0.02, 0.08, MON + VER))

    def test_calibration_recovers_the_inflation(self):
        c = Certifier(world(floor=2e-4, eps=0.25, seed=5), MON, VER, verbose=False)
        self.assertAlmostEqual(c.calibrate([ctrl(f"p{k}", patch(k)) for k in range(3)])["factor"], 1.25, delta=0.02)

    def test_superquadratic_growth_stays_safe(self):
        w = world(floor=2e-4, seed=6, accelerate_above=0.02 / 8)
        c = Certifier(w, MON, VER, verbose=False)
        for k in range(4):
            m = c.certify(ctrl(f"p{k}", patch(k)))
            self.assertEqual(validate(m), [])
            self.assertTrue(self.true_ok(w, patch(k), m.dose["certified"], 0.02, 0.08, MON + VER))

    def test_monograph_file_round_trip(self):
        m = Certifier(world(seed=7), MON, VER, verbose=False).certify(ctrl("p", patch(2)))
        with tempfile.TemporaryDirectory() as t:
            p = os.path.join(t, "p.monograph.json")
            m.to_json(p)
            self.assertEqual(Monograph.from_json(p).intervention["fingerprint"], m.intervention["fingerprint"])

class TestToxicityModel(unittest.TestCase):
    def test_a_hot_monitor_text_binds_the_worst_text_certificate(self):
        w = world(seed=21, hot_text=("A", 3, 20.0))
        m = Certifier(w, MON, VER, verbose=False).certify(ctrl("p", patch(1)))
        self.assertEqual(m.status, "certified")
        self.assertLess(m.dose["worst_text_certificate"], m.dose["excess_certificate"])
        self.assertTrue(max(w.true_kl_text("A", patch(1) * m.dose["certified"])) <= 0.08)

    def test_a_hot_verification_text_is_refused(self):
        m = Certifier(world(seed=22, hot_text=("E", 0, 120.0)), MON, VER, verbose=False).certify(ctrl("p", patch(1)))
        self.assertEqual(m.status, "refused")
        self.assertFalse(m.gates["tail"]["pass"])

    def test_compounding_under_generation(self):
        mild = Certifier(world(seed=23, compounding=0.3), MON, VER, verbose=False).certify(ctrl("p", patch(1)))
        self.assertEqual(mild.status, "certified")
        r = [g["ratio_to_teacher_forced"] for g in mild.exposure["generation"].values()]
        self.assertTrue(all(1.1 < x < 1.6 for x in r))
        harsh = Certifier(world(seed=23, compounding=6.0), MON, VER, verbose=False).certify(ctrl("p", patch(1)))
        self.assertEqual(harsh.status, "refused")
        self.assertFalse(harsh.gates["generation"]["pass"])

    def test_dose_limiting_toxicity_stops_the_escalation(self):
        c = Certifier(world(seed=24), MON, VER, panels=organs(fragile=("arithmetic", 70.0)), verbose=False)
        m = c.certify(ctrl("p", patch(1)))
        self.assertIn("dose-limiting toxicity", str(m.escalation.get("trigger")))
        self.assertEqual(validate(m), [])
        if m.status == "certified":
            self.assertFalse(any(o["dlt"] for o in m.toxicity["organs"].values()))

    def test_benign_organs_pass_and_are_graded(self):
        m = Certifier(world(seed=25), MON, VER, panels=organs(), verbose=False).certify(ctrl("p", patch(1)))
        self.assertEqual(m.status, "certified")
        self.assertTrue(all(o["grade"] == 0 for o in m.toxicity["organs"].values()))

    def test_a_critical_organ_tolerates_no_break(self):
        panels = organs(fragile=("facts", 40.0))
        m = Certifier(world(seed=26), MON, VER, panels=panels, critical=["facts"], verbose=False).certify(ctrl("p", patch(1)))
        self.assertTrue(m.toxicity["organs"]["facts"]["critical"])
        self.assertEqual(m.toxicity["organs"]["facts"]["breaks"] if m.status == "certified" else 0, 0)

    def test_indication_benefit_and_therapeutic_index(self):
        c = Certifier(world(seed=27), MON, VER, panels=organs(), verbose=False)
        m = c.certify(Intervention("repair", patch(1), indication=indication()))
        self.assertEqual(m.status, "certified")
        self.assertGreater(m.indication["efficacy_at_dose"], 0.5)
        self.assertGreater(m.indication["therapeutic_index"], 1.0)
        none = c.certify(Intervention("unexplained", patch(2)))
        self.assertEqual(none.status, "refused")
        self.assertFalse(none.gates["indication"]["pass"])

    def test_contraindications_flag_a_slice_near_its_budget(self):
        m = Certifier(world(seed=28, sensitive={"E": 3.2}), MON, VER, verbose=False).certify(ctrl("p", patch(1)))
        self.assertEqual(m.status, "certified")
        self.assertTrue(any("caution on E" in x for x in m.contraindications))

class TestProductGates(unittest.TestCase):
    def run_one(self, cert_kwargs=None, calibration=None, **world_kwargs):
        c = Certifier(world(**world_kwargs), MON, VER, verbose=False, **(cert_kwargs or {}))
        c.calibration = calibration
        m = c.certify(ctrl("p", patch(1)))
        self.assertEqual(validate(m), [])
        return m

    def test_clean_case_passes_every_gate(self):
        m = self.run_one(seed=11)
        self.assertEqual(m.status, "certified")
        self.assertTrue(all(g["pass"] for g in m.gates.values()))

    def test_matrix_disagreement_flags_then_refuses(self):
        flagged = self.run_one(seed=12, hvp_scale=1.35)
        self.assertEqual(flagged.status, "certified")
        self.assertTrue(any("disagree" in f for f in flagged.flags))
        refused = self.run_one(seed=12, hvp_scale=3.0)
        self.assertEqual(refused.status, "refused")
        self.assertFalse(refused.gates["agreement"]["pass"])

    def test_precision_inflation_is_flagged_not_refused(self):
        m = self.run_one(seed=13, calibration=1.3)
        self.assertEqual(m.status, "certified")
        self.assertTrue(any("precision inflation" in f for f in m.flags))
        self.assertEqual(self.run_one(seed=13, calibration=2.5).status, "refused")

    def test_a_hidden_sensitive_slice_fails_verification(self):
        m = self.run_one(seed=14, sensitive={"E": 30.0})
        self.assertEqual(m.status, "refused")
        self.assertFalse(m.gates["verification"]["pass"])

    def test_repeatability(self):
        self.assertTrue(self.run_one(seed=15, rebatch_bias=0.01).gates["repeatability"]["pass"])
        self.assertFalse(self.run_one(seed=15, rebatch_bias=0.12).gates["repeatability"]["pass"])
        self.assertTrue(self.run_one(seed=17, floor=0.012, eps=0.25).gates["repeatability"]["pass"])

    def test_balanced_weights_and_formulary_table(self):
        inter = {"members": ["a", "b"], "grams": {"A": [[100.0, 0.0], [0.0, 4.0]], "B": [[25.0, 0.0], [0.0, 1.0]]}}
        self.assertEqual([round(x, 6) for x in Certifier.balanced_weights(inter)], [0.2, 1.0])
        c = Certifier(world(seed=16), MON, VER, panels=organs(), verbose=False)
        table = formulary_table([c.certify(ctrl(f"p{k}", patch(k))) for k in range(2)])
        self.assertEqual(len(table.splitlines()), 4)

if __name__ == "__main__":
    unittest.main(verbosity=2)
