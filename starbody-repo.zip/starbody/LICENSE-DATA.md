# Licence for results, figures and text

Result files, figures, readings and other text in this repository are released under
Creative Commons Attribution 4.0 International (CC BY 4.0).
Full text: https://creativecommons.org/licenses/by/4.0/legalcode

Copyright (c) 2026 César Castro
